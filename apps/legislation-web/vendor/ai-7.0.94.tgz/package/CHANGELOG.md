# ai

## 7.0.94

### Patch Changes

- a4ba394: feat: support per-request models in batch
- 36b3364: fix(ai): enforce tool choices in streamText
- 45099da: Retry unclassified empty image results, preserve retry-attempt accounting, add provider-independent result retryability classification, and mark Google and Google Vertex prompt blocks as terminal.
- Updated dependencies [a4ba394]
- Updated dependencies [e9bf5e3]
- Updated dependencies [45099da]
- Updated dependencies [56c004c]
- Updated dependencies [9e1d1b2]
- Updated dependencies [a495511]
  - @ai-sdk/provider@4.0.11
  - @ai-sdk/gateway@4.0.76
  - @ai-sdk/provider-utils@5.0.37

## 7.0.93

### Patch Changes

- df6c009: fix(ai): use new message ID when replacing a message in `sendMessage`
- 6ee74a3: fix(ai): preserve tool part titles when validating UI messages
- f13d371: fix(ai): preserve provider metadata when converting failed tool calls
- d4485fe: feat(ai): support minItems and maxItems in array outputs
- 4f201cc: chore(ai): formally include already supported `onLanguageModelCallStart` and `onLanguageModelCallEnd` in `ToolLoopAgentSettings` type
- 8cdb2a7: fix(ai): decode text data URLs in Node.js
- 0f2281e: fix(ai): reject embedding responses whose count does not match the input values
- fc8e8ac: fix(ai): preserve image call diagnostics when no image is generated
- ee8391e: fix(ai): support abort signals when the global AbortSignal is not a constructor
- Updated dependencies [3cfc1fc]
  - @ai-sdk/gateway@4.0.75

## 7.0.92

### Patch Changes

- a51cc94: fix(ai): preserve provider metadata from empty smooth stream deltas
- d1904d3: fix(ai): surface fallback errors for empty HTTP response bodies
- 84e5a79: fix(ai): skip `smoothStream` delays while the document is hidden
- a8e8ad0: fix(ai): expose call ID and abort reason in streamText onAbort callbacks
- Updated dependencies [a7e324b]
  - @ai-sdk/gateway@4.0.74

## 7.0.91

### Patch Changes

- 802af1e: Add configurable recovery for provider errors received after `streamText` response streaming begins. Explicitly configuring `streamRetries` enables isolated retry attempts, including one bounded callback-directed recovery through `StreamTextOnErrorRetryCallback` with `streamRetries: 0`; recovered results and metadata reflect only the successful attempt, while the existing `StreamTextOnErrorCallback` contract and logging-only observer behavior remain compatible.
- Updated dependencies [5484f27]
- Updated dependencies [36eb7ee]
- Updated dependencies [622fa7f]
  - @ai-sdk/gateway@4.0.73

## 7.0.90

### Patch Changes

- Updated dependencies [4d25a08]
- Updated dependencies [6bcc0f8]
  - @ai-sdk/gateway@4.0.72
  - @ai-sdk/provider-utils@5.0.36

## 7.0.89

### Patch Changes

- 5190b67: feat(provider): extend the FilesV4 interface with optional `getFileMetadata`, `downloadFile` (streaming), and `deleteFile` operations, plus `abortSignal`/`headers` call options and a `{ type: 'stream' }` upload data variant; upload results now expose `byteSize`, `createdAt`, and `expiresAt` (also surfaced by the core `uploadFile()` helper, which now forwards `abortSignal`/`headers`); add `postMultipartStreamToApi` (streaming multipart uploads with deterministic part ordering and failure-path stream teardown), `deleteFromApi`, and `createBinaryStreamResponseHandler` to provider-utils
- Updated dependencies [5190b67]
  - @ai-sdk/provider@4.0.10
  - @ai-sdk/provider-utils@5.0.35
  - @ai-sdk/gateway@4.0.71

## 7.0.88

### Patch Changes

- 8b6b756: fix(ai): prevent generateText from accepting responses that violate required tool choices
- e07b577: feat: add tool calling support to batch

## 7.0.87

### Patch Changes

- 850d863: fix(ai): preserve approval descriptors in UI message streams

## 7.0.86

### Patch Changes

- 11109ae: feat(ai): support signed tool approvals in WorkflowAgent
- Updated dependencies [1329d5a]
  - @ai-sdk/gateway@4.0.70

## 7.0.85

### Patch Changes

- 55a9981: Ensure canonical hashes preserve undefined array element positions.
- dd32de2: fix(ai): sum Gateway image-generation costs across split requests
- aa45741: fix(provider/anthropic): preserve native message batch request counts in provider metadata and support the full language-model option surface in batch requests
- cc29073: feat(ai): expose individual image generation calls
- Updated dependencies [d2507af]
- Updated dependencies [aa45741]
  - @ai-sdk/gateway@4.0.69
  - @ai-sdk/provider@4.0.9
  - @ai-sdk/provider-utils@5.0.34

## 7.0.84

### Patch Changes

- 6669d69: Expose parsed structured output in `streamText` end callbacks.
- a6463ca: fix(ai): allow tool approval secrets in ToolLoopAgent settings and prepareCall
- e604532: fix(ai): handle stateful and empty-match regular expressions in smoothStream
- Updated dependencies [805bbfc]
- Updated dependencies [90192f1]
  - @ai-sdk/gateway@4.0.68
  - @ai-sdk/provider-utils@5.0.33

## 7.0.83

### Patch Changes

- 8dd86a9: Validate persisted typed tool calls against current input and output schemas.
  Schema-incompatible empty or error inputs and terminal history from unavailable
  tools remain loadable as dynamic tool parts instead of exposing unvalidated
  values under current static tool types.
- fda13b3: Allow chats to continue automatically after tool approval denials reach the `output-denied` state.
- 957146c: add operation-level outcomes to UI message stream end callbacks
- ce6849a: fix(ai): handle stitchable stream cancellation before an inner stream is registered

## 7.0.82

### Patch Changes

- 3e125ba: Allow manual tool approval statuses to include a reason and preserve it across
  core, model, and UI approval requests. OPA `requires-approval` decisions now
  surface their reason to human approvers. UI request chunks serialize the
  optional `reason`, while UI messages retain it as `approval.requestReason`
  separately from an approver's response `reason`.
- Updated dependencies [0e7994c]
- Updated dependencies [3e125ba]
  - @ai-sdk/gateway@4.0.67
  - @ai-sdk/provider-utils@5.0.32

## 7.0.81

### Patch Changes

- Updated dependencies [81bebaf]
  - @ai-sdk/gateway@4.0.66

## 7.0.80

### Patch Changes

- 35841f5: feat: normalize mid-stream provider error events across supported providers into public StreamProviderError instances and preserve provider-owned type, code, status, retry, and raw payload metadata
- d2f3353: Split OpenAI and Azure OpenAI embedding requests by a conservative UTF-8 byte budget derived from their aggregate token limit, in addition to input count limits.
- eed7950: Expose structured output parsing diagnostics from `generateText` when generation stops because of the output token limit.
- Updated dependencies [80227cf]
- Updated dependencies [a9782e1]
- Updated dependencies [5533946]
- Updated dependencies [35841f5]
- Updated dependencies [d2f3353]
  - @ai-sdk/gateway@4.0.65
  - @ai-sdk/provider-utils@5.0.31

## 7.0.79

### Patch Changes

- b251584: Preserve active text and reasoning parts when another merged UI message stream finishes a step, and align workflow stream normalization with the explicit part end chunks.
- 591d25b: feat: add batch completion webhooks. `experimental_startTextBatch` accepts a `webhookUrl`, and the gateway provider registers it through the batch `callbackUrl` contract and exports typed async-job metadata. Direct Anthropic and OpenAI batch providers return an unsupported warning when the option is provided.
- 9de0baf: Parse structured generateText output when providers omit finishReason but return text.
- Updated dependencies [591d25b]
  - @ai-sdk/gateway@4.0.64
  - @ai-sdk/provider@4.0.8
  - @ai-sdk/provider-utils@5.0.30

## 7.0.78

### Patch Changes

- 96970bb: Continue approved `generateText`, `streamText`, and `WorkflowAgent` turns with a model-visible tool error when revalidated tool input is invalid.
- Updated dependencies [e12e068]
  - @ai-sdk/gateway@4.0.63

## 7.0.77

### Patch Changes

- Updated dependencies [b74971f]
- Updated dependencies [a371615]
  - @ai-sdk/provider-utils@5.0.29
  - @ai-sdk/gateway@4.0.62

## 7.0.76

### Patch Changes

- c6d57f3: fix(ai): prevent duplicate text and reasoning part ids
- 677a707: fix(ai): allow nullish metadata schemas for UI messages with branded IDs

## 7.0.75

### Patch Changes

- 8978ad8: feat(ai): add `experimental_startVideo` and `experimental_videoStatus` — user-facing fire-and-forget wrappers over the video model `doStart`/`doStatus` spec methods, with the same sparse-options DX as `generateVideo`
- Updated dependencies [dedac59]
  - @ai-sdk/gateway@4.0.61

## 7.0.74

### Patch Changes

- Updated dependencies [5941bd6]
- Updated dependencies [9a4337d]
  - @ai-sdk/gateway@4.0.60

## 7.0.73

### Patch Changes

- Updated dependencies [f607a12]
  - @ai-sdk/gateway@4.0.59

## 7.0.72

### Patch Changes

- Updated dependencies [fdcc814]
  - @ai-sdk/gateway@4.0.58

## 7.0.71

### Patch Changes

- 9a37469: Prevent exceptions in streaming `onChunk` and `onError` callbacks from terminating the stream or masking provider errors.
- Updated dependencies [936719b]
  - @ai-sdk/gateway@4.0.57

## 7.0.70

### Patch Changes

- 9566914: Stop multi-step text generation for client tool approval even when a provider-executed tool has a deferred result.
- b181020: fix: reject `streamObject` result promises and report failed completion when the provider stream errors
- 7054073: Filter preliminary tool outputs when `ignoreIncompleteToolCalls` is enabled.
- a828527: Prevent automatic tool execution when a model call ends with an unsafe finish reason.
- d3cc3fe: Clear partial UI message parts when a WorkflowAgent model-call step is retried.
- Updated dependencies [e6087c9]
  - @ai-sdk/provider-utils@5.0.28
  - @ai-sdk/gateway@4.0.56

## 7.0.69

### Patch Changes

- Updated dependencies [1f7a464]
  - @ai-sdk/gateway@4.0.55

## 7.0.68

### Patch Changes

- Updated dependencies [257632b]
  - @ai-sdk/gateway@4.0.54

## 7.0.67

### Patch Changes

- Updated dependencies [a0b1ffc]
  - @ai-sdk/gateway@4.0.53

## 7.0.66

### Patch Changes

- 0782259: Keep chat status submitted until response content begins streaming.
- 2fd1214: Fix declaration emit for exported values that infer an `Output` type.

## 7.0.65

### Patch Changes

- dc8caae: Avoid repeatedly cloning accumulated text in `readUIMessageStream` while
  preserving independent snapshots for mutable nested values.
- 72ec74f: Preserve root-level JSON Schema definitions when wrapping array output schemas.
- c5b0515: Propagate errors thrown by the Chat `onFinish` callback to the initiating request.
- Updated dependencies [16650e9]
  - @ai-sdk/gateway@4.0.52

## 7.0.64

### Patch Changes

- Updated dependencies [ea75787]
- Updated dependencies [b20de9e]
  - @ai-sdk/gateway@4.0.51

## 7.0.63

### Patch Changes

- d0a5807: Preserve reasoning block IDs from UI message streams on reasoning UI parts.
- dcf33e8: Allow providers without reranking model support to be assigned to `Provider`.
- Updated dependencies [a4d386d]
  - @ai-sdk/gateway@4.0.50

## 7.0.62

### Patch Changes

- e0bcf52: feat(ui): add typed custom bodies to Completion APIs

## 7.0.61

### Patch Changes

- 326054b: Prevent `resumeStream` from copying the previous assistant message into the resumed response.
- 975bb28: Cancel messages that are still being prepared when a chat is stopped.
- Updated dependencies [7fbfc6d]
  - @ai-sdk/provider-utils@5.0.27
  - @ai-sdk/gateway@4.0.49

## 7.0.60

### Patch Changes

- 79c52ef: Align `ToolLoopAgent` `prepareCall` types with the settings available and honored at runtime.
- Updated dependencies [3cc1bb6]
  - @ai-sdk/gateway@4.0.48

## 7.0.59

### Patch Changes

- Updated dependencies [401a4ba]
- Updated dependencies [7af9646]
  - @ai-sdk/provider-utils@5.0.26
  - @ai-sdk/gateway@4.0.47

## 7.0.58

### Patch Changes

- 72ad23f: Respect ToolLoopAgent timeouts configured in agent settings.
- ad6a650: feat(video): allow `aspectRatio: 'adaptive'` on `generateVideo`

  Some video models derive the output ratio from the input and reject explicit
  `{width}:{height}` values — BytePlus Seedance 2.5 does this for first-frame,
  first-and-last-frame, editing, and extension tasks. `aspectRatio` on
  `VideoModelV3CallOptions`, `VideoModelV4CallOptions`, and
  `experimental_generateVideo` is now `` `${number}:${number}` | 'adaptive' ``, so
  those calls no longer need a type assertion. Support is provider-specific.

- 81cd026: Reduce bundle size by making internal Zod v4 imports tree-shakeable.
- Updated dependencies [c477556]
- Updated dependencies [ad6a650]
- Updated dependencies [81cd026]
  - @ai-sdk/gateway@4.0.46
  - @ai-sdk/provider@4.0.7
  - @ai-sdk/provider-utils@5.0.25

## 7.0.57

### Patch Changes

- Updated dependencies [1937bef]
  - @ai-sdk/provider-utils@5.0.24
  - @ai-sdk/gateway@4.0.45

## 7.0.56

### Patch Changes

- 25c9120: Expose provider metadata on language-model-call end callbacks and telemetry spans.
- 89080c8: fix (ai/gateway): make retried `doStart` calls idempotent

  `generateVideo` retries `doStart`, which creates a billable generation, so a
  retry after a lost response could start a second one. It now mints one
  idempotency token per logical start — outside the retry closure — and forwards it
  as an `idempotency-key` header, so a provider that deduplicates (the Vercel AI
  Gateway does) sees the same key on every attempt. `GatewayVideoModel` simply
  forwards the caller's headers rather than inferring retry identity from an
  options object, which would collide across unrelated calls.

- 79d6195: Stop pending and active resumed chat streams after cancellation, and prevent
  overlapping resumptions from applying stale updates.
- Updated dependencies [89080c8]
- Updated dependencies [89080c8]
  - @ai-sdk/gateway@4.0.44

## 7.0.55

### Patch Changes

- 3469d0c: feat: add batch APIs
- Updated dependencies [3469d0c]
  - @ai-sdk/provider@4.0.6
  - @ai-sdk/gateway@4.0.43
  - @ai-sdk/provider-utils@5.0.23

## 7.0.54

### Patch Changes

- a6b17a2: Allow `ToolLoopAgent` `prepareCall` callbacks to read and override the top-level `reasoning` option.
- 5615eb7: Add `defaultInstructionsMiddleware` for applying default language model instructions while preserving call-level overrides.
- 36a3ff6: Preserve preceding assistant messages when regenerating a response.

## 7.0.53

### Patch Changes

- cd0177b: Filter unresolved tool approval requests and tool parts without state when ignoring incomplete tool calls.
- a09fdef: Release async iterable stream reader locks when source reads fail.
- Updated dependencies [7aeab10]
- Updated dependencies [2b60826]
  - @ai-sdk/gateway@4.0.42
  - @ai-sdk/provider-utils@5.0.22

## 7.0.52

### Patch Changes

- 3836a85: Skip re-validating tool input for terminal output-available UI message parts.
- Updated dependencies [1bec07d]
- Updated dependencies [53c326e]
- Updated dependencies [d765f82]
  - @ai-sdk/provider-utils@5.0.21
  - @ai-sdk/gateway@4.0.41

## 7.0.51

### Patch Changes

- Updated dependencies [160ccdb]
  - @ai-sdk/provider-utils@5.0.20
  - @ai-sdk/gateway@4.0.40

## 7.0.50

### Patch Changes

- 79e133c: async APIs for generateVideo (poll, webhook)

  Adds an asynchronous start/status flow to the experimental video model
  interface (`VideoModelV4`): models may now implement `doStart`, `doStatus`,
  and `handleWebhookOption` instead of (or in addition to) `doGenerate`, and
  `experimental_generateVideo` accepts `poll` and `webhook` options to
  orchestrate completion via polling or webhooks. Polling configuration can use
  a custom delay implementation for durable workflow compatibility.

- da64b51: feat(code-mode): simplify tool caller configuration
- Updated dependencies [79e133c]
  - @ai-sdk/provider@4.0.5
  - @ai-sdk/gateway@4.0.39
  - @ai-sdk/provider-utils@5.0.19

## 7.0.49

### Patch Changes

- Updated dependencies [fb6d2f8]
  - @ai-sdk/gateway@4.0.38

## 7.0.48

### Patch Changes

- Updated dependencies [bdd5e28]
  - @ai-sdk/gateway@4.0.37

## 7.0.47

### Patch Changes

- Updated dependencies [5fc7da5]
- Updated dependencies [93b2acd]
  - @ai-sdk/provider-utils@5.0.18
  - @ai-sdk/gateway@4.0.36

## 7.0.46

### Patch Changes

- Updated dependencies [4f2e064]
  - @ai-sdk/gateway@4.0.35

## 7.0.45

### Patch Changes

- d6ce0ee: feat(ai): support experimental_toolCallers in streamText
- fa95504: feat(ai): support experimental tool callers in ToolLoopAgent
- 349afe7: Warn when `generateText` receives streaming-only `firstChunkMs` or `chunkMs` timeout settings.
- Updated dependencies [fa95504]
  - @ai-sdk/provider-utils@5.0.17
  - @ai-sdk/gateway@4.0.34

## 7.0.44

### Patch Changes

- 015acb4: fix telemetry attribution for language model calls that resolve to a different response model

## 7.0.43

### Patch Changes

- b192878: feat: add experimental_toolCaller routing to generateText for code mode
- Updated dependencies [d8210b6]
- Updated dependencies [af3f400]
- Updated dependencies [b192878]
  - @ai-sdk/provider-utils@5.0.16
  - @ai-sdk/gateway@4.0.33

## 7.0.42

### Patch Changes

- 1659cd5: Prevent validated downloads on Node.js from reaching private or internal services through DNS aliases or DNS rebinding by validating and pinning every resolved address at connection time.
- 60f97f6: support overriding model call settings for individual `prepareStep` invocations
- 6a5bdff: Fix validated Node.js downloads when the HTTP connector requests a single DNS address.
- 6de2ec1: Preserve provider metadata from empty text deltas in `streamText`.
- Updated dependencies [1659cd5]
- Updated dependencies [6a5bdff]
- Updated dependencies [0012529]
  - @ai-sdk/provider-utils@5.0.15
  - @ai-sdk/gateway@4.0.32

## 7.0.41

### Patch Changes

- 2e2224b: Route the warning system information banner to stderr so it does not corrupt application output written to stdout.
- Updated dependencies [bf216b3]
  - @ai-sdk/gateway@4.0.31

## 7.0.40

### Patch Changes

- c3782a6: Deprecate `Experimental_GeneratedImage` in favor of `GeneratedFile`.

## 7.0.39

### Patch Changes

- 09a52cb: Promote the `repairText` option to stable on `generateObject` and `streamObject`, with a deprecated `experimental_repairText` alias for backwards compatibility.
- Updated dependencies [0c464d9]
- Updated dependencies [c49380c]
  - @ai-sdk/provider-utils@5.0.14
  - @ai-sdk/gateway@4.0.30

## 7.0.38

### Patch Changes

- 7bd6bdd: Avoid synthesizing client tool errors for invalid provider-executed tool calls.
- 1e2f324: feat: add experimental speech translation model specification (`Experimental_SpeechTranslationModelV4`) and `experimental_streamTranslate` for streaming speech-to-speech translation
- Updated dependencies [d9d2a11]
- Updated dependencies [1e2f324]
  - @ai-sdk/gateway@4.0.29
  - @ai-sdk/provider@4.0.4
  - @ai-sdk/provider-utils@5.0.13

## 7.0.37

### Patch Changes

- Updated dependencies [0a7c7f4]
  - @ai-sdk/gateway@4.0.28

## 7.0.36

### Patch Changes

- 7fa85b2: fix(ai): use injective serialization for tool approval HMAC payload

  The tool approval signature (`experimental_toolApprovalSecret`) built its HMAC
  payload by joining fields with `\n`. Because fields such as `toolName` and
  `toolCallId` can themselves contain a newline, distinct field tuples could
  serialize to identical bytes, allowing a signed approval to verify against a
  different tuple. The payload is now serialized with `JSON.stringify` (with a
  versioned domain-separation prefix), which escapes delimiter/control characters
  and makes the encoding injective.

  Verification remains backwards compatible: a signature in the old format still
  verifies, but only when no field contains the `\n` delimiter (the condition
  that made the old format ambiguous), so a pending approval that straddles an
  upgrade is not rejected while the collision stays closed.

## 7.0.35

### Patch Changes

- 7f6650b: Return response piping promises so callers can catch stream read and write errors.
- 106ea59: feat(ai): add per-step first content timeout for streaming generations
- Updated dependencies [2112ff1]
  - @ai-sdk/gateway@4.0.27

## 7.0.34

### Patch Changes

- Updated dependencies [7c16f21]
  - @ai-sdk/gateway@4.0.26

## 7.0.33

### Patch Changes

- 76cb673: fix: detect MP4 audio from its ftyp box during transcription
- e808fa5: fix(ai): preserve tool parts when tool call IDs repeat across steps
- 33647d7: Preserve provider options when combining consecutive tool messages.
- Updated dependencies [02ffdcb]
- Updated dependencies [76cb673]
  - @ai-sdk/provider-utils@5.0.12
  - @ai-sdk/gateway@4.0.25

## 7.0.32

### Patch Changes

- 6cd7c74: fix: correct the `onToolCall` callback result documentation
- e35bcae: Allow UI message chunks to include fields added by newer server versions.
- a4eb3f3: Propagate abort reasons when generation is cancelled during tool execution.
- Updated dependencies [cefa3b1]
- Updated dependencies [8fbb89c]
  - @ai-sdk/gateway@4.0.24

## 7.0.31

### Patch Changes

- 70f18c3: fix(ai): emit denied tool output state for client-rejected approvals
- cd06458: fix(ai): call `onInputStart` before `onInputAvailable` during non-streaming tool calls
- Updated dependencies [cd06458]
  - @ai-sdk/provider-utils@5.0.11
  - @ai-sdk/gateway@4.0.23

## 7.0.30

### Patch Changes

- Updated dependencies [341616a]
- Updated dependencies [70fc45c]
  - @ai-sdk/gateway@4.0.22

## 7.0.29

### Patch Changes

- Updated dependencies [7069785]
- Updated dependencies [4bf9ac2]
  - @ai-sdk/gateway@4.0.21

## 7.0.28

### Patch Changes

- 0bc8d4f: Fix chat `onFinish` handling when overlapping requests clear the active response before a resume stream finishes.

## 7.0.27

### Patch Changes

- ac01b79: Allow validating assistant UI messages with empty parts so persisted errored responses remain loadable.
- 2696562: `experimental_streamTranscribe` result promises now resolve without consuming `fullStream`: accessing any result promise consumes the stream internally. Previously `await result.text` alone deadlocked on transform backpressure. Because live transcription streams can be unbounded, `fullStream` is explicitly single-consumer (no replay buffering): access it once, before any result promise, when both stream parts and final results are needed.
- Updated dependencies [31c7be8]
- Updated dependencies [4d096f6]
  - @ai-sdk/provider-utils@5.0.10
  - @ai-sdk/gateway@4.0.20

## 7.0.26

### Patch Changes

- 27d294d: feat(ai): group orphaned tool calls after tool approvals under parent span

## 7.0.25

### Patch Changes

- 7805e4a: Cancelling the `experimental_streamTranscribe` `fullStream` now also aborts a still-pending `doStream` setup, so a model whose `doStream` has not yet resolved is cancelled instead of leaking.
- f8e82fd: Update the `experimental_streamTranscribe` unsupported-model error message now that gateway string model IDs can support streaming transcription.
- Updated dependencies [4be62c1]
- Updated dependencies [f8e82fd]
- Updated dependencies [7805e4a]
- Updated dependencies [cd12954]
  - @ai-sdk/provider-utils@5.0.9
  - @ai-sdk/gateway@4.0.19

## 7.0.24

### Patch Changes

- e193290: Cancel the caller's `audio` stream when `experimental_streamTranscribe` fails before or during streaming. Previously, when the model's `doStream` rejected before a stream existed (e.g. missing API key or other auth failure), the audio stream was never consumed or cancelled, so an upstream producer piping into it would hang forever.
- Updated dependencies [e193290]
  - @ai-sdk/provider-utils@5.0.8
  - @ai-sdk/gateway@4.0.18

## 7.0.23

### Patch Changes

- 930f949: feat(ai): wrap embedMany in tracing channel context
- Updated dependencies [867f80a]
  - @ai-sdk/gateway@4.0.17

## 7.0.22

### Patch Changes

- 8f89c25: Add the Cartesia provider with Sonic 3.5 speech generation, Ink-Whisper batch transcription, and Ink 2 realtime transcription support.

## 7.0.21

### Patch Changes

- 308a519: chore: enforce consistent imports from `zod/v4` instead of `zod`
- Updated dependencies [308a519]
- Updated dependencies [7fe53d2]
  - @ai-sdk/gateway@4.0.16

## 7.0.20

### Patch Changes

- b9ac19f: Flush compressed Node.js response chunks as they are piped so UI message and text streams remain incremental in Express and Next.js.
- a4186d6: Promote the `repairToolCall` option to stable, with a deprecated `experimental_repairToolCall` alias for backwards compatibility.

## 7.0.19

### Patch Changes

- be7f05a: Add `fingerprintTools` and `detectToolDrift` to detect MCP tool-definition drift ("rug pull"). Pin a tool set's server-controlled fields (string description, input schema, title) at trust time with `fingerprintTools`, then diff later fetches with `detectToolDrift` to catch injected descriptions or widened schemas before passing tools to the model. Baseline storage and the drift response remain the app's responsibility.
- ee55a07: Preserve tool approval signatures when approvals transition to responded.
- aad737d: Use own-property checks when resolving per-tool approvals so tool names and approval ids that match inherited object properties (e.g. `constructor`, `toString`, `valueOf`, `__proto__`) are treated as unconfigured/absent.

  - `@ai-sdk/policy-opa`: `wrapMcpTools` builds its per-tool map with a null prototype and reads supplied approvals via an own-property check, and `shadow` guards its per-tool map lookup the same way.
  - `ai`: tool and tool-context lookups keyed by a model- or client-supplied name now go through an own-property check (`getOwn`), so a name matching an inherited object property resolves to "no such tool"/"unconfigured" instead of a prototype value. This covers the approval path (per-tool approval resolution and replay re-validation) as well as tool-call parsing, execution, streaming callbacks, and UI message conversion/validation. The human-in-the-loop approval matching (`collectToolApprovals`) and streaming tool-name maps are built with a null prototype so a client-supplied id that matches an inherited property no longer slips past the "unknown approval" / "tool call not found" guards.

- 0f93c57: feat (video): support video (not just image) reference inputs in `inputReferences` for reference-to-video generation
- Updated dependencies [e12411e]
- Updated dependencies [5d894a7]
- Updated dependencies [fdb6d5d]
- Updated dependencies [0f93c57]
- Updated dependencies [d25a084]
  - @ai-sdk/gateway@4.0.15
  - @ai-sdk/provider@4.0.3
  - @ai-sdk/provider-utils@5.0.7

## 7.0.18

### Patch Changes

- Updated dependencies [ac306ed]
  - @ai-sdk/provider-utils@5.0.6
  - @ai-sdk/gateway@4.0.14

## 7.0.17

### Patch Changes

- Updated dependencies [cad8227]
  - @ai-sdk/gateway@4.0.13

## 7.0.16

### Patch Changes

- a8f9b6d: Preserve signed tool approval metadata when recording approval responses.

## 7.0.15

### Patch Changes

- Updated dependencies [0c3c7e4]
- Updated dependencies [c8d2726]
  - @ai-sdk/gateway@4.0.12

## 7.0.14

### Patch Changes

- 5c5c0f5: Add experimental streaming transcription support for transcription models, including OpenAI `gpt-realtime-whisper` and xAI WebSocket STT.
- Updated dependencies [5c5c0f5]
  - @ai-sdk/provider@4.0.2
  - @ai-sdk/provider-utils@5.0.5
  - @ai-sdk/gateway@4.0.11

## 7.0.13

### Patch Changes

- Updated dependencies [31abef7]
  - @ai-sdk/gateway@4.0.10

## 7.0.12

### Patch Changes

- ecfeb6f: Sort tool results by their tool call order when converting generation output to response messages.
- a193137: Fix `extractJsonMiddleware` preserving leading whitespace in the final streamed text suffix when no markdown fence prefix was stripped.
- Updated dependencies [c6f5e62]
  - @ai-sdk/gateway@4.0.9
  - @ai-sdk/provider-utils@5.0.4

## 7.0.11

### Patch Changes

- 0a87626: fix(ai): replace dynamic import() with loadBuiltinModule for diagnostics_channel to fix React Native/Hermes builds

## 7.0.10

### Patch Changes

- 8c616f0: feat(mcp): add maxRetries option for failed mcp tool calls
- Updated dependencies [8c616f0]
  - @ai-sdk/provider-utils@5.0.3
  - @ai-sdk/gateway@4.0.8

## 7.0.9

### Patch Changes

- Updated dependencies [2edc641]
- Updated dependencies [c18018c]
  - @ai-sdk/gateway@4.0.7

## 7.0.8

### Patch Changes

- 0274f34: feat (video): add first-class `frameImages` and `inputReferences` call options for video generation
- Updated dependencies [0274f34]
  - @ai-sdk/provider@4.0.1
  - @ai-sdk/gateway@4.0.6
  - @ai-sdk/provider-utils@5.0.2

## 7.0.7

### Patch Changes

- d598481: Fix: `convertToModelMessages` no longer emits an empty assistant message when a block contains only unknown data parts (e.g. a data part before `step-start` with no `convertDataPart` provided)

## 7.0.6

### Patch Changes

- 989402d: Add ToolLoopAgent types for deprecated tool call callback aliases.
- Updated dependencies [7e3c99e]
  - @ai-sdk/gateway@4.0.5

## 7.0.5

### Patch Changes

- a2750db: fix(ai): prune orphaned tool-approval responses in `pruneMessages`

  When pruning a specific tool by name (`toolCalls: [{ type, tools: [...] }]`), `pruneMessages` left the tool's `tool-approval-response` in place while removing its `tool-approval-request` and `tool-call`. The tool name of an approval response was resolved per-message, but approval responses live in a separate `tool` message from their approval request, so the name could never be resolved and the response was always kept. Tool name resolution is now done across all messages, so approval requests and responses are pruned together.

## 7.0.4

### Patch Changes

- Updated dependencies [6a436e3]
  - @ai-sdk/provider-utils@5.0.1
  - @ai-sdk/gateway@4.0.4

## 7.0.3

### Patch Changes

- Updated dependencies [728eaa0]
  - @ai-sdk/gateway@4.0.3

## 7.0.2

### Patch Changes

- Updated dependencies [9dce0a7]
  - @ai-sdk/gateway@4.0.2

## 7.0.1

### Patch Changes

- Updated dependencies [b2791b3]
- Updated dependencies [330f6e2]
  - @ai-sdk/gateway@4.0.1

## 7.0.0

### Major Changes

- 986c6fd: feat(ai): change type of experimental_context from unknown to generic
- b0c2869: chore(ai): remove deprecated `media` type part from `ToolResultOutput`
- 1949571: feat(ai): make experimental_telemetry stable
- 6542d93: feat(ai): change naming nomenclature for `*TelemetryIntegration` to `*Telemetry`
- 31f69de: fix(ai): carry prepareStep message overrides forward across steps
- 7c71ac6: fix(ai): limit response messages in StepResult to messages created in that step
- cf93359: feat(ai): remove/refactor event data sent via callbacks
- 776b617: feat(provider): adding new 'custom' content type
- 34bd95d: feat(ai): add support for uploading provider skills using the provider references abstraction
- 1f7db50: fix(ai): remove experimental_customProvider
- 3debdb7: feat(ai): rename `stepCountIs` to `isStepCount`
- fcc6869: refactor(ai/core): rename `ModelCallStreamPart` to `LanguageModelStreamPart` and align stream model call naming (`streamLanguageModelCall`, `experimental_streamLanguageModelCall`).

  This updates experimental low-level stream primitives to use "language model call" terminology consistently.

- ef992f8: Remove CommonJS exports from all packages. All packages are now ESM-only (`"type": "module"`). Consumers using `require()` must switch to ESM `import` syntax.
- 493295c: Remove the deprecated `ToolCallOptions` export.

  Use `ToolExecutionOptions` instead.

- 116c89f: feat(ai): remove telemetry data from the user-facing event data
- c29a26f: feat(provider): add support for provider references and uploading files as supported per provider
- 3887c70: feat(provider): add new top-level reasoning parameter to spec and support it in `generateText` and `streamText`
- 9bd6512: feat(provider): change file part data property to be tagged with a type and remove the image part type
- 4b46062: refactoring(ai): extract tool callback invocation into separate function and forward chunks before callback invocation
- 7e26e81: chore: rename experimental_context to context
- 8359612: Start v7 pre-release
- 5463d0d: feat(provider): align tool result output content file part types with top-level message file part types
- 72223e7: chore(ai): remove deprecated isToolOrDynamicToolUIPart function
- 57bf606: chore(ai): simplify unified telemetry creation
- b3c9f6a: feat(ai): create new opentelemetry package (@ai-sdk/otel)
- b9cf502: refactoring(ai): delay tool execution in stream text until model call is finished
- 5b8c58f: feat(ai): decouple otel from core functions
- 4e095b0: fix(ai): reject system messages in messages or prompt by default (opt-in)

### Patch Changes

- e3d9c0e: Add `allowSystemInMessages` option to `ToolLoopAgent`.

  This exposes the same option that exists on `streamText` and `generateText`, whether `role: "system"` messages are allowed in the `prompt` or `messages` fields. When unset, system messages are rejected because they can create a prompt injection attack risk. Ideally, use the `instructions` option instead. Set to `true` to allow system messages, or `false` to explicitly reject them.

  ```ts
  const agent = new ToolLoopAgent({
    model,
    allowSystemInMessages: true,
  });

  await agent.generate({
    messages: [
      { role: "system", content: "Server context" },
      { role: "user", content: "Hello" },
    ],
  });
  ```

  The option can also be returned from `prepareCall` for dynamic per-call configuration.

- b56301c: feat(ai): decouple otel from generate/streamObject
- 2427d88: feat(ai): change Tool.sensitiveContext to telemetry.includeToolsContext and make it opt-in
- 38fc777: Add AI Gateway hint to provider READMEs
- 023550e: Deprecate `streamText` result `fullStream` in favor of `stream`.
- 38ca8dc: fix(gateway): enable retry support for gateway errors
- 19736ee: feat(ai): rename onStepFinish to onStepEnd
- 6d76710: fix URL of hero animation in README
- 5ceed7d: fix(ai): doStream should reflect transformed values
- 4757690: feat(ai): rename onObjectStepFinish to onObjectStepEnd
- bc47739: chore(ai): cleanup telemetry event data
- d1b3786: fix(ai): deprecate properties on result that have moved to finalStep
- 382d53b: refactoring: rename context to runtimeContext
- ff9ce30: feat(ai): introduce experimental callbacks for embed function
- ee798eb: chore(provider-utils): rename `Experimental_Sandbox` to `Experimental_SandboxSession`
- 4873966: chore(ai): allow general usage of `logWarnings` and emit them via Node API when available
- e67d80e: fix: rename onFinish to onEnd
- 7bf7d7f: feat(ai): enable:true for telemetry by default
- 99bf941: feat(ai): extract streamModelCall function for streaming text generation
- e95e38d: fix: Make `generateText` and `streamText` result `usage` report total usage across all steps and deprecate `totalUsage`.
- 6a3793e: chore(ai): add optional ChatRequestOptions to `addToolApprovalResponse` and `addToolOutput`
- 5f3749c: refactoring: rename toolNeedsApproval to toolApproval
- 016e877: feat(ai): add `instructions` as the primary prompt option and deprecate `system`
- 2fe1099: feat(ai): emit streaming chunks throught the onChunk callback
- f319fde: feat(ai): validate tool context against contextSchema at runtime

  Tool execution and approval callbacks now validate each tool's `toolsContext` entry against its `contextSchema`. Invalid tool context now throws `TypeValidationError` with tool-context validation metadata in `error.context`.

- 31ee822: refactoring(ai): extract filterActiveTools and expose it as experimental_filterActiveTools
- b67525f: feat: instructions as prepareStep input
- e68be55: fix(ai): skip stringifying text when streaming partial text
- 1db29c8: feat(ai): break `CallSettings` apart into `LanguageModelCallOptions` and `RequestOptions`
- 0a51f7d: fix(ai): enforce `callOptionsSchema` at runtime in `ToolLoopAgent`

  `ToolLoopAgentSettings.callOptionsSchema` was declared and documented as a runtime schema for `options`, but `tool-loop-agent.ts` never invoked it. Any invariant a developer encoded in the schema was silently bypassed at runtime, and unchecked `options` flowed straight into `prepareCall` and any `instructions` template that interpolated them.

  `ToolLoopAgent.prepareCall` now validates caller-supplied `options` against `callOptionsSchema` (when set) via `safeValidateTypes`, throwing `InvalidArgumentError` on failure before forwarding to `prepareCall` / `generateText` / `streamText`.

- d1a8bed: fix(ui): export `isDynamicToolUIPart` from `ai` package
- bcce2dd: feat(stream-text): expose standalone stream transformation helpers and deprecate the equivalent `streamText` result methods.

  The new `toUIMessageChunk` and `toUIMessageStream` helpers let you convert a `streamText` `stream` (or any compatible `ReadableStream<TextStreamPart<TOOLS>>`) into UI message chunks without going through the result object — useful for custom transports, tests, and other producers of `TextStreamPart`.

  `result.toUIMessageStreamResponse(options)` and `result.pipeUIMessageStreamToResponse(response, options)` can migrate by passing `toUIMessageStream({ stream: result.stream, ...options })` to `createUIMessageStreamResponse` or `pipeUIMessageStreamToResponse`.

  The new `toTextStream` helper extracts text deltas from a `streamText` `stream`, so `result.toTextStreamResponse(options)` and `result.pipeTextStreamToResponse(response, options)` can migrate to `createTextStreamResponse({ stream: toTextStream({ stream: result.stream }), ...options })` and `pipeTextStreamToResponse({ response, stream: toTextStream({ stream: result.stream }), ...options })`.

  `result.toUIMessageStream`, `result.toUIMessageStreamResponse`, `result.pipeUIMessageStreamToResponse`, `result.toTextStreamResponse`, and `result.pipeTextStreamToResponse` are now `@deprecated`. They still work in v7 and will be removed in the next major release. Migration snippets are in the v6 → v7 migration guide.

- 2a74d43: Remove the deprecated `experimental_prepareStep` option from `generateText`.

  Use `prepareStep` instead.

- 71d3022: fix(ai): unify generate text event callbacks
- 6cca112: feat: add timeBetweenOutputTokensMs stats
- fd4f578: fix(ai): exclude request and response bodies from text generation results by default to reduce memory usage.
- 511902c: skip validation for tool parts in terminal states when tool schema is no longer registered
- a5018ab: fix(ai): return schema-transformed elements in array output mode

  Previously final array output validation checked each element against the schema but returned the raw model output. Array output now returns the validated values so Zod transforms, coercions, defaults, and pipes are applied consistently with object output.

- 531251e: fix(security): validate redirect targets in download functions to prevent SSRF bypass

  Both `downloadBlob` and `download` now validate the final URL after following HTTP redirects, preventing attackers from bypassing SSRF protections via open redirects to internal/private addresses.

- eeefc3f: fix(ai): enforce `timeout.stepMs` for the whole step in `streamText`

  Previously `streamText`'s step timer was cleared synchronously right after the step's stream was registered, before the stream produced anything, so `stepMs` never aborted a step that stalled before emitting content. The step timer now survives until the step's stream finishes or aborts, matching `generateText`. `chunkMs`/`totalMs` and normal step-finish cleanup are unchanged.

- ec98264: feat(ai): allow multiple integrations to be registered at once
- 43a6750: fix(ai): preserve `allowSystemInMessages` across `streamText` retries
- 67df0a0: feat: add sensitiveContext property to Tool
- b79b6a8: fix(ai): add approval guard for denied tool outputs
- 81caa5d: fix(ai): remove ExtractLiteralUnion export
- 4181cfe: fix(ai): harden `getMediaTypeFromUrl` against prototype-property collisions

  `getMediaTypeFromUrl` (used to infer media types for `file-url` / `image-url` parts) used `ext in URL_EXTENSION_TO_MEDIA_TYPE` against a plain object literal. A URL ending in `.constructor` therefore resolved through the prototype chain and returned the `Object` constructor function, violating the helper's `: string` return type and forwarding a non-string value to provider adapters.

  Switch to `Object.hasOwn(...)` so attacker-controlled extensions like `.constructor` cannot resolve to inherited `Object.prototype` keys.

- 208d045: fix(ai): skip global telemetry registration when local integration defined
- 5a6f514: feat(ai): support several tools in hasToolCall stop condition
- ed74dae: fix(ui): make `input` optional on `output-error` tool and dynamic-tool UI message parts

  `validateUIMessages` rejected persisted assistant messages whose `output-error` tool parts had no `input` key. This happened for any errored tool call where the SDK set `input: undefined` (e.g. `NoSuchToolError` / `InvalidToolInputError`): JSON serialization stripped the `undefined` value, and Zod 4.4+ treats a missing `z.unknown()` key as a validation failure (previously it was implicitly optional). The schema now matches the runtime shape produced by `process-ui-message-stream`, so reloading a thread that contains an errored tool call no longer throws `AI_TypeValidationError`.

- ca99fea: feat: expose `finalStep` on text generation results
- 9b47dea: fix(ai): remove otel Tracer api from telemetry settings
- 877bf12: fix(ai): flatten model attributes for telemetry
- eea8d98: refactoring: rename tool execution events
- d66ae02: Return validated elements from generateText array output
- 5d0f18e: feat(ai): move opentelemetry to new package
- 21d3d60: feat(harness): implement harness specification
- 1582efa: chore(ai): remove the metadata field from the telemetry settings
- 80d4dde: fix(ai): include tool input on tool result for provider executed dynamic tools
- 98627e5: feat(ai): remove onChunk event from telemetry
- 51ce232: feat(ai): add sensitiveRuntimeContext option
- 82fc0ab: fix(ai): pass all stream text parts to `onChunk`
- 1f509d4: fix(ai): force template check on 'kind' param
- ca446f8: feat: flexible tool descriptions
- 176466a: chore(provider): align V4 model return types to have their own definitions across all model interfaces
- c0c8ca2: fix(ai): remove deprecated LanguageModelUsage properties
- 75763b0: agents: tag outgoing requests with an ai-sdk-agent user-agent segment for usage attribution (tool-loop, workflow)
- 6ec57f5: feat(ai): make the experimental lifecycle callbacks stable
- 3ae1786: fix: better context type inference
- a7de9c9: fix: make sandbox experimental
- caf1b6f: feat(ai): introduce experimental callbacks for rerank function
- 9f0e36c: trigger release for all packages after provenance setup
- befb78c: refactoring: remove real-time delays in unit tests
- 6866afe: fix(ai): fix `lastAssistantMessageIsCompleteWithApprovalResponses` to no longer ignore `providerExecuted` tool approvals
- 29d8cf4: feat(ai): rename the core-event types
- 2e17091: fix(types): move shared tool set utility types into provider-utils

  Moved `ToolSet`, `InferToolSetContext`, and `UnionToIntersection` into `@ai-sdk/provider-utils` and updated `ai` internals to import them directly from there. This keeps the shared tool typing utilities colocated with the core tool type definitions.

- 210ed3d: feat(ai): pass result provider metadata across the stream
- a3fd75b: feat(ai): expose Experimental_ModelCallStreamPart type
- f4cc8eb: feat: add performance statistics
- 2add429: fix(ai): skip passing invalid JSON inputs to response messages
- 5588abd: feat(ai): add experimental_refineToolInput option to ToolLoopAgent, generateText, streamText
- e80ada0: fix(ai): download tool-result file URLs
- 58a2ad7: fix: more precise default message for tool execution denial
- 62d6481: Post-publish release notifications now link to each package’s GitHub release and npm page.
- 1fe058b: fix(anthropic): preserve the error code returned by model
- 5c4d910: feat(ai): add new `isLoopFinished` stop condition helper for unlimited steps
- e4182bd: chore: rm export of OutputInterface
- 34fd051: feat(ai): add toolMs to timeout configuration
- 72cb801: feat(ai): concurrent event notification
- 2e98477: fix: retain stack traces on async errors
- add1126: refactoring: executeTool uses tool as parameter
- 81a284b: fix(ai): handle partial unicode escapes in fixJson
- 76fd58c: fix: consider file outputs and tool calls for time to first output
- 7392266: feat: move includeRawChunks to include.rawChunks
- 69aeb0e: feat: add deprecated tool call lifecycle callback aliases for AI SDK 6 compatibility.
- 37d69b2: feat(ai): access runtime context in tool approval functions
- 1043274: feat(ai): add a ModelCall start/end event
- 350ea38: refactoring: introduce Arrayable type
- 7f59f04: feat(ai): add approval reason to automatic tool approvals
- 7677c1e: feat(ai): allow tool approval functions to return undefined
- 476e1ca: feat(ai): remove telemetry dependency on onChunk callback
- 008271d: feat(openai-compatible): emit warning when using kebab-case instead of camelCase
- 7fc6bd6: Raise minimum supported Node.js version to 22. Supported versions: 22, 24, and 26.
- 594029e: feat(ai): wrap the model call in telemetry context
- 426dbbb: fix(ai): reject `streamText` result promises with `NoOutputGeneratedError` when the model stream ends without producing any output. Previously such streams resolved with an empty step. Incomplete streams with partial output still resolve with the partial result.
- 25a64f8: Remove deprecated experimental generateImage exports.
- 75ef93e: remove the deprecated `experimental_output` alias and document the `output` migration for AI SDK 7
- c26ca8d: Remove custom User-Agent header from HttpChatTransport to fix CORS preflight failures in Safari and Firefox
- eaf849f: Rename rerank telemetry finish callback to `onRerankEnd`.
- 664a0eb: feat (ai/core): support plain string model IDs in `rerank()` function

  The `rerank()` function now accepts plain model strings (e.g., `'cohere/rerank-v3.5'`) in addition to `RerankingModel` objects, matching the behavior of `generateText`, `embed`, and other core functions.

- 08d2129: feat(mcp): propagate the server name through dynamic tool parts
- 5faf71c: feat: introduce responseMessages on GenerateTextResult and StreamTextResult
- 0c4c275: trigger initial canary release
- 118b953: feat(ai): decouple otel from embed functions
- 6fd51c0: fix(provider): preserve error type prefix in getErrorMessage
- 1dca341: fix: rename telemetry onFinish to onEnd
- ebd4da2: feat(ai): add missing usage attributes
- bc67b4f: feat(ai): add experimental callbacks for structured outputs
- f0b0b20: feat(ai): add per-tool timeout overrides via toolTimeouts
- 2852a84: fix(ai): make input optional on input-streaming UIMessagePart variants
- 2a9c144: feat(ai): add toolNeedsApproval option
- ce769dd: feat(provider): add experimental Realtime API support for voice conversations

  Adds first-class support for realtime (speech-to-speech) APIs:

  - `Experimental_RealtimeModelV4` spec in `@ai-sdk/provider` with normalized event types and factory
  - OpenAI, Google, and xAI realtime provider implementations
  - `openai.experimental_realtime()` / `google.experimental_realtime()` / `xai.experimental_realtime()` work in both server and browser
  - `.getToken()` static method on each provider for server-side ephemeral token creation
  - `experimental_getRealtimeToolDefinitions` helper for provider session tool definitions
  - `experimental_useRealtime` hook in `@ai-sdk/react` returning `UIMessage[]` (aligned with `useChat`), with `onToolCall` and `addToolOutput` for client-driven tool execution
  - `inputAudioTranscription` session config for showing transcribed user audio messages when supported by the provider

- e3a0419: fix(ai): default missing embedding warnings to an empty array
- f04adcb: feat(ai): refresh `customProvider` and `createProviderRegistry` to support file and skill upload abstractions
- 876fd3e: fix(ai): limit tool execution time duration to actual tool execution
- e311194: feat(ai): allow passing provider instance to `uploadFile` and `uploadSkill` as shorthand
- 989d3d2: fix(ai): include generated files in OTEL response attributes
- b5092f5: fix(ai): do not re-validate tool input for output-error parts in validateUIMessages
- 6dd6b83: feat(ai): change sensitiveRuntimeContext to telemetry.includeRuntimeContext and make it opt-in
- 69254e0: feat(ai): add toolMetadata for tool specific metdata
- 79b2468: feat: add request.messages to StepResult
- 6c93e36: feat(provider-utils): add `spawnCommand` method to `Experimental_Sandbox` to allow for detached command execution
- 2605e5f: fix test mocks to return the first array-backed result on the first call
- 258c093: chore: ensure consistent import handling and avoid import duplicates or cycles
- f58f9bc: fix(ai): remove stopWhen from onStart event
- 8565dcb: fix: rename onEmbedFinish to onEmbedEnd
- 6abd098: split `prepareToolsAndToolChoice()` into `prepareTools()` and `prepareToolChoice()`
- e1bfb9c: feat(ai): remove unnecessary data from events
- 375fdd7: fix: harden download URL SSRF guard against hostname and redirect bypasses

  `validateDownloadUrl` and the file download helpers (`downloadBlob`, `download`) could be bypassed in several ways when handling untrusted URLs:

  - A fully-qualified hostname with a trailing dot (e.g. `localhost.`, `myhost.local.`) skipped the localhost/`.local` blocklist.
  - IPv6 addresses that embed an IPv4 address in their last 32 bits — IPv4-compatible (`::127.0.0.1`), IPv4-translated (`::ffff:0:127.0.0.1`), and NAT64 (`64:ff9b::127.0.0.1`, including the `64:ff9b:1::/48` local-use prefix) — were not decoded and checked against the private IPv4 ranges.
  - Redirects were validated only _after_ `fetch` had already followed them, so the request to a redirect target (e.g. an internal/metadata address) had already been issued before the check ran.
  - Several reserved/internal address ranges were not blocked: CGNAT (`100.64.0.0/10`, used by some cloud providers for internal traffic), benchmarking (`198.18.0.0/15`), IETF protocol assignments (`192.0.0.0/24`), the reserved `240.0.0.0/4` block (including the `255.255.255.255` broadcast address), and IPv6 site-local (`fec0::/10`) and multicast (`ff00::/8`).

  The validator now strips trailing dots before the hostname checks and fully expands IPv6 addresses to detect embedded private IPv4 targets. The download helpers now follow redirects manually (`redirect: 'manual'`), re-validating each hop before requesting it, so an unsafe redirect target is never fetched. When a redirect cannot be inspected because the runtime returns an opaque response, the helpers fail closed (reject the redirect) on the server; only in a real browser — where SSRF is not reachable (fetch is constrained by CORS and cannot reach a server's internal network or cloud-metadata endpoints) — is the redirect followed natively so legitimate redirected downloads keep working.

- 89ad56f: Promote `generateSpeech` and `SpeechResult` to stable exports.
- f9a496f: Promote `transcribe` and `TranscriptionResult` to stable exports, with deprecated experimental aliases for backwards compatibility.
- 334ae5d: Update step performance metrics with explicit effective, input, output, and total token throughput fields.
- 3295831: Harden stream text processing and middleware against prototype pollution from stream part IDs.
- b097c52: feat(ai): use tracing channels to track parent-child context
- e79e644: chore(ai/core): remove `timeout` from `CallSettings` as it was effectively unused there
- 3015fc3: feat: sandbox shell execution abstraction
- b8396f0: trigger initial beta release
- 48e92f3: feat: make include stable
- 33d099c: fix(ai): omit reasoning-start/end when sendReasoning is false
- e87d71b: feat(ai): support automatic tool approval in ui messages
- a6617c5: feat(provider-utils): add `readFile` and `writeFile` plus convenience wrappers to `Experimental_Sandbox` abstraction
- eee1166: feat(ai): expose initial and response messages in prepareStep
- 9d486aa: feat(ai): generic tool approval function
- c3d4019: chore(ai): rename 'TelemetrySettings' to 'TelemetryOptions'
- 28dfa06: fix: support tools with optional context
- bcacd48: fix(ai): accumulative properties on StreamTextResult, GenerateTextResult
- e92fc45: feat(ai): introduce onAbort hook to close telemetry spans
- 083947b: feat(ai): separate toolsContext from context
- 47e65d6: fix(ai): tag step/chunk timeout aborts with `TimeoutError` reason

  When `timeout: { stepMs }` or `timeout: { chunkMs }` fires, the abort reason is now a `TimeoutError` `DOMException`, matching what `AbortSignal.timeout()` produces natively. Consumers can distinguish a framework timeout from a user-initiated cancel via `signal.reason.name === 'TimeoutError'`.

- 6a2caf9: Serialize `undefined` tool output to `null` in UI message chunks
- 202f107: feat(ai): create a diagnostics channel to push event data
- bae5e2b: fix(security): re-validate tool approvals from client message history before execution

  The approval-replay path in `generateText`/`streamText` (and `WorkflowAgent.stream`) reconstructed approved tool calls from the client-supplied messages array and executed them without re-validating input against the tool's schema or re-applying the approval policy. A client could forge an assistant message with a pre-approved tool-call part and have the server execute a tool with attacker-chosen arguments.

  The replay path now validates HMAC signature (when `experimental_toolApprovalSecret` is configured), re-validates tool-call input against the tool's input schema, and re-resolves the approval policy before execution.

- c907622: Add a `toolOrder` option to control the order in which tools are sent to provider APIs.
- 90e2d8a: chore: fix unused vars not being flagged by our lint tooling
- c4f4b5f: refactoring(ai): remove deprecated experimental_activeTools option
- f4cfccd: feat(ai): decouple otel from rerank function
- f5a6f89: README updates
- f18b08f: fix: redact server error details from UI message streams by default

  `toUIMessageStream`, `createUIMessageStream`, and `toUIMessageChunk` defaulted their `onError` callback to `getErrorMessage`, which serializes the raw error (`error.toString()` / `JSON.stringify(error)`) into the client-facing `{ type: 'error', errorText }` chunk — and also into `tool-output-error` parts. The documented default was `() => 'An error occurred.'`, so applications relying on the documented behavior were unknowingly streaming server exception details (internal hostnames, paths, provider request data, validation inputs) to end users.

  The default `onError` now returns the documented generic `'An error occurred.'`. Raw error details are only emitted when the developer explicitly supplies an `onError` handler. This also redacts `tool-output-error` and invalid-tool-input error text by default; pass an `onError` to surface richer messages.

- 7fd3360: Harden UI message stream processing against prototype pollution from chunk IDs.
- 0416e3e: feat (video): add first-class `generateAudio` call option
- d775a57: feat: introduce Instructions type
- b4507d5: fix(provider-utils): cancel response body on download rejection to prevent socket leak

  When a download was rejected early — because the `Content-Length` header exceeded the size limit, the response status was not ok, or a redirect resolved to a blocked URL — the fetch response body was left unconsumed and uncancelled. With WHATWG Fetch/undici this leaves the underlying TCP socket open instead of returning it to the connection pool, allowing an attacker-controlled origin to exhaust file descriptors and cause a denial of service. The body is now cancelled on all early-rejection paths in `readResponseWithSizeLimit`, `download`, and `downloadBlob`, and `fetchWithValidatedRedirects` cancels each redirect hop's body before following or rejecting the next hop.

- 6147cdf: fix(ai): fix auto-complete on provider registry and custom provider
- e93fa91: rename Sandbox.executeCommand to Sandbox.runCommand
- f32c750: refactoring(ai): simplify mergeAbortSignals
- 7dbf992: feat(ai): allow prepareStep to override sandbox per step
- 9b0bc8a: fix(mcp): prevent prototype pollution by using secureJsonParse
- 4bb4dbc: feat: introduce include.requestMessage option for step request message storage opt-in
- c22750c: fix(ai): move onToolExecutionStart and onToolExecutionEnd to stable
- 538c12b: feat: use instructions on ToolCallRepairFunction, parseToolCall, and events
- fc92055: feat(ai): automatic tool approval
- f372547: fix(ai): fix `providerExecuted` tool approvals being passed to language model twice
- 1e4b350: Honor `tool.toModelOutput` in `WorkflowAgent`.

  `WorkflowAgent` now routes successful local, provider-executed, and approved tool results through each tool's optional `toModelOutput` hook, matching `generateText`, `streamText`, and `ToolLoopAgent`. Previously the hook was ignored and results were always serialized as `text` or `json`.

  Internally exports the shared tool-result model-output helpers from `ai/internal`, and uses the shared `getErrorMessage` behavior for workflow tool error results.

- 69d7128: fix(workflow): reuse the core tool-approval validation in WorkflowAgent

  `WorkflowAgent.stream` previously reconstructed approved tool calls with a copy of the core collection logic and validated them inline. Because the logic was duplicated, it could drift from the hardened `generateText`/`streamText` implementation. WorkflowAgent now collects approvals via the shared `collectToolApprovals` and re-validates each one through the shared `validateApprovedToolApprovals` (input-schema re-validation, HMAC signature verification when configured, and approval-policy re-resolution) in addition to its existing `needsApproval` guard, so a client-forged approval cannot execute a tool with unvalidated input. The duplicated collector was removed; `collectToolApprovals` and `validateApprovedToolApprovals` are now exported from `ai/internal`.

- ff5eba1: feat: roll `image-*` tool output types into their equivalent `file-*` types
- cc6ab90: feat(ai): rename ui message stream onFinish to onEnd
- e27ed76: feat(devtools): add new devtools integration for telemetry

## 7.0.0-beta.187

### Patch Changes

- Updated dependencies [77cc1af]
  - @ai-sdk/gateway@4.0.0-beta.114

## 7.0.0-beta.186

### Patch Changes

- Updated dependencies [eb024b6]
  - @ai-sdk/gateway@4.0.0-beta.113

## 7.0.0-beta.185

### Patch Changes

- 75763b0: agents: tag outgoing requests with an ai-sdk-agent user-agent segment for usage attribution (tool-loop, workflow)

## 7.0.0-beta.184

### Patch Changes

- 0416e3e: feat (video): add first-class `generateAudio` call option
- Updated dependencies [a403276]
- Updated dependencies [0416e3e]
  - @ai-sdk/gateway@4.0.0-beta.112
  - @ai-sdk/provider@4.0.0-beta.20
  - @ai-sdk/provider-utils@5.0.0-beta.50

## 7.0.0-beta.183

### Patch Changes

- Updated dependencies [8e990ff]
  - @ai-sdk/gateway@4.0.0-beta.111

## 7.0.0-beta.182

### Patch Changes

- cc6ab90: feat(ai): rename ui message stream onFinish to onEnd

## 7.0.0-beta.181

### Patch Changes

- 6a2caf9: Serialize `undefined` tool output to `null` in UI message chunks

## 7.0.0-beta.180

### Patch Changes

- 81a284b: fix(ai): handle partial unicode escapes in fixJson

## 7.0.0-beta.179

### Patch Changes

- Updated dependencies [987d9e4]
  - @ai-sdk/gateway@4.0.0-beta.110

## 7.0.0-beta.178

### Patch Changes

- b097c52: feat(ai): use tracing channels to track parent-child context
- Updated dependencies [15eb253]
  - @ai-sdk/gateway@4.0.0-beta.109

## 7.0.0-beta.177

### Patch Changes

- b8396f0: trigger initial beta release
- Updated dependencies [b8396f0]
  - @ai-sdk/gateway@4.0.0-beta.108
  - @ai-sdk/provider-utils@5.0.0-beta.49
  - @ai-sdk/provider@4.0.0-beta.19

## 7.0.0-canary.176

### Patch Changes

- Updated dependencies [d5b8263]
  - @ai-sdk/gateway@4.0.0-canary.107

## 7.0.0-canary.175

### Patch Changes

- 6ec57f5: feat(ai): make the experimental lifecycle callbacks stable

## 7.0.0-canary.174

### Patch Changes

- Updated dependencies [ca2cf45]
  - @ai-sdk/gateway@4.0.0-canary.106

## 7.0.0-canary.173

### Patch Changes

- Updated dependencies [efec111]
  - @ai-sdk/gateway@4.0.0-canary.105

## 7.0.0-canary.172

### Patch Changes

- 25a64f8: Remove deprecated experimental generateImage exports.
- 375fdd7: fix: harden download URL SSRF guard against hostname and redirect bypasses

  `validateDownloadUrl` and the file download helpers (`downloadBlob`, `download`) could be bypassed in several ways when handling untrusted URLs:

  - A fully-qualified hostname with a trailing dot (e.g. `localhost.`, `myhost.local.`) skipped the localhost/`.local` blocklist.
  - IPv6 addresses that embed an IPv4 address in their last 32 bits — IPv4-compatible (`::127.0.0.1`), IPv4-translated (`::ffff:0:127.0.0.1`), and NAT64 (`64:ff9b::127.0.0.1`, including the `64:ff9b:1::/48` local-use prefix) — were not decoded and checked against the private IPv4 ranges.
  - Redirects were validated only _after_ `fetch` had already followed them, so the request to a redirect target (e.g. an internal/metadata address) had already been issued before the check ran.
  - Several reserved/internal address ranges were not blocked: CGNAT (`100.64.0.0/10`, used by some cloud providers for internal traffic), benchmarking (`198.18.0.0/15`), IETF protocol assignments (`192.0.0.0/24`), the reserved `240.0.0.0/4` block (including the `255.255.255.255` broadcast address), and IPv6 site-local (`fec0::/10`) and multicast (`ff00::/8`).

  The validator now strips trailing dots before the hostname checks and fully expands IPv6 addresses to detect embedded private IPv4 targets. The download helpers now follow redirects manually (`redirect: 'manual'`), re-validating each hop before requesting it, so an unsafe redirect target is never fetched. When a redirect cannot be inspected because the runtime returns an opaque response, the helpers fail closed (reject the redirect) on the server; only in a real browser — where SSRF is not reachable (fetch is constrained by CORS and cannot reach a server's internal network or cloud-metadata endpoints) — is the redirect followed natively so legitimate redirected downloads keep working.

- f18b08f: fix: redact server error details from UI message streams by default

  `toUIMessageStream`, `createUIMessageStream`, and `toUIMessageChunk` defaulted their `onError` callback to `getErrorMessage`, which serializes the raw error (`error.toString()` / `JSON.stringify(error)`) into the client-facing `{ type: 'error', errorText }` chunk — and also into `tool-output-error` parts. The documented default was `() => 'An error occurred.'`, so applications relying on the documented behavior were unknowingly streaming server exception details (internal hostnames, paths, provider request data, validation inputs) to end users.

  The default `onError` now returns the documented generic `'An error occurred.'`. Raw error details are only emitted when the developer explicitly supplies an `onError` handler. This also redacts `tool-output-error` and invalid-tool-input error text by default; pass an `onError` to surface richer messages.

- b4507d5: fix(provider-utils): cancel response body on download rejection to prevent socket leak

  When a download was rejected early — because the `Content-Length` header exceeded the size limit, the response status was not ok, or a redirect resolved to a blocked URL — the fetch response body was left unconsumed and uncancelled. With WHATWG Fetch/undici this leaves the underlying TCP socket open instead of returning it to the connection pool, allowing an attacker-controlled origin to exhaust file descriptors and cause a denial of service. The body is now cancelled on all early-rejection paths in `readResponseWithSizeLimit`, `download`, and `downloadBlob`, and `fetchWithValidatedRedirects` cancels each redirect hop's body before following or rejecting the next hop.

- Updated dependencies [8c17bf8]
- Updated dependencies [aeda373]
- Updated dependencies [558777f]
- Updated dependencies [375fdd7]
- Updated dependencies [b4507d5]
  - @ai-sdk/gateway@4.0.0-canary.104
  - @ai-sdk/provider-utils@5.0.0-canary.48

## 7.0.0-canary.171

### Patch Changes

- 89ad56f: Promote `generateSpeech` and `SpeechResult` to stable exports.
- f9a496f: Promote `transcribe` and `TranscriptionResult` to stable exports, with deprecated experimental aliases for backwards compatibility.
- 3295831: Harden stream text processing and middleware against prototype pollution from stream part IDs.

## 7.0.0-canary.170

### Patch Changes

- bae5e2b: fix(security): re-validate tool approvals from client message history before execution

  The approval-replay path in `generateText`/`streamText` (and `WorkflowAgent.stream`) reconstructed approved tool calls from the client-supplied messages array and executed them without re-validating input against the tool's schema or re-applying the approval policy. A client could forge an assistant message with a pre-approved tool-call part and have the server execute a tool with attacker-chosen arguments.

  The replay path now validates HMAC signature (when `experimental_toolApprovalSecret` is configured), re-validates tool-call input against the tool's input schema, and re-resolves the approval policy before execution.

- 69d7128: fix(workflow): reuse the core tool-approval validation in WorkflowAgent

  `WorkflowAgent.stream` previously reconstructed approved tool calls with a copy of the core collection logic and validated them inline. Because the logic was duplicated, it could drift from the hardened `generateText`/`streamText` implementation. WorkflowAgent now collects approvals via the shared `collectToolApprovals` and re-validates each one through the shared `validateApprovedToolApprovals` (input-schema re-validation, HMAC signature verification when configured, and approval-policy re-resolution) in addition to its existing `needsApproval` guard, so a client-forged approval cannot execute a tool with unvalidated input. The duplicated collector was removed; `collectToolApprovals` and `validateApprovedToolApprovals` are now exported from `ai/internal`.

- Updated dependencies [bae5e2b]
  - @ai-sdk/provider-utils@5.0.0-canary.47
  - @ai-sdk/gateway@4.0.0-canary.103

## 7.0.0-canary.169

### Patch Changes

- a5018ab: fix(ai): return schema-transformed elements in array output mode

  Previously final array output validation checked each element against the schema but returned the raw model output. Array output now returns the validated values so Zod transforms, coercions, defaults, and pipes are applied consistently with object output.

- 21d3d60: feat(harness): implement harness specification
- 426dbbb: fix(ai): reject `streamText` result promises with `NoOutputGeneratedError` when the model stream ends without producing any output. Previously such streams resolved with an empty step. Incomplete streams with partial output still resolve with the partial result.
- 7fd3360: Harden UI message stream processing against prototype pollution from chunk IDs.

## 7.0.0-canary.168

### Patch Changes

- 1e4b350: Honor `tool.toModelOutput` in `WorkflowAgent`.

  `WorkflowAgent` now routes successful local, provider-executed, and approved tool results through each tool's optional `toModelOutput` hook, matching `generateText`, `streamText`, and `ToolLoopAgent`. Previously the hook was ignored and results were always serialized as `text` or `json`.

  Internally exports the shared tool-result model-output helpers from `ai/internal`, and uses the shared `getErrorMessage` behavior for workflow tool error results.

- Updated dependencies [a3bb04a]
  - @ai-sdk/gateway@4.0.0-canary.102

## 7.0.0-canary.167

### Patch Changes

- 4757690: feat(ai): rename onObjectStepFinish to onObjectStepEnd
- eeefc3f: fix(ai): enforce `timeout.stepMs` for the whole step in `streamText`

  Previously `streamText`'s step timer was cleared synchronously right after the step's stream was registered, before the stream produced anything, so `stepMs` never aborted a step that stalled before emitting content. The step timer now survives until the step's stream finishes or aborts, matching `generateText`. `chunkMs`/`totalMs` and normal step-finish cleanup are unchanged.

- b79b6a8: fix(ai): add approval guard for denied tool outputs
- Updated dependencies [6b4d325]
  - @ai-sdk/gateway@4.0.0-canary.101

## 7.0.0-canary.166

### Patch Changes

- 19736ee: feat(ai): rename onStepFinish to onStepEnd
- d66ae02: Return validated elements from generateText array output
- e4182bd: chore: rm export of OutputInterface
- Updated dependencies [24bb123]
- Updated dependencies [c44fcc8]
- Updated dependencies [97e480a]
  - @ai-sdk/gateway@4.0.0-canary.100

## 7.0.0-canary.165

### Patch Changes

- ce769dd: feat(provider): add experimental Realtime API support for voice conversations

  Adds first-class support for realtime (speech-to-speech) APIs:

  - `Experimental_RealtimeModelV4` spec in `@ai-sdk/provider` with normalized event types and factory
  - OpenAI, Google, and xAI realtime provider implementations
  - `openai.experimental_realtime()` / `google.experimental_realtime()` / `xai.experimental_realtime()` work in both server and browser
  - `.getToken()` static method on each provider for server-side ephemeral token creation
  - `experimental_getRealtimeToolDefinitions` helper for provider session tool definitions
  - `experimental_useRealtime` hook in `@ai-sdk/react` returning `UIMessage[]` (aligned with `useChat`), with `onToolCall` and `addToolOutput` for client-driven tool execution
  - `inputAudioTranscription` session config for showing transcribed user audio messages when supported by the provider

- Updated dependencies [ce769dd]
  - @ai-sdk/provider@4.0.0-canary.18
  - @ai-sdk/gateway@4.0.0-canary.99
  - @ai-sdk/provider-utils@5.0.0-canary.46

## 7.0.0-canary.164

### Patch Changes

- Updated dependencies [9876183]
  - @ai-sdk/gateway@4.0.0-canary.98

## 7.0.0-canary.163

### Patch Changes

- ee798eb: chore(provider-utils): rename `Experimental_Sandbox` to `Experimental_SandboxSession`
- c907622: Add a `toolOrder` option to control the order in which tools are sent to provider APIs.
- Updated dependencies [ee798eb]
- Updated dependencies [daf6637]
  - @ai-sdk/provider-utils@5.0.0-canary.45
  - @ai-sdk/gateway@4.0.0-canary.97

## 7.0.0-canary.162

### Patch Changes

- Updated dependencies [83877a1]
  - @ai-sdk/gateway@4.0.0-canary.96

## 7.0.0-canary.161

### Patch Changes

- Updated dependencies [a3261db]
  - @ai-sdk/gateway@4.0.0-canary.95

## 7.0.0-canary.160

### Patch Changes

- Updated dependencies [712873e]
  - @ai-sdk/gateway@4.0.0-canary.94

## 7.0.0-canary.159

### Patch Changes

- b5092f5: fix(ai): do not re-validate tool input for output-error parts in validateUIMessages

## 7.0.0-canary.158

### Patch Changes

- bcce2dd: feat(stream-text): expose standalone stream transformation helpers and deprecate the equivalent `streamText` result methods.

  The new `toUIMessageChunk` and `toUIMessageStream` helpers let you convert a `streamText` `stream` (or any compatible `ReadableStream<TextStreamPart<TOOLS>>`) into UI message chunks without going through the result object — useful for custom transports, tests, and other producers of `TextStreamPart`.

  `result.toUIMessageStreamResponse(options)` and `result.pipeUIMessageStreamToResponse(response, options)` can migrate by passing `toUIMessageStream({ stream: result.stream, ...options })` to `createUIMessageStreamResponse` or `pipeUIMessageStreamToResponse`.

  The new `toTextStream` helper extracts text deltas from a `streamText` `stream`, so `result.toTextStreamResponse(options)` and `result.pipeTextStreamToResponse(response, options)` can migrate to `createTextStreamResponse({ stream: toTextStream({ stream: result.stream }), ...options })` and `pipeTextStreamToResponse({ response, stream: toTextStream({ stream: result.stream }), ...options })`.

  `result.toUIMessageStream`, `result.toUIMessageStreamResponse`, `result.pipeUIMessageStreamToResponse`, `result.toTextStreamResponse`, and `result.pipeTextStreamToResponse` are now `@deprecated`. They still work in v7 and will be removed in the next major release. Migration snippets are in the v6 → v7 migration guide.

## 7.0.0-canary.157

### Patch Changes

- Updated dependencies [e02f041]
  - @ai-sdk/gateway@4.0.0-canary.93

## 7.0.0-canary.156

### Patch Changes

- 023550e: Deprecate `streamText` result `fullStream` in favor of `stream`.
- e92fc45: feat(ai): introduce onAbort hook to close telemetry spans

## 7.0.0-canary.155

### Patch Changes

- e67d80e: fix: rename onFinish to onEnd
- 6cca112: feat: add timeBetweenOutputTokensMs stats
- 82fc0ab: fix(ai): pass all stream text parts to `onChunk`
- 76fd58c: fix: consider file outputs and tool calls for time to first output

## 7.0.0-canary.154

### Patch Changes

- 594029e: feat(ai): wrap the model call in telemetry context

## 7.0.0-canary.153

### Patch Changes

- 6c93e36: feat(provider-utils): add `spawnCommand` method to `Experimental_Sandbox` to allow for detached command execution
- Updated dependencies [6c93e36]
- Updated dependencies [f617ac2]
  - @ai-sdk/provider-utils@5.0.0-canary.44
  - @ai-sdk/gateway@4.0.0-canary.92

## 7.0.0-canary.152

### Patch Changes

- Updated dependencies [d4d4a5e]
  - @ai-sdk/gateway@4.0.0-canary.91

## 7.0.0-canary.151

### Patch Changes

- Updated dependencies [8b811d8]
  - @ai-sdk/gateway@4.0.0-canary.90

## 7.0.0-canary.150

### Patch Changes

- Updated dependencies [bba5250]
- Updated dependencies [94c6edc]
  - @ai-sdk/gateway@4.0.0-canary.89

## 7.0.0-canary.149

### Patch Changes

- e3d9c0e: Add `allowSystemInMessages` option to `ToolLoopAgent`.

  This exposes the same option that exists on `streamText` and `generateText`, whether `role: "system"` messages are allowed in the `prompt` or `messages` fields. When unset, system messages are rejected because they can create a prompt injection attack risk. Ideally, use the `instructions` option instead. Set to `true` to allow system messages, or `false` to explicitly reject them.

  ```ts
  const agent = new ToolLoopAgent({
    model,
    allowSystemInMessages: true,
  });

  await agent.generate({
    messages: [
      { role: "system", content: "Server context" },
      { role: "user", content: "Hello" },
    ],
  });
  ```

  The option can also be returned from `prepareCall` for dynamic per-call configuration.

## 7.0.0-canary.148

### Patch Changes

- 2852a84: fix(ai): make input optional on input-streaming UIMessagePart variants

## 7.0.0-canary.147

### Patch Changes

- Updated dependencies [accaca0]
  - @ai-sdk/gateway@4.0.0-canary.88

## 7.0.0-canary.146

### Patch Changes

- Updated dependencies [bf837fe]
  - @ai-sdk/gateway@4.0.0-canary.87

## 7.0.0-canary.145

### Patch Changes

- Updated dependencies [546cefe]
  - @ai-sdk/gateway@4.0.0-canary.86

## 7.0.0-canary.144

### Patch Changes

- 7fc6bd6: Raise minimum supported Node.js version to 22. Supported versions: 22, 24, and 26.
- Updated dependencies [7fc6bd6]
  - @ai-sdk/gateway@4.0.0-canary.85
  - @ai-sdk/provider-utils@5.0.0-canary.43
  - @ai-sdk/provider@4.0.0-canary.17

## 7.0.0-canary.143

### Patch Changes

- a6617c5: feat(provider-utils): add `readFile` and `writeFile` plus convenience wrappers to `Experimental_Sandbox` abstraction
- Updated dependencies [a6617c5]
- Updated dependencies [032c4a5]
  - @ai-sdk/provider-utils@5.0.0-canary.42
  - @ai-sdk/gateway@4.0.0-canary.84

## 7.0.0-canary.142

### Patch Changes

- 62d6481: Post-publish release notifications now link to each package’s GitHub release and npm page.

## 7.0.0-canary.141

### Patch Changes

- e3a0419: fix(ai): default missing embedding warnings to an empty array

## 7.0.0-canary.140

### Patch Changes

- Updated dependencies [1d6fb7f]
  - @ai-sdk/gateway@4.0.0-canary.83

## 7.0.0-canary.139

### Patch Changes

- 334ae5d: Update step performance metrics with explicit effective, input, output, and total token throughput fields.
- 28dfa06: fix: support tools with optional context
- e93fa91: rename Sandbox.executeCommand to Sandbox.runCommand
- Updated dependencies [28dfa06]
- Updated dependencies [e93fa91]
  - @ai-sdk/provider-utils@5.0.0-canary.41
  - @ai-sdk/gateway@4.0.0-canary.82

## 7.0.0-canary.138

### Patch Changes

- Updated dependencies [67c4011]
  - @ai-sdk/gateway@4.0.0-canary.81

## 7.0.0-canary.137

### Patch Changes

- 98627e5: feat(ai): remove onChunk event from telemetry
- 476e1ca: feat(ai): remove telemetry dependency on onChunk callback

## 7.0.0-canary.136

### Patch Changes

- a7de9c9: fix: make sandbox experimental
- Updated dependencies [a7de9c9]
  - @ai-sdk/provider-utils@5.0.0-canary.40
  - @ai-sdk/gateway@4.0.0-canary.80

## 7.0.0-canary.135

### Patch Changes

- Updated dependencies [105f95b]
  - @ai-sdk/provider-utils@5.0.0-canary.39
  - @ai-sdk/gateway@4.0.0-canary.79

## 7.0.0-canary.134

### Patch Changes

- ed74dae: fix(ui): make `input` optional on `output-error` tool and dynamic-tool UI message parts

  `validateUIMessages` rejected persisted assistant messages whose `output-error` tool parts had no `input` key. This happened for any errored tool call where the SDK set `input: undefined` (e.g. `NoSuchToolError` / `InvalidToolInputError`): JSON serialization stripped the `undefined` value, and Zod 4.4+ treats a missing `z.unknown()` key as a validation failure (previously it was implicitly optional). The schema now matches the runtime shape produced by `process-ui-message-stream`, so reloading a thread that contains an errored tool call no longer throws `AI_TypeValidationError`.

- f4cc8eb: feat: add performance statistics
- e80ada0: fix(ai): download tool-result file URLs
- 1dca341: fix: rename telemetry onFinish to onEnd
- 2605e5f: fix test mocks to return the first array-backed result on the first call

## 7.0.0-canary.133

### Patch Changes

- 38ca8dc: fix(gateway): enable retry support for gateway errors
- 6d76710: fix URL of hero animation in README
- Updated dependencies [38ca8dc]
- Updated dependencies [8b7af75]
  - @ai-sdk/gateway@4.0.0-canary.78

## 7.0.0-canary.132

### Patch Changes

- eaf849f: Rename rerank telemetry finish callback to `onRerankEnd`.
- 8565dcb: fix: rename onEmbedFinish to onEmbedEnd

## 7.0.0-canary.131

### Patch Changes

- b67525f: feat: instructions as prepareStep input
- ca446f8: feat: flexible tool descriptions
- bcacd48: fix(ai): accumulative properties on StreamTextResult, GenerateTextResult
- Updated dependencies [ca446f8]
  - @ai-sdk/provider-utils@5.0.0-canary.38
  - @ai-sdk/gateway@4.0.0-canary.77

## 7.0.0-canary.130

### Patch Changes

- Updated dependencies [5f380c0]
  - @ai-sdk/gateway@4.0.0-canary.76

## 7.0.0-canary.129

### Patch Changes

- d1b3786: fix(ai): deprecate properties on result that have moved to finalStep

## 7.0.0-canary.128

### Patch Changes

- Updated dependencies [d848405]
  - @ai-sdk/provider-utils@5.0.0-canary.37
  - @ai-sdk/gateway@4.0.0-canary.75

## 7.0.0-canary.127

### Patch Changes

- e95e38d: fix: Make `generateText` and `streamText` result `usage` report total usage across all steps and deprecate `totalUsage`.
- 016e877: feat(ai): add `instructions` as the primary prompt option and deprecate `system`
- ca99fea: feat: expose `finalStep` on text generation results
- d775a57: feat: introduce Instructions type
- 538c12b: feat: use instructions on ToolCallRepairFunction, parseToolCall, and events
- Updated dependencies [ca39020]
  - @ai-sdk/provider-utils@5.0.0-canary.36
  - @ai-sdk/gateway@4.0.0-canary.74

## 7.0.0-canary.126

### Patch Changes

- Updated dependencies [f634bac]
  - @ai-sdk/provider-utils@5.0.0-canary.35
  - @ai-sdk/gateway@4.0.0-canary.73

## 7.0.0-canary.125

### Major Changes

- 31f69de: fix(ai): carry prepareStep message overrides forward across steps
- 7c71ac6: fix(ai): limit response messages in StepResult to messages created in that step

### Patch Changes

- fd4f578: fix(ai): exclude request and response bodies from text generation results by default to reduce memory usage.
- c0c8ca2: fix(ai): remove deprecated LanguageModelUsage properties
- 5faf71c: feat: introduce responseMessages on GenerateTextResult and StreamTextResult
- 69254e0: feat(ai): add toolMetadata for tool specific metdata
- 3015fc3: feat: sandbox shell execution abstraction
- eee1166: feat(ai): expose initial and response messages in prepareStep
- 7dbf992: feat(ai): allow prepareStep to override sandbox per step
- Updated dependencies [69254e0]
- Updated dependencies [3015fc3]
  - @ai-sdk/provider-utils@5.0.0-canary.34
  - @ai-sdk/gateway@4.0.0-canary.72

## 7.0.0-canary.124

### Patch Changes

- 69aeb0e: feat: add deprecated tool call lifecycle callback aliases for AI SDK 6 compatibility.
- 48e92f3: feat: make include stable

## 7.0.0-canary.123

### Patch Changes

- 7392266: feat: move includeRawChunks to include.rawChunks
- 4bb4dbc: feat: introduce include.requestMessage option for step request message storage opt-in

## 7.0.0-canary.122

### Patch Changes

- 79b2468: feat: add request.messages to StepResult
- c22750c: fix(ai): move onToolExecutionStart and onToolExecutionEnd to stable

## 7.0.0-canary.121

### Patch Changes

- 2427d88: feat(ai): change Tool.sensitiveContext to telemetry.includeToolsContext and make it opt-in
- 5588abd: feat(ai): add experimental_refineToolInput option to ToolLoopAgent, generateText, streamText
- 6dd6b83: feat(ai): change sensitiveRuntimeContext to telemetry.includeRuntimeContext and make it opt-in
- Updated dependencies [2427d88]
  - @ai-sdk/provider-utils@5.0.0-canary.33
  - @ai-sdk/gateway@4.0.0-canary.71

## 7.0.0-canary.120

### Major Changes

- 5463d0d: feat(provider): align tool result output content file part types with top-level message file part types

### Patch Changes

- Updated dependencies [5463d0d]
  - @ai-sdk/provider-utils@5.0.0-canary.32
  - @ai-sdk/provider@4.0.0-canary.16
  - @ai-sdk/gateway@4.0.0-canary.70

## 7.0.0-canary.119

### Patch Changes

- Updated dependencies [8e53eb7]
  - @ai-sdk/gateway@4.0.0-canary.69

## 7.0.0-canary.118

### Patch Changes

- 47e65d6: fix(ai): tag step/chunk timeout aborts with `TimeoutError` reason

  When `timeout: { stepMs }` or `timeout: { chunkMs }` fires, the abort reason is now a `TimeoutError` `DOMException`, matching what `AbortSignal.timeout()` produces natively. Consumers can distinguish a framework timeout from a user-initiated cancel via `signal.reason.name === 'TimeoutError'`.

## 7.0.0-canary.117

### Patch Changes

- 0c4c275: trigger initial canary release
- Updated dependencies [0c4c275]
  - @ai-sdk/provider-utils@5.0.0-canary.31
  - @ai-sdk/provider@4.0.0-canary.15
  - @ai-sdk/gateway@4.0.0-canary.68

## 7.0.0-beta.116

### Patch Changes

- Updated dependencies [e7e8f42]
  - @ai-sdk/gateway@4.0.0-beta.67

## 7.0.0-beta.115

### Patch Changes

- 08d2129: feat(mcp): propagate the server name through dynamic tool parts
- 202f107: feat(ai): create a diagnostics channel to push event data
- Updated dependencies [08d2129]
- Updated dependencies [04e9009]
- Updated dependencies [be09425]
  - @ai-sdk/provider-utils@5.0.0-beta.30
  - @ai-sdk/gateway@4.0.0-beta.66

## 7.0.0-beta.114

### Major Changes

- 1f7db50: fix(ai): remove experimental_customProvider
- 9bd6512: feat(provider): change file part data property to be tagged with a type and remove the image part type

### Patch Changes

- 43a6750: fix(ai): preserve `allowSystemInMessages` across `streamText` retries
- 81caa5d: fix(ai): remove ExtractLiteralUnion export
- 258c093: chore: ensure consistent import handling and avoid import duplicates or cycles
- 6147cdf: fix(ai): fix auto-complete on provider registry and custom provider
- Updated dependencies [9bd6512]
- Updated dependencies [258c093]
- Updated dependencies [b6783da]
  - @ai-sdk/provider-utils@5.0.0-beta.29
  - @ai-sdk/provider@4.0.0-beta.14
  - @ai-sdk/gateway@4.0.0-beta.65

## 7.0.0-beta.113

### Patch Changes

- 9f0e36c: trigger release for all packages after provenance setup
- Updated dependencies [9f0e36c]
  - @ai-sdk/gateway@4.0.0-beta.64
  - @ai-sdk/provider@4.0.0-beta.13
  - @ai-sdk/provider-utils@5.0.0-beta.28

## 7.0.0-beta.112

### Major Changes

- cf93359: feat(ai): remove/refactor event data sent via callbacks
- 116c89f: feat(ai): remove telemetry data from the user-facing event data
- 4e095b0: fix(ai): reject system messages in messages or prompt by default (opt-in)

### Patch Changes

- 5f3749c: refactoring: rename toolNeedsApproval to toolApproval
- 0a51f7d: fix(ai): enforce `callOptionsSchema` at runtime in `ToolLoopAgent`

  `ToolLoopAgentSettings.callOptionsSchema` was declared and documented as a runtime schema for `options`, but `tool-loop-agent.ts` never invoked it. Any invariant a developer encoded in the schema was silently bypassed at runtime, and unchecked `options` flowed straight into `prepareCall` and any `instructions` template that interpolated them.

  `ToolLoopAgent.prepareCall` now validates caller-supplied `options` against `callOptionsSchema` (when set) via `safeValidateTypes`, throwing `InvalidArgumentError` on failure before forwarding to `prepareCall` / `generateText` / `streamText`.

- 71d3022: fix(ai): unify generate text event callbacks
- 67df0a0: feat: add sensitiveContext property to Tool
- 4181cfe: fix(ai): harden `getMediaTypeFromUrl` against prototype-property collisions

  `getMediaTypeFromUrl` (used to infer media types for `file-url` / `image-url` parts) used `ext in URL_EXTENSION_TO_MEDIA_TYPE` against a plain object literal. A URL ending in `.constructor` therefore resolved through the prototype chain and returned the `Object` constructor function, violating the helper's `: string` return type and forwarding a non-string value to provider adapters.

  Switch to `Object.hasOwn(...)` so attacker-controlled extensions like `.constructor` cannot resolve to inherited `Object.prototype` keys.

- 51ce232: feat(ai): add sensitiveRuntimeContext option
- befb78c: refactoring: remove real-time delays in unit tests
- 29d8cf4: feat(ai): rename the core-event types
- 58a2ad7: fix: more precise default message for tool execution denial
- 37d69b2: feat(ai): access runtime context in tool approval functions
- 1043274: feat(ai): add a ModelCall start/end event
- 7f59f04: feat(ai): add approval reason to automatic tool approvals
- 7677c1e: feat(ai): allow tool approval functions to return undefined
- f58f9bc: fix(ai): remove stopWhen from onStart event
- e1bfb9c: feat(ai): remove unnecessary data from events
- e87d71b: feat(ai): support automatic tool approval in ui messages
- 9d486aa: feat(ai): generic tool approval function
- 9b0bc8a: fix(mcp): prevent prototype pollution by using secureJsonParse
- fc92055: feat(ai): automatic tool approval
- Updated dependencies [785fe16]
- Updated dependencies [67df0a0]
- Updated dependencies [befb78c]
- Updated dependencies [0458559]
- Updated dependencies [5852c0a]
- Updated dependencies [baa5f20]
- Updated dependencies [fc92055]
- Updated dependencies [f9acbc0]
  - @ai-sdk/provider-utils@5.0.0-beta.27
  - @ai-sdk/gateway@4.0.0-beta.63

## 7.0.0-beta.111

### Major Changes

- 1949571: feat(ai): make experimental_telemetry stable
- 6542d93: feat(ai): change naming nomenclature for `*TelemetryIntegration` to `*Telemetry`

### Patch Changes

- f319fde: feat(ai): validate tool context against contextSchema at runtime

  Tool execution and approval callbacks now validate each tool's `toolsContext` entry against its `contextSchema`. Invalid tool context now throws `TypeValidationError` with tool-context validation metadata in `error.context`.

- 511902c: skip validation for tool parts in terminal states when tool schema is no longer registered
- 2e98477: fix: retain stack traces on async errors
- 876fd3e: fix(ai): limit tool execution time duration to actual tool execution
- f32c750: refactoring(ai): simplify mergeAbortSignals
- Updated dependencies [2e98477]
  - @ai-sdk/provider-utils@5.0.0-beta.26
  - @ai-sdk/gateway@4.0.0-beta.62

## 7.0.0-beta.110

### Patch Changes

- 72cb801: feat(ai): concurrent event notification

## 7.0.0-beta.109

### Patch Changes

- ec98264: feat(ai): allow multiple integrations to be registered at once
- eea8d98: refactoring: rename tool execution events
- 75ef93e: remove the deprecated `experimental_output` alias and document the `output` migration for AI SDK 7
- Updated dependencies [eea8d98]
  - @ai-sdk/provider-utils@5.0.0-beta.25
  - @ai-sdk/gateway@4.0.0-beta.61

## 7.0.0-beta.108

### Patch Changes

- Updated dependencies [f807e45]
  - @ai-sdk/provider-utils@5.0.0-beta.24
  - @ai-sdk/gateway@4.0.0-beta.60

## 7.0.0-beta.107

### Patch Changes

- 350ea38: refactoring: introduce Arrayable type
- Updated dependencies [350ea38]
  - @ai-sdk/provider-utils@5.0.0-beta.23
  - @ai-sdk/gateway@4.0.0-beta.59

## 7.0.0-beta.106

### Patch Changes

- Updated dependencies [03dc15c]
  - @ai-sdk/gateway@4.0.0-beta.58

## 7.0.0-beta.105

### Patch Changes

- 33d099c: fix(ai): omit reasoning-start/end when sendReasoning is false

## 7.0.0-beta.104

### Patch Changes

- 2a74d43: Remove the deprecated `experimental_prepareStep` option from `generateText`.

  Use `prepareStep` instead.

## 7.0.0-beta.103

### Patch Changes

- 382d53b: refactoring: rename context to runtimeContext
- 7bf7d7f: feat(ai): enable:true for telemetry by default
- c3d4019: chore(ai): rename 'TelemetrySettings' to 'TelemetryOptions'
- 083947b: feat(ai): separate toolsContext from context
- Updated dependencies [083947b]
  - @ai-sdk/provider-utils@5.0.0-beta.22
  - @ai-sdk/gateway@4.0.0-beta.57

## 7.0.0-beta.102

### Patch Changes

- Updated dependencies [0d8f107]
  - @ai-sdk/gateway@4.0.0-beta.56

## 7.0.0-beta.101

### Patch Changes

- 4873966: chore(ai): allow general usage of `logWarnings` and emit them via Node API when available

## 7.0.0-beta.100

### Patch Changes

- add1126: refactoring: executeTool uses tool as parameter
- Updated dependencies [add1126]
  - @ai-sdk/provider-utils@5.0.0-beta.21
  - @ai-sdk/gateway@4.0.0-beta.55

## 7.0.0-beta.99

### Patch Changes

- 2a9c144: feat(ai): add toolNeedsApproval option

## 7.0.0-beta.98

### Patch Changes

- Updated dependencies [5df9b6f]
  - @ai-sdk/gateway@4.0.0-beta.54

## 7.0.0-beta.97

### Patch Changes

- 208d045: fix(ai): skip global telemetry registration when local integration defined

## 7.0.0-beta.96

### Patch Changes

- Updated dependencies [0457e45]
  - @ai-sdk/gateway@4.0.0-beta.53

## 7.0.0-beta.95

### Patch Changes

- c4f4b5f: refactoring(ai): remove deprecated experimental_activeTools option

## 7.0.0-beta.94

### Patch Changes

- 1582efa: chore(ai): remove the metadata field from the telemetry settings

## 7.0.0-beta.93

### Patch Changes

- bc47739: chore(ai): cleanup telemetry event data

## 7.0.0-beta.92

### Patch Changes

- Updated dependencies [ba2e254]
  - @ai-sdk/gateway@4.0.0-beta.52

## 7.0.0-beta.91

### Patch Changes

- Updated dependencies [cdcdec2]
  - @ai-sdk/gateway@4.0.0-beta.51

## 7.0.0-beta.90

### Patch Changes

- 1db29c8: feat(ai): break `CallSettings` apart into `LanguageModelCallOptions` and `RequestOptions`

## 7.0.0-beta.89

### Patch Changes

- ff5eba1: feat: roll `image-*` tool output types into their equivalent `file-*` types
- Updated dependencies [b3976a2]
- Updated dependencies [ff5eba1]
  - @ai-sdk/provider-utils@5.0.0-beta.20
  - @ai-sdk/gateway@4.0.0-beta.50
  - @ai-sdk/provider@4.0.0-beta.12

## 7.0.0-beta.88

### Major Changes

- ef992f8: Remove CommonJS exports from all packages. All packages are now ESM-only (`"type": "module"`). Consumers using `require()` must switch to ESM `import` syntax.

### Patch Changes

- Updated dependencies [ef992f8]
  - @ai-sdk/gateway@4.0.0-beta.49
  - @ai-sdk/provider@4.0.0-beta.11
  - @ai-sdk/provider-utils@5.0.0-beta.19

## 7.0.0-beta.87

### Patch Changes

- Updated dependencies [bdbd322]
- Updated dependencies [8f53ccf]
  - @ai-sdk/gateway@4.0.0-beta.48

## 7.0.0-beta.86

### Patch Changes

- 5a6f514: feat(ai): support several tools in hasToolCall stop condition

## 7.0.0-beta.85

### Major Changes

- 57bf606: chore(ai): simplify unified telemetry creation

## 7.0.0-beta.84

### Patch Changes

- 90e2d8a: chore: fix unused vars not being flagged by our lint tooling
- Updated dependencies [90e2d8a]
  - @ai-sdk/provider-utils@5.0.0-beta.18
  - @ai-sdk/gateway@4.0.0-beta.47

## 7.0.0-beta.83

### Patch Changes

- Updated dependencies [6b0a40d]
  - @ai-sdk/gateway@4.0.0-beta.46

## 7.0.0-beta.82

### Patch Changes

- e27ed76: feat(devtools): add new devtools integration for telemetry

## 7.0.0-beta.81

### Patch Changes

- 2fe1099: feat(ai): emit streaming chunks throught the onChunk callback
- f04adcb: feat(ai): refresh `customProvider` and `createProviderRegistry` to support file and skill upload abstractions

## 7.0.0-beta.80

### Patch Changes

- 3ae1786: fix: better context type inference
- Updated dependencies [3ae1786]
  - @ai-sdk/provider-utils@5.0.0-beta.17
  - @ai-sdk/gateway@4.0.0-beta.45

## 7.0.0-beta.79

### Patch Changes

- 6866afe: fix(ai): fix `lastAssistantMessageIsCompleteWithApprovalResponses` to no longer ignore `providerExecuted` tool approvals

## 7.0.0-beta.78

### Patch Changes

- f372547: fix(ai): fix `providerExecuted` tool approvals being passed to language model twice
- Updated dependencies [7943a4b]
  - @ai-sdk/gateway@4.0.0-beta.44

## 7.0.0-beta.77

### Patch Changes

- 2add429: fix(ai): skip passing invalid JSON inputs to response messages

## 7.0.0-beta.76

### Major Changes

- fcc6869: refactor(ai/core): rename `ModelCallStreamPart` to `LanguageModelStreamPart` and align stream model call naming (`streamLanguageModelCall`, `experimental_streamLanguageModelCall`).

  This updates experimental low-level stream primitives to use "language model call" terminology consistently.

## 7.0.0-beta.75

### Patch Changes

- 176466a: chore(provider): align V4 model return types to have their own definitions across all model interfaces
- Updated dependencies [176466a]
  - @ai-sdk/provider@4.0.0-beta.10
  - @ai-sdk/gateway@4.0.0-beta.43
  - @ai-sdk/provider-utils@5.0.0-beta.16

## 7.0.0-beta.74

### Patch Changes

- e311194: feat(ai): allow passing provider instance to `uploadFile` and `uploadSkill` as shorthand
- Updated dependencies [e311194]
  - @ai-sdk/provider@4.0.0-beta.9
  - @ai-sdk/gateway@4.0.0-beta.42
  - @ai-sdk/provider-utils@5.0.0-beta.15

## 7.0.0-beta.73

### Patch Changes

- Updated dependencies [1464561]
  - @ai-sdk/gateway@4.0.0-beta.41

## 7.0.0-beta.72

### Patch Changes

- 664a0eb: feat (ai/core): support plain string model IDs in `rerank()` function

  The `rerank()` function now accepts plain model strings (e.g., `'cohere/rerank-v3.5'`) in addition to `RerankingModel` objects, matching the behavior of `generateText`, `embed`, and other core functions.

## 7.0.0-beta.71

### Patch Changes

- e68be55: fix(ai): skip stringifying text when streaming partial text
- Updated dependencies [939171f]
  - @ai-sdk/gateway@4.0.0-beta.40

## 7.0.0-beta.70

### Patch Changes

- Updated dependencies [0694029]
  - @ai-sdk/gateway@4.0.0-beta.39

## 7.0.0-beta.69

### Major Changes

- 72223e7: chore(ai): remove deprecated isToolOrDynamicToolUIPart function

### Patch Changes

- 34bd95d: feat(ai): add support for uploading provider skills using the provider references abstraction
- 008271d: feat(openai-compatible): emit warning when using kebab-case instead of camelCase
- Updated dependencies [34bd95d]
- Updated dependencies [008271d]
  - @ai-sdk/provider@4.0.0-beta.8
  - @ai-sdk/gateway@4.0.0-beta.38
  - @ai-sdk/provider-utils@5.0.0-beta.14

## 7.0.0-beta.68

### Major Changes

- 7e26e81: chore: rename experimental_context to context

### Patch Changes

- b0c2869: chore(ai): remove deprecated `media` type part from `ToolResultOutput`
- Updated dependencies [b0c2869]
- Updated dependencies [7e26e81]
  - @ai-sdk/provider-utils@5.0.0-beta.13
  - @ai-sdk/gateway@4.0.0-beta.37

## 7.0.0-beta.67

### Patch Changes

- d1a8bed: fix(ui): export `isDynamicToolUIPart` from `ai` package

## 7.0.0-beta.66

### Patch Changes

- Updated dependencies [fb0c233]
- Updated dependencies [d1f0d2b]
  - @ai-sdk/gateway@4.0.0-beta.36

## 7.0.0-beta.65

### Patch Changes

- Updated dependencies [46d1149]
  - @ai-sdk/provider-utils@5.0.0-beta.12
  - @ai-sdk/gateway@4.0.0-beta.35

## 7.0.0-beta.64

### Patch Changes

- Updated dependencies [71b0e7d]
  - @ai-sdk/gateway@4.0.0-beta.34

## 7.0.0-beta.63

### Patch Changes

- 6fd51c0: fix(provider): preserve error type prefix in getErrorMessage
- Updated dependencies [6fd51c0]
  - @ai-sdk/provider-utils@5.0.0-beta.11
  - @ai-sdk/provider@4.0.0-beta.7
  - @ai-sdk/gateway@4.0.0-beta.33

## 7.0.0-beta.62

### Patch Changes

- Updated dependencies [11746ca]
  - @ai-sdk/gateway@4.0.0-beta.32

## 7.0.0-beta.61

### Patch Changes

- c29a26f: feat(provider): add support for provider references and uploading files as supported per provider
- Updated dependencies [c29a26f]
  - @ai-sdk/provider-utils@5.0.0-beta.10
  - @ai-sdk/provider@4.0.0-beta.6
  - @ai-sdk/gateway@4.0.0-beta.31

## 7.0.0-beta.60

### Patch Changes

- 38fc777: Add AI Gateway hint to provider READMEs

## 7.0.0-beta.59

### Patch Changes

- Updated dependencies [4552cbf]
  - @ai-sdk/gateway@4.0.0-beta.30

## 7.0.0-beta.58

### Patch Changes

- 2e17091: fix(types): move shared tool set utility types into provider-utils

  Moved `ToolSet`, `InferToolSetContext`, and `UnionToIntersection` into `@ai-sdk/provider-utils` and updated `ai` internals to import them directly from there. This keeps the shared tool typing utilities colocated with the core tool type definitions.

- Updated dependencies [2e17091]
  - @ai-sdk/provider-utils@5.0.0-beta.9
  - @ai-sdk/gateway@4.0.0-beta.29

## 7.0.0-beta.57

### Major Changes

- 986c6fd: feat(ai): change type of experimental_context from unknown to generic
- 493295c: Remove the deprecated `ToolCallOptions` export.

  Use `ToolExecutionOptions` instead.

### Patch Changes

- Updated dependencies [986c6fd]
- Updated dependencies [493295c]
  - @ai-sdk/provider-utils@5.0.0-beta.8
  - @ai-sdk/gateway@4.0.0-beta.28

## 7.0.0-beta.56

### Patch Changes

- Updated dependencies [70a9aae]
  - @ai-sdk/gateway@4.0.0-beta.27

## 7.0.0-beta.55

### Major Changes

- b3c9f6a: feat(ai): create new opentelemetry package (@ai-sdk/otel)

## 7.0.0-beta.54

### Patch Changes

- 5d0f18e: feat(ai): move opentelemetry to new package

## 7.0.0-beta.53

### Patch Changes

- 9b47dea: fix(ai): remove otel Tracer api from telemetry settings

## 7.0.0-beta.52

### Patch Changes

- b56301c: feat(ai): decouple otel from generate/streamObject

## 7.0.0-beta.51

### Patch Changes

- 6abd098: split `prepareToolsAndToolChoice()` into `prepareTools()` and `prepareToolChoice()`

## 7.0.0-beta.50

### Patch Changes

- 3debdb7: feat(ai): rename `stepCountIs` to `isStepCount`

## 7.0.0-beta.49

### Patch Changes

- Updated dependencies [294cbe7]
  - @ai-sdk/gateway@4.0.0-beta.26

## 7.0.0-beta.48

### Patch Changes

- 5c4d910: feat(ai): add new `isLoopFinished` stop condition helper for unlimited steps

## 7.0.0-beta.47

### Patch Changes

- bc67b4f: feat(ai): add experimental callbacks for structured outputs

## 7.0.0-beta.46

### Patch Changes

- 31ee822: refactoring(ai): extract filterActiveTools and expose it as experimental_filterActiveTools

## 7.0.0-beta.45

### Patch Changes

- Updated dependencies [435895b]
  - @ai-sdk/gateway@4.0.0-beta.25

## 7.0.0-beta.44

### Patch Changes

- Updated dependencies [d30466c]
  - @ai-sdk/gateway@4.0.0-beta.24

## 7.0.0-beta.43

### Patch Changes

- Updated dependencies [4ec78cd]
  - @ai-sdk/gateway@4.0.0-beta.23

## 7.0.0-beta.42

### Patch Changes

- a3fd75b: feat(ai): expose Experimental_ModelCallStreamPart type

## 7.0.0-beta.41

### Patch Changes

- Updated dependencies [7ceff62]
  - @ai-sdk/gateway@4.0.0-beta.22

## 7.0.0-beta.40

### Patch Changes

- 989d3d2: fix(ai): include generated files in OTEL response attributes

## 7.0.0-beta.39

### Patch Changes

- f4cfccd: feat(ai): decouple otel from rerank function

## 7.0.0-beta.38

### Patch Changes

- 1f509d4: fix(ai): force template check on 'kind' param
- Updated dependencies [1f509d4]
  - @ai-sdk/provider-utils@5.0.0-beta.7
  - @ai-sdk/provider@4.0.0-beta.5
  - @ai-sdk/gateway@4.0.0-beta.21

## 7.0.0-beta.37

### Patch Changes

- Updated dependencies [4f91b5d]
  - @ai-sdk/gateway@4.0.0-beta.20

## 7.0.0-beta.36

### Patch Changes

- 118b953: feat(ai): decouple otel from embed functions

## 7.0.0-beta.35

### Patch Changes

- 99bf941: feat(ai): extract streamModelCall function for streaming text generation

## 7.0.0-beta.34

### Patch Changes

- Updated dependencies [72889f8]
  - @ai-sdk/gateway@4.0.0-beta.19

## 7.0.0-beta.33

### Patch Changes

- caf1b6f: feat(ai): introduce experimental callbacks for rerank function

## 7.0.0-beta.32

### Major Changes

- 4b46062: refactoring(ai): extract tool callback invocation into separate function and forward chunks before callback invocation

### Patch Changes

- Updated dependencies [165b97a]
  - @ai-sdk/gateway@4.0.0-beta.18

## 7.0.0-beta.31

### Patch Changes

- e79e644: chore(ai/core): remove `timeout` from `CallSettings` as it was effectively unused there

## 7.0.0-beta.30

### Patch Changes

- f5a6f89: README updates

## 7.0.0-beta.29

### Patch Changes

- 877bf12: fix(ai): flatten model attributes for telemetry

## 7.0.0-beta.28

### Major Changes

- b9cf502: refactoring(ai): delay tool execution in stream text until model call is finished

## 7.0.0-beta.27

### Patch Changes

- 3887c70: feat(provider): add new top-level reasoning parameter to spec and support it in `generateText` and `streamText`
- Updated dependencies [3887c70]
  - @ai-sdk/provider-utils@5.0.0-beta.6
  - @ai-sdk/provider@4.0.0-beta.4
  - @ai-sdk/gateway@4.0.0-beta.17

## 7.0.0-beta.26

### Patch Changes

- f0b0b20: feat(ai): add per-tool timeout overrides via toolTimeouts

## 7.0.0-beta.25

### Patch Changes

- ff9ce30: feat(ai): introduce experimental callbacks for embed function

## 7.0.0-beta.24

### Major Changes

- 776b617: feat(provider): adding new 'custom' content type

### Patch Changes

- Updated dependencies [776b617]
  - @ai-sdk/provider-utils@5.0.0-beta.5
  - @ai-sdk/provider@4.0.0-beta.3
  - @ai-sdk/gateway@4.0.0-beta.16

## 7.0.0-beta.23

### Patch Changes

- 80d4dde: fix(ai): include tool input on tool result for provider executed dynamic tools
- Updated dependencies [61753c3]
  - @ai-sdk/provider-utils@5.0.0-beta.4
  - @ai-sdk/gateway@4.0.0-beta.15

## 7.0.0-beta.22

### Patch Changes

- Updated dependencies [ead9144]
  - @ai-sdk/gateway@4.0.0-beta.14

## 7.0.0-beta.21

### Patch Changes

- 34fd051: feat(ai): add toolMs to timeout configuration

## 7.0.0-beta.20

### Patch Changes

- Updated dependencies [2095655]
  - @ai-sdk/gateway@4.0.0-beta.13

## 7.0.0-beta.19

### Patch Changes

- Updated dependencies [f7d4f01]
  - @ai-sdk/provider-utils@5.0.0-beta.3
  - @ai-sdk/provider@4.0.0-beta.2
  - @ai-sdk/gateway@4.0.0-beta.12

## 7.0.0-beta.18

### Patch Changes

- Updated dependencies [5c2a5a2]
  - @ai-sdk/provider@4.0.0-beta.1
  - @ai-sdk/gateway@4.0.0-beta.11
  - @ai-sdk/provider-utils@5.0.0-beta.2

## 7.0.0-beta.17

### Patch Changes

- Updated dependencies [4d6ab9a]
  - @ai-sdk/gateway@4.0.0-beta.10

## 7.0.0-beta.16

### Major Changes

- 5b8c58f: feat(ai): decouple otel from core functions

## 7.0.0-beta.15

### Patch Changes

- Updated dependencies [980f777]
- Updated dependencies [7185ba2]
  - @ai-sdk/gateway@4.0.0-beta.9

## 7.0.0-beta.14

### Patch Changes

- Updated dependencies [4adc485]
  - @ai-sdk/gateway@4.0.0-beta.8

## 7.0.0-beta.13

### Patch Changes

- c26ca8d: Remove custom User-Agent header from HttpChatTransport to fix CORS preflight failures in Safari and Firefox

## 7.0.0-beta.12

### Patch Changes

- Updated dependencies [e046ea3]
  - @ai-sdk/gateway@4.0.0-beta.7

## 7.0.0-beta.11

### Patch Changes

- Updated dependencies [82288b0]
  - @ai-sdk/gateway@4.0.0-beta.6

## 7.0.0-beta.10

### Patch Changes

- Updated dependencies [aa5a583]
  - @ai-sdk/gateway@4.0.0-beta.5

## 7.0.0-beta.9

### Patch Changes

- 1fe058b: fix(anthropic): preserve the error code returned by model

## 7.0.0-beta.8

### Patch Changes

- Updated dependencies [f32d84a]
  - @ai-sdk/gateway@4.0.0-beta.4

## 7.0.0-beta.7

### Patch Changes

- 210ed3d: feat(ai): pass result provider metadata across the stream

## 7.0.0-beta.6

### Patch Changes

- Updated dependencies [c949e25]
  - @ai-sdk/gateway@4.0.0-beta.3

## 7.0.0-beta.5

### Patch Changes

- ebd4da2: feat(ai): add missing usage attributes

## 7.0.0-beta.4

### Patch Changes

- 5ceed7d: fix(ai): doStream should reflect transformed values

## 7.0.0-beta.3

### Patch Changes

- 531251e: fix(security): validate redirect targets in download functions to prevent SSRF bypass

  Both `downloadBlob` and `download` now validate the final URL after following HTTP redirects, preventing attackers from bypassing SSRF protections via open redirects to internal/private addresses.

- Updated dependencies [531251e]
  - @ai-sdk/provider-utils@5.0.0-beta.1
  - @ai-sdk/gateway@4.0.0-beta.2

## 7.0.0-beta.2

### Patch Changes

- Updated dependencies [7afaece]
- Updated dependencies [f16c103]
  - @ai-sdk/gateway@4.0.0-beta.1

## 7.0.0-beta.1

### Patch Changes

- 6a3793e: chore(ai): add optional ChatRequestOptions to `addToolApprovalResponse` and `addToolOutput`

## 7.0.0-beta.0

### Major Changes

- 8359612: Start v7 pre-release

### Patch Changes

- Updated dependencies [8359612]
  - @ai-sdk/gateway@4.0.0-beta.0
  - @ai-sdk/provider@4.0.0-beta.0
  - @ai-sdk/provider-utils@5.0.0-beta.0

## 6.0.116

### Patch Changes

- ad4cfc2: Add URL validation to `downloadBlob` and `download` to prevent blind SSRF attacks. Private/internal IP addresses, localhost, and non-HTTP protocols are now rejected before fetching.
- Updated dependencies [ad4cfc2]
  - @ai-sdk/provider-utils@4.0.19
  - @ai-sdk/gateway@3.0.66

## 6.0.115

### Patch Changes

- Updated dependencies [824b295]
  - @ai-sdk/provider-utils@4.0.18
  - @ai-sdk/gateway@3.0.65

## 6.0.114

### Patch Changes

- 2291047: fix(ai): fix missing support for image thought signatures (e.g. for Gemini image models)

## 6.0.113

### Patch Changes

- 70d3980: fix(ai): use errorMode 'text' in approval continuation to preserve tool error messages

## 6.0.112

### Patch Changes

- Updated dependencies [db3d4ca]
  - @ai-sdk/gateway@3.0.64

## 6.0.111

### Patch Changes

- 2129c82: feat(ai): register global telemetry integrations

## 6.0.110

### Patch Changes

- Updated dependencies [1b01ec1]
- Updated dependencies [8df8e11]
  - @ai-sdk/gateway@3.0.63

## 6.0.109

### Patch Changes

- Updated dependencies [10bec50]
  - @ai-sdk/gateway@3.0.62

## 6.0.108

### Patch Changes

- 2a4f512: feat(ai): add telemetry interface and registry

## 6.0.107

### Patch Changes

- Updated dependencies [08336f1]
  - @ai-sdk/provider-utils@4.0.17
  - @ai-sdk/gateway@3.0.61

## 6.0.106

### Patch Changes

- Updated dependencies [29e9f4d]
  - @ai-sdk/gateway@3.0.60

## 6.0.105

### Patch Changes

- Updated dependencies [58bc42d]
  - @ai-sdk/provider-utils@4.0.16
  - @ai-sdk/gateway@3.0.59

## 6.0.104

### Patch Changes

- Updated dependencies [1330f2f]
  - @ai-sdk/gateway@3.0.58

## 6.0.103

### Patch Changes

- Updated dependencies [ba63bc2]
  - @ai-sdk/gateway@3.0.57

## 6.0.102

### Patch Changes

- Updated dependencies [45f0a7f]
  - @ai-sdk/gateway@3.0.56

## 6.0.101

### Patch Changes

- 5230482: fix(ai): Don't create duplicate tool parts when models call non-existent tools

## 6.0.100

### Patch Changes

- b7fba77: feat(ai): add event notifiers to core functions

## 6.0.99

### Patch Changes

- Updated dependencies [e8172b6]
  - @ai-sdk/gateway@3.0.55

## 6.0.98

### Patch Changes

- Updated dependencies [0c9395b]
  - @ai-sdk/gateway@3.0.54

## 6.0.97

### Patch Changes

- ebfdad1: feat(ai): experimental callbacks in ToolLoopAgent

## 6.0.96

### Patch Changes

- 30c9de6: feat(ai): experimental callbacks for streamText

## 6.0.95

### Patch Changes

- Updated dependencies [73b7e09]
  - @ai-sdk/gateway@3.0.53

## 6.0.94

### Patch Changes

- Updated dependencies [363fa44]
  - @ai-sdk/gateway@3.0.52

## 6.0.93

### Patch Changes

- d3769ec: feat(ai): add experimental callbacks in generateText

## 6.0.92

### Patch Changes

- Updated dependencies [765b013]
  - @ai-sdk/gateway@3.0.51

## 6.0.91

### Patch Changes

- Updated dependencies [a433cd3]
  - @ai-sdk/gateway@3.0.50

## 6.0.90

### Patch Changes

- 98e83ab: Fix `useChat` status briefly flashing to `submitted` on page load when `resume: true` is set and there is no active stream to resume. The `reconnectToStream` check is now performed before setting status to `submitted`, so status stays `ready` when the server responds with 204 (no active stream).

## 6.0.89

### Patch Changes

- Updated dependencies [5f693c8]
  - @ai-sdk/gateway@3.0.49

## 6.0.88

### Patch Changes

- Updated dependencies [2a1c664]
  - @ai-sdk/gateway@3.0.48

## 6.0.87

### Patch Changes

- Updated dependencies [6bbd05b]
  - @ai-sdk/gateway@3.0.47

## 6.0.86

### Patch Changes

- Updated dependencies [f75f18c]
  - @ai-sdk/gateway@3.0.46

## 6.0.85

### Patch Changes

- Updated dependencies [e858654]
  - @ai-sdk/gateway@3.0.45

## 6.0.84

### Patch Changes

- 4024a3a: security: prevent unbounded memory growth in download functions

  The `download()` and `downloadBlob()` functions now enforce a default 2 GiB size limit when downloading from user-provided URLs. Downloads that exceed this limit are aborted with a `DownloadError` instead of consuming unbounded memory and crashing the process. The `abortSignal` parameter is now passed through to `fetch()` in all download call sites.

  Added `download` option to `transcribe()` and `experimental_generateVideo()` for providing a custom download function. Use the new `createDownload({ maxBytes })` factory to configure download size limits.

- Updated dependencies [4024a3a]
  - @ai-sdk/provider-utils@4.0.15
  - @ai-sdk/gateway@3.0.44

## 6.0.83

### Patch Changes

- Updated dependencies [b424e50]
  - @ai-sdk/gateway@3.0.43

## 6.0.82

### Patch Changes

- Updated dependencies [1819bc1]
  - @ai-sdk/gateway@3.0.42

## 6.0.81

### Patch Changes

- ee4beee: feat(ai): add onStepFinish callback to createUIMessageStream

## 6.0.80

### Patch Changes

- Updated dependencies [99fbed8]
  - @ai-sdk/gateway@3.0.41

## 6.0.79

### Patch Changes

- Updated dependencies [a2208a2]
  - @ai-sdk/gateway@3.0.40

## 6.0.78

### Patch Changes

- 59fcf30: fix(ai): make experimental_context required in ToolLoopAgentOnFinishCallback

  This fixes a type inconsistency where `ToolLoopAgentOnFinishCallback` had `experimental_context` as optional while `StreamTextOnFinishCallback` and `GenerateTextOnFinishCallback` had it as required. Since `ToolLoopAgent` delegates to `streamText`/`generateText`, and both always pass `experimental_context` when invoking the callback, the types should match.

## 6.0.77

### Patch Changes

- Updated dependencies [eea5d30]
  - @ai-sdk/gateway@3.0.39

## 6.0.76

### Patch Changes

- Updated dependencies [70028ab]
  - @ai-sdk/gateway@3.0.38

## 6.0.75

### Patch Changes

- 7168375: feat (ai, provider): default global provider video model resolution
- Updated dependencies [7168375]
  - @ai-sdk/provider@3.0.8
  - @ai-sdk/gateway@3.0.37
  - @ai-sdk/provider-utils@4.0.14

## 6.0.74

### Patch Changes

- 471009b: fix(ai): pass reasoning text in telemetry

## 6.0.73

### Patch Changes

- Updated dependencies [9892c58]
  - @ai-sdk/gateway@3.0.36

## 6.0.72

### Patch Changes

- Updated dependencies [8e2eaac]
  - @ai-sdk/gateway@3.0.35

## 6.0.71

### Patch Changes

- Updated dependencies [4867635]
  - @ai-sdk/gateway@3.0.34

## 6.0.70

### Patch Changes

- Updated dependencies [ae30443]
  - @ai-sdk/gateway@3.0.33

## 6.0.69

### Patch Changes

- d659305: fix(ai): auto-populate `originalMessages` in `createAgentUIStream`

## 6.0.68

### Patch Changes

- 8bf2660: chore(ai): export `DefaultGeneratedFile`

## 6.0.67

### Patch Changes

- 53f6731: feat (ai, provider): experimental generate video support
- Updated dependencies [53f6731]
  - @ai-sdk/provider@3.0.7
  - @ai-sdk/gateway@3.0.32
  - @ai-sdk/provider-utils@4.0.13

## 6.0.66

### Patch Changes

- Updated dependencies [96936e5]
  - @ai-sdk/provider-utils@4.0.12
  - @ai-sdk/gateway@3.0.31

## 6.0.65

### Patch Changes

- Updated dependencies [1a74972]
  - @ai-sdk/gateway@3.0.30

## 6.0.64

### Patch Changes

- ce9daa3: Fixed 'reasoning part reasoning-0 not found' error by ensuring 'reasoning-start' event is emitted for empty thinking blocks (eg. <think></think>)

## 6.0.63

### Patch Changes

- be95579: fix(ui): respect `Promise<false>` when returned by `sendAutomaticallyWhen`

## 6.0.62

### Patch Changes

- 2810850: fix(ai): improve type validation error messages with field paths and entity identifiers
- Updated dependencies [2810850]
  - @ai-sdk/provider-utils@4.0.11
  - @ai-sdk/provider@3.0.6
  - @ai-sdk/gateway@3.0.29

## 6.0.61

### Patch Changes

- Updated dependencies [1524271]
  - @ai-sdk/gateway@3.0.28

## 6.0.60

### Patch Changes

- 5fc42fa: feat(ai): add experimental retention setting

## 6.0.59

### Patch Changes

- Updated dependencies [0acff64]
  - @ai-sdk/gateway@3.0.27

## 6.0.58

### Patch Changes

- Updated dependencies [a8be296]
  - @ai-sdk/gateway@3.0.26

## 6.0.57

### Patch Changes

- 65865d8: Fix handling of error results in deferrable tools

## 6.0.56

### Patch Changes

- Updated dependencies [15a78c7]
  - @ai-sdk/gateway@3.0.25

## 6.0.55

### Patch Changes

- 43a74df: chore(ai): add skill to README

## 6.0.54

### Patch Changes

- 2f8ac87: docs(ai): fix incorrect and outdated jsdoc

## 6.0.53

### Patch Changes

- 7ee3f10: chore: updated docs

## 6.0.52

### Patch Changes

- Updated dependencies [462ad00]
  - @ai-sdk/provider-utils@4.0.10
  - @ai-sdk/gateway@3.0.24

## 6.0.51

### Patch Changes

- ea0feb5: fix(ai): clean up step timeout when error occurs in streamText

## 6.0.50

### Patch Changes

- Updated dependencies [cbf1704]
  - @ai-sdk/gateway@3.0.23

## 6.0.49

### Patch Changes

- ded661b: feat(ai): add onStepFinish to agent.generate and agent.stream

## 6.0.48

### Patch Changes

- 4de5a1d: chore: excluded tests from src folder in npm package
- Updated dependencies [4de5a1d]
  - @ai-sdk/gateway@3.0.22
  - @ai-sdk/provider@3.0.5
  - @ai-sdk/provider-utils@4.0.9

## 6.0.47

### Patch Changes

- Updated dependencies [2b8369d]
  - @ai-sdk/gateway@3.0.21

## 6.0.46

### Patch Changes

- Updated dependencies [8dc54db]
  - @ai-sdk/gateway@3.0.20

## 6.0.45

### Patch Changes

- Updated dependencies [c60fdd8]
  - @ai-sdk/gateway@3.0.19

## 6.0.44

### Patch Changes

- Updated dependencies [7af4eb4]
  - @ai-sdk/gateway@3.0.18

## 6.0.43

### Patch Changes

- 2dc9bfa: fix(ai): handle provider-executed tools and tool-approval-response in validation
  - Skip validation for tool calls with `providerExecuted: true` (deferred results)
  - Map approvalId to toolCallId for proper tool-approval-response handling
  - Filter out empty tool messages after content filtering
  - Fixes MissingToolResultError for async and approval-based tool flows

## 6.0.42

### Patch Changes

- Updated dependencies [66d78d5]
  - @ai-sdk/gateway@3.0.17

## 6.0.41

### Patch Changes

- 84b6e6d: Revert "feat(ai): expose token usage in useChat onFinish callback#11871

## 6.0.40

### Patch Changes

- ab57783: Add usage information to onFinish callback in useChat

## 6.0.39

### Patch Changes

- 4e28ba0: fix(ai): propagate providerMetadata during input-streaming state

  Provider-executed tools (like MCP tools) need to send metadata during the streaming phase, but the implementation only set `callProviderMetadata` when `part.state === "input-available"`. This fix removes the overly-restrictive state check and adds `callProviderMetadata` to the input-streaming state types and schemas.

## 6.0.38

### Patch Changes

- Updated dependencies [5c090e7]
  - @ai-sdk/provider@3.0.4
  - @ai-sdk/gateway@3.0.16
  - @ai-sdk/provider-utils@4.0.8

## 6.0.37

### Patch Changes

- b5dab9b: fix(ai): maintain OpenTelemetry context across async generator yields

  Fixes an issue where OpenTelemetry context was lost at async generator yield boundaries, causing nested ToolLoopAgent spans to escape to the parent agent's level in observability platforms.

  The fix ensures that when `recordSpan` is used with async generators (e.g., in tool execution), the active context is explicitly maintained using `context.with()`, preventing span hierarchy corruption in nested agent scenarios.

  Closes #11720

## 6.0.36

### Patch Changes

- 46f46e4: fix(provider-utils): improve tool type inference when using `inputExamples` with Zod schemas that use `.optional().default()` or `.refine()`.
- Updated dependencies [46f46e4]
  - @ai-sdk/provider-utils@4.0.7
  - @ai-sdk/gateway@3.0.15

## 6.0.35

### Patch Changes

- d7e7f1f: Add descriptive error messages for malformed UIMessageStream chunks.

## 6.0.34

### Patch Changes

- 1b11dcb: chore(ai): include sources in npm package
- Updated dependencies [1b11dcb]
  - @ai-sdk/provider-utils@4.0.6
  - @ai-sdk/provider@3.0.3
  - @ai-sdk/gateway@3.0.14

## 6.0.33

### Patch Changes

- 0ca078c: fix(ai): pass providerMetadata in smooth stream to preserve thinking tag

## 6.0.32

### Patch Changes

- ec24401: chore(ai): include docs in npm package

## 6.0.31

### Patch Changes

- Updated dependencies [92b339b]
  - @ai-sdk/gateway@3.0.13

## 6.0.30

### Patch Changes

- Updated dependencies [34d1c8a]
  - @ai-sdk/provider-utils@4.0.5
  - @ai-sdk/gateway@3.0.12

## 6.0.29

### Patch Changes

- fdce123: docs: update README with usage example for @ai-sdk/anthropic

## 6.0.28

### Patch Changes

- d4486d2: fix(ai): do not cleanup AsyncIterableStream twice

## 6.0.27

### Patch Changes

- Updated dependencies [891a60a]
  - @ai-sdk/gateway@3.0.11

## 6.0.26

### Patch Changes

- 40d4997: feat(ai): add middleware for extracting JSON

## 6.0.25

### Patch Changes

- b64f256: Add `elementStream` to `streamText` for streaming individual array elements when using `output: Output.array()`.

## 6.0.24

### Patch Changes

- 4f236c8: feat(ai): per-chunk timeouts for streamText

## 6.0.23

### Patch Changes

- a4c680a: feat(ai): per-step timeouts for generateText and streamText
- 8c6f067: feat(ai): support Intl.Segmenter in smoothStream

## 6.0.22

### Patch Changes

- f0d29de: chore(ai): remove \_internal.currentDate from streamText

## 6.0.21

### Patch Changes

- 9667780: fix(ai): preserve `rawInput` in `safeValidateUIMessages` for `output-error` tool parts

  Fixes #11406

## 6.0.20

### Patch Changes

- f748c46: Updated Unified Provider Architecture section in README to describe AI Gateway as the default.

## 6.0.19

### Patch Changes

- Updated dependencies [2696fd2]
  - @ai-sdk/gateway@3.0.10

## 6.0.18

### Patch Changes

- d6ec0e2: chore(ai): remove \_internal.currentDate from generateText

## 6.0.17

### Patch Changes

- af0955e: streamText should throw timeout error with proper cause when it times out

## 6.0.16

### Patch Changes

- 81adf59: feat(ai): introduce timeout configuration object

## 6.0.15

### Patch Changes

- 3a73fb3: Include abort reason in stream chunks and document the new field

## 6.0.14

### Patch Changes

- 3f9453f: feat(ai): add timeout option to generateText, streamText, and Agent

## 6.0.13

### Patch Changes

- e2c445d: feat(ai): smoothStream reasoning support

## 6.0.12

### Patch Changes

- d937c8f: Add Image model middleware support via `wrapImageModel` and `ImageModelV3Middleware`.
- Updated dependencies [d937c8f]
  - @ai-sdk/provider@3.0.2
  - @ai-sdk/gateway@3.0.9
  - @ai-sdk/provider-utils@4.0.4

## 6.0.11

### Patch Changes

- Updated dependencies [8ec1984]
  - @ai-sdk/gateway@3.0.8

## 6.0.10

### Patch Changes

- ae26f95: Add missing `.catch()` handler to `executeToolCall` promise in `runToolsTransformation` to prevent potential stream hang when the promise rejects.

## 6.0.9

### Patch Changes

- 4e90233: feat(ui): add DirectChatTransport

## 6.0.8

### Patch Changes

- Updated dependencies [0b429d4]
  - @ai-sdk/provider-utils@4.0.3
  - @ai-sdk/gateway@3.0.7

## 6.0.7

### Patch Changes

- Updated dependencies [74c0157]
  - @ai-sdk/gateway@3.0.6

## 6.0.6

### Patch Changes

- Updated dependencies [7ee2d12]
  - @ai-sdk/gateway@3.0.5

## 6.0.5

### Patch Changes

- 863d34f: fix: trigger release to update `@latest`
- Updated dependencies [863d34f]
  - @ai-sdk/gateway@3.0.4
  - @ai-sdk/provider@3.0.1
  - @ai-sdk/provider-utils@4.0.2

## 6.0.4

### Patch Changes

- Updated dependencies [1dad057]
  - @ai-sdk/gateway@3.0.3

## 6.0.3

### Patch Changes

- 29264a3: feat: add MCP tool approval
- Updated dependencies [29264a3]
  - @ai-sdk/provider-utils@4.0.1
  - @ai-sdk/gateway@3.0.2

## 6.0.2

### Patch Changes

- 129ff26: fix(ai): skip tool input validation in `safeValidateUIMessages` when `output-error` state has undefined input

  Fixes #11392

- Updated dependencies [c0c8a0e]
  - @ai-sdk/gateway@3.0.1

## 6.0.1

### Patch Changes

- Updated dependencies [387980f]
  - @ai-sdk/gateway@3.0.0

## 6.0.0

### Major Changes

- dee8b05: ai SDK 6 beta

### Minor Changes

- 78928cb: release: start 5.1 beta

### Patch Changes

- 0c3b58b: fix(provider): add specificationVersion to ProviderV3
- 58920e0: fix(ai): do not drop custom headers in HttpChatTransport
- a7da2b6: feat(agent): change output generics
- 0adc679: feat(provider): shared spec v3
- 50b70d6: feat(anthropic): add programmatic tool calling
- 2d28066: chore(agent): limit agent call parameters
- fca786b: feat(agent): configurable call options
- 046aa3b: feat(provider): speech model v3 spec
- e1f6e8e: feat(ai): add Output.json()
- 8d9e8ad: chore(provider): remove generics from EmbeddingModelV3

  Before

  ```ts
  model.textEmbeddingModel("my-model-id");
  ```

  After

  ```ts
  model.embeddingModel("my-model-id");
  ```

- b67d224: Fixes an issue where `providerMetadata` and `providerExecuted` were lost when tool input validation failed
- ab6f01a: Improve ai gateway error message when api key is not present
- 9388ff1: feat(ui): add isDataUIPart helper
- dce03c4: feat: tool input examples
- 2625a04: feat(openai); update spec for mcp approval
- 37c58a0: This release introduces `wrapEmbeddingModel`, a new helper that brings embedding model customization capabilities similar to `wrapLanguageModel`.
- 4e2b04d: fix(gateway): throw error with user-friendly message in non-production environments if `AI_GATEWAY_API_KEY` is not configured
- ab1087b: feat(ai): `chat.addToolResult()` is now `chat.addToolOutput()`
- bb10a89: fix(ai): mcp errors to be jsonrpc 2.0 compliant
- 457f1c6: feat(ai): onFinish callback for generateText
- 95f65c2: chore: use import \* from zod/v4
- 754df61: fix(ai): correct type field in arrayOutputStrategy from 'enum' to 'array'
- 58920e0: refactor: consolidate header normalization across packages, remove duplicates, preserve custom headers
- 954c356: feat(openai): allow custom names for provider-defined tools
- 7fdd89d: feat(agent): export AgentCallParameters and AgentStreamParameters types
- eca63f3: feat(ai): add OAuth for MCP clients + refactor to new package

  This change replaces

  ```ts
  import { experimental_createMCPClient } from "ai";
  import { Experimental_StdioMCPTransport } from "ai/mcp-stdio";
  ```

  with

  ```ts
  import { experimental_createMCPClient } from "@ai-sdk/mcp";
  import { Experimental_StdioMCPTransport } from "@ai-sdk/mcp/mcp-stdio";
  ```

- 90e5bdd: chore(ai): restructure agent files
- 42cf7ed: fix(agent): use tool.toModelOutput when available
- 544d4e8: chore(specification): rename v3 provider defined tool to provider tool
- 4812235: fix(ai): add missing export for `LoadSettingError`
- 7f2c9b6: fix(ui): do not submit automatically when server return with error
- 614599a: chore(ai): deprecate generateObject and streamObject
- 0c4822d: feat: `EmbeddingModelV3`
- e062079: chore(agent): move Agent.respond into createAgentStreamResponse function
- 2b49dae: feat(agent): support UIMessageStreamOptions in createAgentStreamResponse
- ee651d7: `https://v6.ai-sdk.dev` -> `https://ai-sdk.dev`
- 5a4e732: Export `parseJsonEventStream` and `uiMessageChunkSchema` from "ai" package
- f733285: fix(ai): only parse experimental_output in generateText when finishReason is stop
- 9b83947: feat(ai): add convertDataPart option to convertToModelMessages

  Add optional convertDataPart callback for converting custom data parts (URLs, code files, etc.) to text or file parts that models can process. Fully type-safe using existing UIMessage generics.

- 7eca093: fix(ai): update `uiMessageChunkSchema` to satisfy the `UIMessageChunk` type
- 077aea3: feat(ai): stable structured output on generateText, streamText, and ToolLoopAgent
- 9f20c87: chore: updated README
- 521c537: feat(ai): Tool.needsApproval can be a function
- 7169511: feat(agent): support context in onFinish callback
- e8109d3: feat: tool execution approval
- 03849b0: move DelayedPromise into provider utils
- ed329cb: feat: `Provider-V3`
- 22ef5c6: feat(ai): Output.text() is default output mode
- 9ba4324: feat(ai): support SystemModelMessage[] in system and instructions properties
- 3bd2689: feat: extended token usage
- 293a6b7: Added a title to the tools
- 7c3c216: fixed docs and exported NoSpeechGeneratedError
- c62ecf0: feat(ai): add support for v2 specs in transcription and speech models
- d1bdadb: Added experimental_rerank support
- 703459a: feat: tool execution approval for dynamic tools
- 3071620: fix header loss when statusText is undefined in writeHead
- 7e4649f: fix(core): Fix image download behavior when the initial model is swapped out during prepareStep
- 48454ab: fix(ai): handle backpressure in `writeToServerResponse`
- e06b663: feat(agent): support experimental stream transforms
- 83e5744: feat: support async Tool.toModelOutput
- 8c98371: Extend addToolResult to support error results
- b1405bf: feat(ai): send context into streamText / generateText onFinish callbacks
- a5e152d: fix(ai): back version support for V2 providers
- aa0515c: feat(ai): move Agent to stable
- f6f0c5a: chore: remove zod from ui packages
- 3ed5519: chore: rename ToolCallOptions to ToolExecutionOptions
- eb8d1cb: fix not catching of empty arrays in validateUIMessage
- e7d9b00: feat(agent): add optional name property to agent
- d5b25ee: feat(ai): add Output.array()
- d7bae86: feat(ai): add Output.choice()
- 8dac895: feat: `LanguageModelV3`
- a755db5: feat(ai): improve warnings with provider and model id
- 1c2a4c1: fix(ai): remove outdated jsdoc param descriptions
- 686103c: chore(ai): export ContentPart type
- 0d6c0d8: chore(ai): remove deprecated CodeMessage type and related types and functions
- 9b8d17e: fix(agent): move provider options to main agent config
- 79a8e7f: feat(agent): support abortSignal in createAgentUIStream
- d59ce25: fix(ai): do not mutate middleware array argument when wrapping
- 475189e: chore(specification): rename EmbeddingModelCallOptions
- 3d83f38: chore(ai): improve addToolInputExamplesMiddleware
- 457318b: chore(provider,ai): switch to SharedV3Warning and unified warnings
- b681d7d: feat: expose usage tokens for 'generateImage' function
- c99da05: feat(ai): add onFinish to Agent
- db913bd: fix(google): add thought signature to gemini 3 pro image parts
- 9061dc0: feat: image editing
- 8445d70: feat: export GatewayModelId and use to type LanguageModel
- 32223c8: feat: add toolCallId arg to toModelOutput
- 8370068: fix(provider/google): preserve thoughtSignature through tool execution
- 5e313e3: fix(agent): do not allow static tools when tools is empty
- db62f7d: Added schema name and description for generateText and output
- a7f6f81: Add safeValidateUIMessages utility to validate UI messages without throwing, returning a success/failure result object like Zod’s safeParse
- 79ba99f: feat(agent): add message metadata support when inferring UI messages
- c98373a: chore(agent): rename createAgentStreamResponse to createAgentUIStreamResponse
- 846e80e: fix(ai): bind functions for v2 -> v3 adapter
- bbdcb81: Add experimental_context parameter to prepareStep callback
- 67a407c: chore(ai): add warning when using v2 models with AISDK v6
- 9524761: chore(ai): rename relevanceScore to score
- ca13d26: feat(ai): add output to StreamTextResult
- 4616b86: chore: update zod peer depenedency version
- a322efa: Added finishReason on useChat onFinish callbck
- 2d166e4: feat(provider/gateway): add support for image models
- 384142c: feat(agent): add abortSignal parameter to generate and stream
- 36b175c: chore(ai): change output generics
- 2b1bf9d: feat(ai): add pruneMessages helper function
- 81d4308: feat: provider-executed dynamic tools
- e0d1ea9: fix(ai): align logic of text-end with reasoning-end
- 2406576: chore(agent): rename messages property on agent ui stream functions to uiMessages
- b1aeea7: feat(ai): set default stopWhen on Agent to isStepCount(20)
- dce4e7b: chore(agent): rename system to instructions
- 4ece5f9: feat(agent): add experimental_download to ToolLoopAgent
- a417a34: feat(agent): introduce version property
- 637eaa4: feat(ai): print model warnings in embed and embedMany
- 177b475: fix(ai): download files when intermediate file cannot be downloaded
- 21e20c0: feat(provider): transcription model v3 spec
- afe7093: feat: add middleware for tool input examples
- 61f7b0f: chore(agent): rename BasicAgent to ToolLoopAgent
- af9dab3: fix(ai): remove unused mode setting from generateObject and streamObject
- 522f6b8: feat: `ImageModelV3`
- 97b1d77: fix(ui): Don't resend messages for providerExecuted tools in lastAssistantMessageIsCompleteWithToolCalls and lastAssistantMessageIsCompleteWithApprovalResponses
- 69768c2: chore(ai): remove UI message reference from model message validation
- 27e8c3a: chore(ai): rename Agent to BasicAgent, introduce Agent interface
- 81e29ab: feat(ai): allow modifying experimental context in prepareStep
- 7da02d2: fix(ai): prune messages properly when toolCalls set to 'before-last-message'
- 763d04a: feat: Standard JSON Schema support
- 95b77e2: feat(agent): extract createAgentUIStream, add pipeAgentUIStreamToResponse
- 3794514: feat: flexible tool output content support
- cbf52cd: feat: expose raw finish reason
- 14ca35d: feat: add support for v2 specs
- 10c1322: fix: moved dependency `@ai-sdk/test-server` to devDependencies
- dcdac8c: chore(ai): rename tool helpers
- 960ec8f: chore: change argument of toModelOutput to parameter object
- b59d924: feat(ai): support SystemModelMessage in system and instructions properties
- 1bd7d32: feat: tool-specific strict mode
- 95f65c2: chore: load zod schemas lazily
- Updated dependencies
  - @ai-sdk/provider@3.0.0
  - @ai-sdk/gateway@2.0.0
  - @ai-sdk/provider-utils@4.0.0

## 6.0.0-beta.169

### Patch Changes

- ee651d7: `https://v6.ai-sdk.dev` -> `https://ai-sdk.dev`

## 6.0.0-beta.168

### Patch Changes

- Updated dependencies [7294355]
  - @ai-sdk/gateway@2.0.0-beta.93

## 6.0.0-beta.167

### Patch Changes

- 475189e: chore(specification): rename EmbeddingModelCallOptions
- Updated dependencies [475189e]
  - @ai-sdk/provider@3.0.0-beta.32
  - @ai-sdk/gateway@2.0.0-beta.92
  - @ai-sdk/provider-utils@4.0.0-beta.59

## 6.0.0-beta.166

### Patch Changes

- 9f20c87: chore: updated README

## 6.0.0-beta.165

### Patch Changes

- 2625a04: feat(openai); update spec for mcp approval
- Updated dependencies [2625a04]
  - @ai-sdk/provider@3.0.0-beta.31
  - @ai-sdk/gateway@2.0.0-beta.91
  - @ai-sdk/provider-utils@4.0.0-beta.58

## 6.0.0-beta.164

### Patch Changes

- cbf52cd: feat: expose raw finish reason
- Updated dependencies [cbf52cd]
  - @ai-sdk/provider@3.0.0-beta.30
  - @ai-sdk/gateway@2.0.0-beta.90
  - @ai-sdk/provider-utils@4.0.0-beta.57

## 6.0.0-beta.163

### Patch Changes

- Updated dependencies [9549c9e]
  - @ai-sdk/provider@3.0.0-beta.29
  - @ai-sdk/gateway@2.0.0-beta.89
  - @ai-sdk/provider-utils@4.0.0-beta.56

## 6.0.0-beta.162

### Patch Changes

- 50b70d6: feat(anthropic): add programmatic tool calling
- Updated dependencies [50b70d6]
  - @ai-sdk/provider-utils@4.0.0-beta.55
  - @ai-sdk/gateway@2.0.0-beta.88

## 6.0.0-beta.161

### Patch Changes

- Updated dependencies [ee71658]
  - @ai-sdk/gateway@2.0.0-beta.87

## 6.0.0-beta.160

### Patch Changes

- 9061dc0: feat: image editing
- Updated dependencies [9061dc0]
  - @ai-sdk/provider-utils@4.0.0-beta.54
  - @ai-sdk/provider@3.0.0-beta.28
  - @ai-sdk/gateway@2.0.0-beta.86

## 6.0.0-beta.159

### Patch Changes

- 3071620: fix header loss when statusText is undefined in writeHead
- Updated dependencies [870297d]
  - @ai-sdk/gateway@2.0.0-beta.85

## 6.0.0-beta.158

### Patch Changes

- Updated dependencies [366f50b]
  - @ai-sdk/provider@3.0.0-beta.27
  - @ai-sdk/gateway@2.0.0-beta.84
  - @ai-sdk/provider-utils@4.0.0-beta.53

## 6.0.0-beta.157

### Patch Changes

- 763d04a: feat: Standard JSON Schema support
- Updated dependencies [763d04a]
  - @ai-sdk/provider-utils@4.0.0-beta.52
  - @ai-sdk/gateway@2.0.0-beta.83

## 6.0.0-beta.156

### Patch Changes

- 2406576: chore(agent): rename messages property on agent ui stream functions to uiMessages

## 6.0.0-beta.155

### Patch Changes

- Updated dependencies [c1efac4]
  - @ai-sdk/provider-utils@4.0.0-beta.51
  - @ai-sdk/gateway@2.0.0-beta.82

## 6.0.0-beta.154

### Patch Changes

- 32223c8: feat: add toolCallId arg to toModelOutput
- Updated dependencies [32223c8]
  - @ai-sdk/provider-utils@4.0.0-beta.50
  - @ai-sdk/gateway@2.0.0-beta.81

## 6.0.0-beta.153

### Patch Changes

- 83e5744: feat: support async Tool.toModelOutput
- Updated dependencies [83e5744]
  - @ai-sdk/provider-utils@4.0.0-beta.49
  - @ai-sdk/gateway@2.0.0-beta.80

## 6.0.0-beta.152

### Patch Changes

- 960ec8f: chore: change argument of toModelOutput to parameter object
- Updated dependencies [960ec8f]
  - @ai-sdk/provider-utils@4.0.0-beta.48
  - @ai-sdk/gateway@2.0.0-beta.79

## 6.0.0-beta.151

### Patch Changes

- dcdac8c: chore(ai): rename tool helpers

## 6.0.0-beta.150

### Patch Changes

- db62f7d: Added schema name and description for generateText and output

## 6.0.0-beta.149

### Patch Changes

- 4e2b04d: fix(gateway): throw error with user-friendly message in non-production environments if `AI_GATEWAY_API_KEY` is not configured

## 6.0.0-beta.148

### Patch Changes

- Updated dependencies [f18ef7f]
  - @ai-sdk/gateway@2.0.0-beta.78

## 6.0.0-beta.147

### Patch Changes

- 637eaa4: feat(ai): print model warnings in embed and embedMany

## 6.0.0-beta.146

### Patch Changes

- Updated dependencies [e9e157f]
  - @ai-sdk/provider-utils@4.0.0-beta.47
  - @ai-sdk/gateway@2.0.0-beta.77

## 6.0.0-beta.145

### Patch Changes

- Updated dependencies [34ee8d0]
  - @ai-sdk/gateway@2.0.0-beta.76

## 6.0.0-beta.144

### Patch Changes

- ab6f01a: Improve ai gateway error message when api key is not present

## 6.0.0-beta.143

### Patch Changes

- 81e29ab: feat(ai): allow modifying experimental context in prepareStep
- Updated dependencies [81e29ab]
  - @ai-sdk/provider-utils@4.0.0-beta.46
  - @ai-sdk/gateway@2.0.0-beta.75

## 6.0.0-beta.142

### Patch Changes

- 7169511: feat(agent): support context in onFinish callback
- bbdcb81: Add experimental_context parameter to prepareStep callback

## 6.0.0-beta.141

### Patch Changes

- b1405bf: feat(ai): send context into streamText / generateText onFinish callbacks

## 6.0.0-beta.140

### Patch Changes

- 7fdd89d: feat(agent): export AgentCallParameters and AgentStreamParameters types

## 6.0.0-beta.139

### Patch Changes

- 3bd2689: feat: extended token usage
- Updated dependencies [3bd2689]
  - @ai-sdk/provider@3.0.0-beta.26
  - @ai-sdk/gateway@2.0.0-beta.74
  - @ai-sdk/provider-utils@4.0.0-beta.45

## 6.0.0-beta.138

### Patch Changes

- Updated dependencies [53f3368]
  - @ai-sdk/provider@3.0.0-beta.25
  - @ai-sdk/gateway@2.0.0-beta.73
  - @ai-sdk/provider-utils@4.0.0-beta.44

## 6.0.0-beta.137

### Patch Changes

- 9ba4324: feat(ai): support SystemModelMessage[] in system and instructions properties

## 6.0.0-beta.136

### Patch Changes

- 3d83f38: chore(ai): improve addToolInputExamplesMiddleware

## 6.0.0-beta.135

### Patch Changes

- afe7093: feat: add middleware for tool input examples

## 6.0.0-beta.134

### Patch Changes

- 686103c: chore(ai): export ContentPart type

## 6.0.0-beta.133

### Patch Changes

- dce03c4: feat: tool input examples
- Updated dependencies [dce03c4]
  - @ai-sdk/provider-utils@4.0.0-beta.43
  - @ai-sdk/provider@3.0.0-beta.24
  - @ai-sdk/gateway@2.0.0-beta.72

## 6.0.0-beta.132

### Patch Changes

- af9dab3: fix(ai): remove unused mode setting from generateObject and streamObject

## 6.0.0-beta.131

### Patch Changes

- 3ed5519: chore: rename ToolCallOptions to ToolExecutionOptions
- Updated dependencies [3ed5519]
  - @ai-sdk/provider-utils@4.0.0-beta.42
  - @ai-sdk/gateway@2.0.0-beta.71

## 6.0.0-beta.130

### Patch Changes

- 1bd7d32: feat: tool-specific strict mode
- Updated dependencies [1bd7d32]
  - @ai-sdk/provider-utils@4.0.0-beta.41
  - @ai-sdk/provider@3.0.0-beta.23
  - @ai-sdk/gateway@2.0.0-beta.70

## 6.0.0-beta.129

### Patch Changes

- 67a407c: chore(ai): add warning when using v2 models with AISDK v6

## 6.0.0-beta.128

### Patch Changes

- Updated dependencies [b1624f0]
  - @ai-sdk/gateway@2.0.0-beta.69

## 6.0.0-beta.127

### Patch Changes

- 614599a: chore(ai): deprecate generateObject and streamObject

## 6.0.0-beta.126

### Patch Changes

- b67d224: Fixes an issue where `providerMetadata` and `providerExecuted` were lost when tool input validation failed

## 6.0.0-beta.125

### Patch Changes

- 0d6c0d8: chore(ai): remove deprecated CodeMessage type and related types and functions

## 6.0.0-beta.124

### Patch Changes

- 544d4e8: chore(specification): rename v3 provider defined tool to provider tool
- Updated dependencies [544d4e8]
  - @ai-sdk/provider-utils@4.0.0-beta.40
  - @ai-sdk/provider@3.0.0-beta.22
  - @ai-sdk/gateway@2.0.0-beta.68

## 6.0.0-beta.123

### Patch Changes

- 954c356: feat(openai): allow custom names for provider-defined tools
- Updated dependencies [954c356]
  - @ai-sdk/provider-utils@4.0.0-beta.39
  - @ai-sdk/provider@3.0.0-beta.21
  - @ai-sdk/gateway@2.0.0-beta.67

## 6.0.0-beta.122

### Patch Changes

- 03849b0: move DelayedPromise into provider utils
- Updated dependencies [03849b0]
  - @ai-sdk/provider-utils@4.0.0-beta.38
  - @ai-sdk/gateway@2.0.0-beta.66

## 6.0.0-beta.121

### Patch Changes

- Updated dependencies [cdd0bc2]
  - @ai-sdk/gateway@2.0.0-beta.65

## 6.0.0-beta.120

### Patch Changes

- 457318b: chore(provider,ai): switch to SharedV3Warning and unified warnings
- Updated dependencies [457318b]
  - @ai-sdk/provider@3.0.0-beta.20
  - @ai-sdk/gateway@2.0.0-beta.64
  - @ai-sdk/provider-utils@4.0.0-beta.37

## 6.0.0-beta.119

### Patch Changes

- b59d924: feat(ai): support SystemModelMessage in system and instructions properties

## 6.0.0-beta.118

### Patch Changes

- 8d9e8ad: chore(provider): remove generics from EmbeddingModelV3

  Before

  ```ts
  model.textEmbeddingModel("my-model-id");
  ```

  After

  ```ts
  model.embeddingModel("my-model-id");
  ```

- Updated dependencies [8d9e8ad]
  - @ai-sdk/provider@3.0.0-beta.19
  - @ai-sdk/gateway@2.0.0-beta.63
  - @ai-sdk/provider-utils@4.0.0-beta.36

## 6.0.0-beta.117

### Patch Changes

- Updated dependencies [10d819b]
  - @ai-sdk/provider@3.0.0-beta.18
  - @ai-sdk/gateway@2.0.0-beta.62
  - @ai-sdk/provider-utils@4.0.0-beta.35

## 6.0.0-beta.116

### Patch Changes

- 4ece5f9: feat(agent): add experimental_download to ToolLoopAgent

## 6.0.0-beta.115

### Patch Changes

- 7da02d2: fix(ai): prune messages properly when toolCalls set to 'before-last-message'

## 6.0.0-beta.114

### Patch Changes

- 69768c2: chore(ai): remove UI message reference from model message validation

## 6.0.0-beta.113

### Patch Changes

- 79a8e7f: feat(agent): support abortSignal in createAgentUIStream

## 6.0.0-beta.112

### Patch Changes

- e06b663: feat(agent): support experimental stream transforms

## 6.0.0-beta.111

### Patch Changes

- Updated dependencies [e8694af]
  - @ai-sdk/gateway@2.0.0-beta.61

## 6.0.0-beta.110

### Patch Changes

- db913bd: fix(google): add thought signature to gemini 3 pro image parts
- Updated dependencies [db913bd]
  - @ai-sdk/provider@3.0.0-beta.17
  - @ai-sdk/gateway@2.0.0-beta.60
  - @ai-sdk/provider-utils@4.0.0-beta.34

## 6.0.0-beta.109

### Patch Changes

- 79ba99f: feat(agent): add message metadata support when inferring UI messages

## 6.0.0-beta.108

### Patch Changes

- Updated dependencies [5dd4c6a]
  - @ai-sdk/gateway@2.0.0-beta.59

## 6.0.0-beta.107

### Patch Changes

- 8445d70: feat: export GatewayModelId and use to type LanguageModel

## 6.0.0-beta.106

### Patch Changes

- Updated dependencies [1425df5]
  - @ai-sdk/gateway@2.0.0-beta.58

## 6.0.0-beta.105

### Patch Changes

- Updated dependencies [bca7e61]
  - @ai-sdk/gateway@2.0.0-beta.57

## 6.0.0-beta.104

### Patch Changes

- 2d166e4: feat(provider/gateway): add support for image models
- Updated dependencies [2d166e4]
  - @ai-sdk/gateway@2.0.0-beta.56

## 6.0.0-beta.103

### Patch Changes

- Updated dependencies [cc5170d]
  - @ai-sdk/gateway@2.0.0-beta.55

## 6.0.0-beta.102

### Patch Changes

- Updated dependencies [5f66123]
  - @ai-sdk/gateway@2.0.0-beta.54

## 6.0.0-beta.101

### Patch Changes

- Updated dependencies [3782645]
  - @ai-sdk/gateway@2.0.0-beta.53

## 6.0.0-beta.100

### Patch Changes

- 8370068: fix(provider/google): preserve thoughtSignature through tool execution

## 6.0.0-beta.99

### Patch Changes

- 384142c: feat(agent): add abortSignal parameter to generate and stream

## 6.0.0-beta.98

### Patch Changes

- b681d7d: feat: expose usage tokens for 'generateImage' function
- Updated dependencies [b681d7d]
  - @ai-sdk/provider@3.0.0-beta.16
  - @ai-sdk/gateway@2.0.0-beta.52
  - @ai-sdk/provider-utils@4.0.0-beta.33

## 6.0.0-beta.97

### Patch Changes

- Updated dependencies [32d8dbb]
  - @ai-sdk/provider-utils@4.0.0-beta.32
  - @ai-sdk/gateway@2.0.0-beta.51

## 6.0.0-beta.96

### Patch Changes

- a322efa: Added finishReason on useChat onFinish callbck

## 6.0.0-beta.95

### Patch Changes

- eb8d1cb: fix not catching of empty arrays in validateUIMessage

## 6.0.0-beta.94

### Patch Changes

- ab1087b: feat(ai): `chat.addToolResult()` is now `chat.addToolOutput()`

## 6.0.0-beta.93

### Patch Changes

- Updated dependencies [bb36798]
  - @ai-sdk/provider@3.0.0-beta.15
  - @ai-sdk/gateway@2.0.0-beta.50
  - @ai-sdk/provider-utils@4.0.0-beta.31

## 6.0.0-beta.92

### Patch Changes

- 97b1d77: fix(ui): Don't resend messages for providerExecuted tools in lastAssistantMessageIsCompleteWithToolCalls and lastAssistantMessageIsCompleteWithApprovalResponses

## 6.0.0-beta.91

### Patch Changes

- Updated dependencies [4f16c37]
  - @ai-sdk/provider-utils@4.0.0-beta.30
  - @ai-sdk/gateway@2.0.0-beta.49

## 6.0.0-beta.90

### Patch Changes

- Updated dependencies [af3780b]
  - @ai-sdk/provider@3.0.0-beta.14
  - @ai-sdk/gateway@2.0.0-beta.48
  - @ai-sdk/provider-utils@4.0.0-beta.29

## 6.0.0-beta.89

### Patch Changes

- d59ce25: fix(ai): do not mutate middleware array argument when wrapping

## 6.0.0-beta.88

### Patch Changes

- 22ef5c6: feat(ai): Output.text() is default output mode

## 6.0.0-beta.87

### Patch Changes

- ca13d26: feat(ai): add output to StreamTextResult

## 6.0.0-beta.86

### Patch Changes

- 36b175c: chore(ai): change output generics

## 6.0.0-beta.85

### Patch Changes

- Updated dependencies [96322b7]
  - @ai-sdk/gateway@2.0.0-beta.47

## 6.0.0-beta.84

### Patch Changes

- Updated dependencies [016b111]
  - @ai-sdk/provider-utils@4.0.0-beta.28
  - @ai-sdk/gateway@2.0.0-beta.46

## 6.0.0-beta.83

### Patch Changes

- e1f6e8e: feat(ai): add Output.json()

## 6.0.0-beta.82

### Patch Changes

- 37c58a0: This release introduces `wrapEmbeddingModel`, a new helper that brings embedding model customization capabilities similar to `wrapLanguageModel`.
- Updated dependencies [37c58a0]
  - @ai-sdk/provider@3.0.0-beta.13
  - @ai-sdk/gateway@2.0.0-beta.45
  - @ai-sdk/provider-utils@4.0.0-beta.27

## 6.0.0-beta.81

### Patch Changes

- Updated dependencies [7d73922]
  - @ai-sdk/gateway@2.0.0-beta.44

## 6.0.0-beta.80

### Patch Changes

- 9524761: chore(ai): rename relevanceScore to score

## 6.0.0-beta.79

### Patch Changes

- d1bdadb: Added experimental_rerank support
- Updated dependencies [d1bdadb]
  - @ai-sdk/provider@3.0.0-beta.12
  - @ai-sdk/gateway@2.0.0-beta.43
  - @ai-sdk/provider-utils@4.0.0-beta.26

## 6.0.0-beta.78

### Patch Changes

- Updated dependencies [4c44a5b]
  - @ai-sdk/provider@3.0.0-beta.11
  - @ai-sdk/gateway@2.0.0-beta.42
  - @ai-sdk/provider-utils@4.0.0-beta.25

## 6.0.0-beta.77

### Patch Changes

- 0c3b58b: fix(provider): add specificationVersion to ProviderV3
- Updated dependencies [0c3b58b]
  - @ai-sdk/provider@3.0.0-beta.10
  - @ai-sdk/gateway@2.0.0-beta.41
  - @ai-sdk/provider-utils@4.0.0-beta.24

## 6.0.0-beta.76

### Patch Changes

- a755db5: feat(ai): improve warnings with provider and model id
- Updated dependencies [a755db5]
  - @ai-sdk/provider@3.0.0-beta.9
  - @ai-sdk/gateway@2.0.0-beta.40
  - @ai-sdk/provider-utils@4.0.0-beta.23

## 6.0.0-beta.75

### Patch Changes

- 58920e0: fix(ai): do not drop custom headers in HttpChatTransport
- 58920e0: refactor: consolidate header normalization across packages, remove duplicates, preserve custom headers
- Updated dependencies [58920e0]
  - @ai-sdk/provider-utils@4.0.0-beta.22
  - @ai-sdk/gateway@2.0.0-beta.39

## 6.0.0-beta.74

### Patch Changes

- 293a6b7: Added a title to the tools
- Updated dependencies [293a6b7]
  - @ai-sdk/provider-utils@4.0.0-beta.21
  - @ai-sdk/gateway@2.0.0-beta.38

## 6.0.0-beta.73

### Patch Changes

- 754df61: fix(ai): correct type field in arrayOutputStrategy from 'enum' to 'array'

## 6.0.0-beta.72

### Patch Changes

- eca63f3: feat(ai): add OAuth for MCP clients + refactor to new package

  This change replaces

  ```ts
  import { experimental_createMCPClient } from "ai";
  import { Experimental_StdioMCPTransport } from "ai/mcp-stdio";
  ```

  with

  ```ts
  import { experimental_createMCPClient } from "@ai-sdk/mcp";
  import { Experimental_StdioMCPTransport } from "@ai-sdk/mcp/mcp-stdio";
  ```

## 6.0.0-beta.71

### Patch Changes

- 077aea3: feat(ai): stable structured output on generateText, streamText, and ToolLoopAgent

## 6.0.0-beta.70

### Patch Changes

- d7bae86: feat(ai): add Output.choice()

## 6.0.0-beta.69

### Patch Changes

- d5b25ee: feat(ai): add Output.array()

## 6.0.0-beta.68

### Patch Changes

- 9b83947: feat(ai): add convertDataPart option to convertToModelMessages

  Add optional convertDataPart callback for converting custom data parts (URLs, code files, etc.) to text or file parts that models can process. Fully type-safe using existing UIMessage generics.

## 6.0.0-beta.67

### Patch Changes

- Updated dependencies [2b6a848]
  - @ai-sdk/gateway@2.0.0-beta.37

## 6.0.0-beta.66

### Patch Changes

- fca786b: feat(agent): configurable call options
- Updated dependencies [fca786b]
  - @ai-sdk/provider-utils@4.0.0-beta.20
  - @ai-sdk/gateway@2.0.0-beta.36

## 6.0.0-beta.65

### Patch Changes

- dce4e7b: chore(agent): rename system to instructions

## 6.0.0-beta.64

### Patch Changes

- 2d28066: chore(agent): limit agent call parameters

## 6.0.0-beta.63

### Patch Changes

- a7da2b6: feat(agent): change output generics

## 6.0.0-beta.62

### Patch Changes

- 95b77e2: feat(agent): extract createAgentUIStream, add pipeAgentUIStreamToResponse

## 6.0.0-beta.61

### Patch Changes

- c98373a: chore(agent): rename createAgentStreamResponse to createAgentUIStreamResponse

## 6.0.0-beta.60

### Patch Changes

- 2b49dae: feat(agent): support UIMessageStreamOptions in createAgentStreamResponse

## 6.0.0-beta.59

### Patch Changes

- e062079: chore(agent): move Agent.respond into createAgentStreamResponse function

## 6.0.0-beta.58

### Patch Changes

- a417a34: feat(agent): introduce version property

## 6.0.0-beta.57

### Patch Changes

- 61f7b0f: chore(agent): rename BasicAgent to ToolLoopAgent

## 6.0.0-beta.56

### Patch Changes

- 3794514: feat: flexible tool output content support
- Updated dependencies [3794514]
  - @ai-sdk/provider-utils@4.0.0-beta.19
  - @ai-sdk/provider@3.0.0-beta.8
  - @ai-sdk/gateway@2.0.0-beta.35

## 6.0.0-beta.55

### Patch Changes

- 42cf7ed: fix(agent): use tool.toModelOutput when available

## 6.0.0-beta.54

### Patch Changes

- 9388ff1: feat(ui): add isDataUIPart helper

## 6.0.0-beta.53

### Patch Changes

- Updated dependencies [2f8b0c8]
  - @ai-sdk/gateway@2.0.0-beta.34

## 6.0.0-beta.52

### Patch Changes

- Updated dependencies [1890317]
  - @ai-sdk/gateway@2.0.0-beta.33

## 6.0.0-beta.51

### Patch Changes

- 5e313e3: fix(agent): do not allow static tools when tools is empty

## 6.0.0-beta.50

### Patch Changes

- 4812235: fix(ai): add missing export for `LoadSettingError`
- 81d4308: feat: provider-executed dynamic tools
- Updated dependencies [81d4308]
  - @ai-sdk/provider@3.0.0-beta.7
  - @ai-sdk/gateway@2.0.0-beta.32
  - @ai-sdk/provider-utils@4.0.0-beta.18

## 6.0.0-beta.49

### Patch Changes

- 703459a: feat: tool execution approval for dynamic tools
- Updated dependencies [703459a]
  - @ai-sdk/provider-utils@4.0.0-beta.17
  - @ai-sdk/gateway@2.0.0-beta.31

## 6.0.0-beta.48

### Patch Changes

- 7f2c9b6: fix(ui): do not submit automatically when server return with error

## 6.0.0-beta.47

### Patch Changes

- c62ecf0: feat(ai): add support for v2 specs in transcription and speech models

## 6.0.0-beta.46

### Patch Changes

- Updated dependencies [0a2ff8a]
  - @ai-sdk/gateway@2.0.0-beta.30

## 6.0.0-beta.45

### Patch Changes

- 48454ab: fix(ai): handle backpressure in `writeToServerResponse`

## 6.0.0-beta.44

### Patch Changes

- 2b1bf9d: feat(ai): add pruneMessages helper function

## 6.0.0-beta.43

### Patch Changes

- 27e8c3a: chore(ai): rename Agent to BasicAgent, introduce Agent interface

## 6.0.0-beta.42

### Patch Changes

- Updated dependencies [6306603]
  - @ai-sdk/provider-utils@4.0.0-beta.16
  - @ai-sdk/gateway@2.0.0-beta.29

## 6.0.0-beta.41

### Patch Changes

- Updated dependencies [f0b2157]
  - @ai-sdk/gateway@2.0.0-beta.28
  - @ai-sdk/provider-utils@4.0.0-beta.15

## 6.0.0-beta.40

### Patch Changes

- Updated dependencies [3b1d015]
  - @ai-sdk/provider-utils@4.0.0-beta.14
  - @ai-sdk/gateway@2.0.0-beta.27

## 6.0.0-beta.39

### Patch Changes

- f6f0c5a: chore: remove zod from ui packages

## 6.0.0-beta.38

### Patch Changes

- Updated dependencies [d116b4b]
  - @ai-sdk/provider-utils@4.0.0-beta.13
  - @ai-sdk/gateway@2.0.0-beta.26

## 6.0.0-beta.37

### Patch Changes

- Updated dependencies [7e32fea]
  - @ai-sdk/provider-utils@4.0.0-beta.12
  - @ai-sdk/gateway@2.0.0-beta.25

## 6.0.0-beta.36

### Patch Changes

- Updated dependencies [0e29b8b]
  - @ai-sdk/gateway@2.0.0-beta.24

## 6.0.0-beta.35

### Patch Changes

- Updated dependencies [acc14d8]
  - @ai-sdk/gateway@2.0.0-beta.23

## 6.0.0-beta.34

### Patch Changes

- bb10a89: fix(ai): mcp errors to be jsonrpc 2.0 compliant

## 6.0.0-beta.33

### Patch Changes

- f733285: fix(ai): only parse experimental_output in generateText when finishReason is stop

## 6.0.0-beta.32

### Patch Changes

- 7e4649f: fix(core): Fix image download behavior when the initial model is swapped out during prepareStep

## 6.0.0-beta.31

### Patch Changes

- 95f65c2: chore: use import \* from zod/v4
- 95f65c2: chore: load zod schemas lazily
- Updated dependencies
  - @ai-sdk/provider-utils@4.0.0-beta.11
  - @ai-sdk/gateway@2.0.0-beta.22

## 6.0.0-beta.30

### Patch Changes

- Updated dependencies [7b1b1b1]
  - @ai-sdk/gateway@2.0.0-beta.21

## 6.0.0-beta.29

### Major Changes

- dee8b05: ai SDK 6 beta

### Patch Changes

- Updated dependencies [dee8b05]
  - @ai-sdk/gateway@2.0.0-beta.20
  - @ai-sdk/provider@3.0.0-beta.6
  - @ai-sdk/provider-utils@4.0.0-beta.10

## 5.1.0-beta.28

### Patch Changes

- 521c537: feat(ai): Tool.needsApproval can be a function
- Updated dependencies [521c537]
  - @ai-sdk/provider-utils@3.1.0-beta.9
  - @ai-sdk/gateway@1.1.0-beta.19

## 5.1.0-beta.27

### Patch Changes

- Updated dependencies [e06565c]
  - @ai-sdk/provider-utils@3.1.0-beta.8
  - @ai-sdk/gateway@1.1.0-beta.18

## 5.1.0-beta.26

### Patch Changes

- c99da05: feat(ai): add onFinish to Agent

## 5.1.0-beta.25

### Patch Changes

- 457f1c6: feat(ai): onFinish callback for generateText

## 5.1.0-beta.24

### Patch Changes

- 90e5bdd: chore(ai): restructure agent files

## 5.1.0-beta.23

### Patch Changes

- Updated dependencies [1d8ea2c]
  - @ai-sdk/gateway@1.1.0-beta.17

## 5.1.0-beta.22

### Patch Changes

- 046aa3b: feat(provider): speech model v3 spec
- e8109d3: feat: tool execution approval
- a5e152d: fix(ai): back version support for V2 providers
- 21e20c0: feat(provider): transcription model v3 spec
- Updated dependencies
  - @ai-sdk/provider@2.1.0-beta.5
  - @ai-sdk/provider-utils@3.1.0-beta.7
  - @ai-sdk/gateway@1.1.0-beta.16

## 5.1.0-beta.21

### Patch Changes

- Updated dependencies [ef62178]
  - @ai-sdk/gateway@1.1.0-beta.15

## 5.1.0-beta.20

### Patch Changes

- 846e80e: fix(ai): bind functions for v2 -> v3 adapter
- Updated dependencies [a90dca6]
  - @ai-sdk/gateway@1.1.0-beta.14

## 5.1.0-beta.19

### Patch Changes

- aa0515c: feat(ai): move Agent to stable
- e7d9b00: feat(agent): add optional name property to agent
- b1aeea7: feat(ai): set default stopWhen on Agent to isStepCount(20)

## 5.1.0-beta.18

### Patch Changes

- 0adc679: feat(provider): shared spec v3
- 9b8d17e: fix(agent): move provider options to main agent config
- Updated dependencies
  - @ai-sdk/provider-utils@3.1.0-beta.6
  - @ai-sdk/provider@2.1.0-beta.4
  - @ai-sdk/gateway@1.1.0-beta.13

## 5.1.0-beta.17

### Patch Changes

- Updated dependencies [e6bfe91]
  - @ai-sdk/gateway@1.1.0-beta.12

## 5.1.0-beta.16

### Patch Changes

- 14ca35d: feat: add support for v2 specs
- Updated dependencies [636e614]
  - @ai-sdk/gateway@1.1.0-beta.11

## 5.1.0-beta.15

### Patch Changes

- Updated dependencies [9f6149e]
  - @ai-sdk/gateway@1.1.0-beta.10

## 5.1.0-beta.14

### Patch Changes

- 7c3c216: fixed docs and exported NoSpeechGeneratedError
- 8dac895: feat: `LanguageModelV3`
- e0d1ea9: fix(ai): align logic of text-end with reasoning-end
- 10c1322: fix: moved dependency `@ai-sdk/test-server` to devDependencies
- Updated dependencies [8dac895]
  - @ai-sdk/provider-utils@3.1.0-beta.5
  - @ai-sdk/provider@2.1.0-beta.3
  - @ai-sdk/gateway@1.1.0-beta.9

## 5.1.0-beta.13

### Patch Changes

- 1c2a4c1: fix(ai): remove outdated jsdoc param descriptions

## 5.1.0-beta.12

### Patch Changes

- Updated dependencies [c823faf]
  - @ai-sdk/gateway@1.1.0-beta.8

## 5.1.0-beta.11

### Patch Changes

- 4616b86: chore: update zod peer depenedency version
- Updated dependencies [4616b86]
  - @ai-sdk/provider-utils@3.1.0-beta.4
  - @ai-sdk/gateway@1.1.0-beta.7

## 5.1.0-beta.10

### Patch Changes

- 8c98371: Extend addToolResult to support error results

## 5.1.0-beta.9

### Patch Changes

- ed329cb: feat: `Provider-V3`
- 177b475: fix(ai): download files when intermediate file cannot be downloaded
- 522f6b8: feat: `ImageModelV3`
- Updated dependencies
  - @ai-sdk/gateway@1.1.0-beta.6
  - @ai-sdk/provider@2.1.0-beta.2
  - @ai-sdk/provider-utils@3.1.0-beta.3

## 5.1.0-beta.8

### Patch Changes

- 7eca093: fix(ai): update `uiMessageChunkSchema` to satisfy the `UIMessageChunk` type

## 5.1.0-beta.7

### Patch Changes

- 5a4e732: Export `parseJsonEventStream` and `uiMessageChunkSchema` from "ai" package

## 5.1.0-beta.6

### Patch Changes

- 0c4822d: feat: `EmbeddingModelV3`
- Updated dependencies
  - @ai-sdk/gateway@1.1.0-beta.5
  - @ai-sdk/provider@2.1.0-beta.1
  - @ai-sdk/provider-utils@3.1.0-beta.2

## 5.1.0-beta.5

### Patch Changes

- Updated dependencies
  - @ai-sdk/gateway@1.1.0-beta.4

## 5.1.0-beta.4

### Patch Changes

- Updated dependencies [ea9ca31]
  - @ai-sdk/gateway@1.1.0-beta.3

## 5.1.0-beta.3

### Patch Changes

- Updated dependencies
  - @ai-sdk/gateway@1.1.0-beta.2

## 5.1.0-beta.2

### Patch Changes

- Updated dependencies
  - @ai-sdk/test-server@1.0.0-beta.0
  - @ai-sdk/provider-utils@3.1.0-beta.1
  - @ai-sdk/gateway@1.1.0-beta.1

## 5.1.0-beta.1

### Patch Changes

- a7f6f81: Add safeValidateUIMessages utility to validate UI messages without throwing, returning a success/failure result object like Zod’s safeParse

## 5.1.0-beta.0

### Minor Changes

- 78928cb: release: start 5.1 beta

### Patch Changes

- Updated dependencies [78928cb]
  - @ai-sdk/gateway@1.1.0-beta.0
  - @ai-sdk/provider@2.1.0-beta.0
  - @ai-sdk/provider-utils@3.1.0-beta.0

## 5.0.45

### Patch Changes

- 76024fc: fix(ai): fix static tool call and result detection when dynamic is undefined
- 93d8b60: fix(ai): do not filter zero-length text parts that have provider options
- d8eb31f: fix(ai): fix webp image detection from base64

## 5.0.44

### Patch Changes

- Updated dependencies [f49f924]
  - @ai-sdk/gateway@1.0.23

## 5.0.43

### Patch Changes

- 0294b58: feat(ai): set `ai`, `@ai-sdk/provider-utils`, and runtime in `user-agent` header
- Updated dependencies [0294b58]
  - @ai-sdk/provider-utils@3.0.9
  - @ai-sdk/gateway@1.0.22

## 5.0.42

### Patch Changes

- de5c066: fix(ai): forwarded providerExecuted flag in validateUIMessages

## 5.0.41

### Patch Changes

- cd91e4b: fix(ai): use correct type for reasoning outputs

## 5.0.40

### Patch Changes

- Updated dependencies [4ee3719]
  - @ai-sdk/gateway@1.0.21

## 5.0.39

### Patch Changes

- a0a725f: feat (ai): export createGateway

## 5.0.38

### Patch Changes

- Updated dependencies [350a328]
  - @ai-sdk/gateway@1.0.20

## 5.0.37

### Patch Changes

- d6785d7: feat (ai): add tool and agent helpers

## 5.0.36

### Patch Changes

- ccc2ded: feat (ai): export gateway provider

## 5.0.35

### Patch Changes

- 99c946a: export missing type

## 5.0.34

### Patch Changes

- Updated dependencies
  - @ai-sdk/gateway@1.0.19

## 5.0.33

### Patch Changes

- Updated dependencies [5d59a8c]
  - @ai-sdk/gateway@1.0.18

## 5.0.32

### Patch Changes

- Updated dependencies [b6005cd]
  - @ai-sdk/gateway@1.0.17

## 5.0.31

### Patch Changes

- Updated dependencies [99964ed]
  - @ai-sdk/provider-utils@3.0.8
  - @ai-sdk/gateway@1.0.16

## 5.0.30

### Patch Changes

- 7fcc6be: feat(ai): throw InvalidArgumentError when messages is not provided

## 5.0.29

### Patch Changes

- e0e9449: feat(ui): sent isAbort, isDisconnect, isError in useChat onFinish callback

## 5.0.28

### Patch Changes

- 4b81e7d: fix(ai): remove vitest dependency from test exports
- d68a4f2: feat(ai): log warnings

## 5.0.27

### Patch Changes

- ca40fac: feat(ai): support custom download functions (experimental)

## 5.0.26

### Patch Changes

- 33cf848: feat(ai): pass messages to `useChat({ onFinish })`
- Updated dependencies
  - @ai-sdk/gateway@1.0.15

## 5.0.25

### Patch Changes

- ca65923: fix(ai): remove use of `expect()` from production code
- Updated dependencies [886e7cd]
  - @ai-sdk/provider-utils@3.0.7
  - @ai-sdk/gateway@1.0.14

## 5.0.24

### Patch Changes

- f8f3682: fix: call onFinish when stream is cancelled in toUIMessageStream

  Previously, onFinish was only called on normal stream completion. Now it's also called when the reader is cancelled (e.g., browser close, navigation), ensuring partial messages are persisted.

- Updated dependencies
  - @ai-sdk/provider-utils@3.0.6
  - @ai-sdk/gateway@1.0.13

## 5.0.23

### Patch Changes

- 5099b3d: fix(ai): make `chat.addToolResult()` compatible with dynamic tool calls
- 7a2bf8d: fix(ai): support loop breaking behavior in async iterable stream
- Updated dependencies
  - @ai-sdk/gateway@1.0.12

## 5.0.22

### Patch Changes

- Updated dependencies
  - @ai-sdk/gateway@1.0.11

## 5.0.21

### Patch Changes

- 581abea: fix(ai): call abort callback when stream is aborted during tool execution
- 3c178ec: feat(ai): improved type checking for prompt/messages input
- Updated dependencies [0857788]
  - @ai-sdk/provider-utils@3.0.5
  - @ai-sdk/gateway@1.0.10

## 5.0.20

### Patch Changes

- 8a87693: fix(ai) Make sure warnings promise in streamObject is resolved and properly collects and passes warnings

## 5.0.19

### Patch Changes

- 8da6e9c: fix(ai): use parsed tool input if possible when validation fails

## 5.0.18

### Patch Changes

- Updated dependencies [8b96f99]
  - @ai-sdk/gateway@1.0.9

## 5.0.17

### Patch Changes

- 4176ecb: feat(ai): add reasoning text to generateObject result
- 20f23f9: feat(ai): export LanguageModelMiddleware type

## 5.0.16

### Patch Changes

- Updated dependencies [68751f9]
  - @ai-sdk/provider-utils@3.0.4
  - @ai-sdk/gateway@1.0.8

## 5.0.15

### Patch Changes

- ca4f68f: feat(ai): add validateUIMessages function
- Updated dependencies [28a4006]
  - @ai-sdk/gateway@1.0.7

## 5.0.14

### Patch Changes

- 7729e32: fix(ai): expand mp3 detection to support all mpeg frame headers

## 5.0.13

### Patch Changes

- a7b2e66: Added providerOptions to agent stream and generate calls
- 9bed210: ### `extractReasoningMiddleware()`: delay sending `text-start` chunk to prevent rendering final text before reasoning

  When wrapping a text stream in `extractReasoningMiddleware()`, delay queing the `text-start` chunk until either `reasoning-start` chunk was queued or the first `text-delta` chunk is about to be queued, whichever comes first.

  https://github.com/vercel/ai/pull/8036

## 5.0.12

### Patch Changes

- Updated dependencies
  - @ai-sdk/gateway@1.0.6
  - @ai-sdk/provider-utils@3.0.3

## 5.0.11

### Patch Changes

- 38ac190: feat(ai): preliminary tool results
- e3a63cb: fix(ai): streamText promises reject when stream has errors
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.2
  - @ai-sdk/gateway@1.0.5

## 5.0.10

### Patch Changes

- 63a5dc5: fix(ai): convert user message text/file part provider metadata in convertToModelMessages

## 5.0.9

### Patch Changes

- afd5c2a: fix(ai): preserve filename for file parts in convertToModelMessages

## 5.0.8

### Patch Changes

- Updated dependencies [35f93ce]
  - @ai-sdk/gateway@1.0.4

## 5.0.7

### Patch Changes

- 8e72304: fix (ai): handle invalid tool calls

## 5.0.6

### Patch Changes

- d983eee: feat(ai): allow passing model string for embeddings

## 5.0.5

### Patch Changes

- Updated dependencies [893aed6]
  - @ai-sdk/gateway@1.0.3

## 5.0.4

### Patch Changes

- Updated dependencies [444df49]
  - @ai-sdk/gateway@1.0.2

## 5.0.3

### Patch Changes

- 90d212f: feat (ai): add experimental tool call context
- Updated dependencies
  - @ai-sdk/gateway@1.0.1
  - @ai-sdk/provider-utils@3.0.1

## 5.0.2

### Patch Changes

- 401d73e: fix (ai): support dynamic tool calls in lastAssistantMessageIsCompleteWithToolCalls
- 69fde99: Set status to ready when reconnect stream is null

## 5.0.1

### Patch Changes

- 4d0c108: fix(ai/ui): convert provider metadata for system messages to model messages

## 5.0.0

### Major Changes

- e1cbf8a: chore(@ai-sdk/rsc): extract to separate package
- a847c3e: chore: rename reasoning to reasoningText etc
- 13fef90: chore (ai): remove automatic conversion of UI messages to model messages
- d964901: - remove setting temperature to `0` by default
  - remove `null` option from `DefaultSettingsMiddleware`
  - remove setting defaults for `temperature` and `stopSequences` in `ai` to enable middleware changes
- 0a710d8: feat (ui): typed tool parts in ui messages
- 9ad0484: feat (ai): automatic tool execution error handling
- 63f9e9b: chore (provider,ai): tools have input/output instead of args,result
- ab7ccef: chore (ai): change source ui message parts to source-url
- d5f588f: AI SDK 5
- ec78cdc: chore (ai): remove "data" UIMessage role
- 6a83f7d: refactoring (ai): restructure message metadata transfer
- db345da: chore (ai): remove exports of internal ui functions
- 496bbc1: chore (ui): inline/remove ChatRequest type
- 72d7d72: chore (ai): stable activeTools
- 40acf9b: feat (ui): introduce ChatStore and ChatTransport
- 98f25e5: chore (ui): remove managed chat inputs
- 2d03e19: chore (ai): remove StreamCallbacks.onCompletion
- da70d79: chore (ai): remove getUIText helper
- c60f895: chore (ai): remove useChat keepLastMessageOnError
- 0560977: chore (ai): improve consistency of generate text result, stream text result, and step result
- 9477ebb: chore (ui): remove useAssistant hook (**breaking change**)
- 1f55c21: chore (ai): send reasoning to the client by default
- e7dc6c7: chore (ai): remove onResponse callback
- 8b86e99: chore (ai): replace `Message` with `UIMessage`
- 04d5063: chore (ai): rename default provider global to AI_SDK_DEFAULT_PROVIDER
- 319b989: chore (ai): remove content from ui messages
- 14c9410: chore: refactor file towards source pattern (spec)
- a34eb39: chore (ai): remove `data` and `allowEmptySubmit` from `ChatRequestOptions`
- f04fb4a: chore (ai): replace useChat attachments with file ui parts
- f7e8bf4: chore (ai): flatten ui message stream parts
- 257224b: chore (ai): separate TextStreamChatTransport
- fd1924b: chore (ai): remove redundant `mimeType` property
- 2524fc7: chore (ai): remove ui message toolInvocations property
- 6fba4c7: chore (ai): remove deprecated experimental_providerMetadata
- b4b4bb2: chore (ui): rename experimental_resume to resumeStream
- 441d042: chore (ui): data stream protocol v2 with SSEs
- ef256ed: chore (ai): refactor and use chatstore in svelte
- 516be5b: ### Move Image Model Settings into generate options

  Image Models no longer have settings. Instead, `maxImagesPerCall` can be passed directly to `generateImage()`. All other image settings can be passed to `providerOptions[provider]`.

  Before

  ```js
  await generateImage({
    model: luma.image("photon-flash-1", {
      maxImagesPerCall: 5,
      pollIntervalMillis: 500,
    }),
    prompt,
    n: 10,
  });
  ```

  After

  ```js
  await generateImage({
    model: luma.image("photon-flash-1"),
    prompt,
    n: 10,
    maxImagesPerCall: 5,
    providerOptions: {
      luma: { pollIntervalMillis: 5 },
    },
  });
  ```

  Pull Request: https://github.com/vercel/ai/pull/6180

- a662dea: chore (ai): remove sendExtraMessageFields
- d884051: feat (ai): simplify default provider setup
- e8324c5: feat (ai): add args callbacks to tools
- fafc3f2: chore (ai): change file to parts to use urls instead of data
- 1ed0287: chore (ai): stable sendStart/sendFinish options
- c7710a9: chore (ai): rename DataStreamToSSETransformStream to JsonToSseTransformStream
- bfbfc4c: feat (ai): streamText/generateText: totalUsage contains usage for all steps. usage is for a single step.
- 9ae327d: chore (ui): replace chat store concept with chat instances
- 9315076: chore (ai): rename continueUntil to stopWhen. Rename maxSteps stop condition to isStepCount.
- 247ee0c: chore (ai): remove steps from tool invocation ui parts
- 109c0ac: chore (ai): rename id to chatId (in post request, resume request, and useChat)
- 954aa73: feat (ui): extended regenerate support
- 33eb499: feat (ai): inject message id in createUIMessageStream
- 901df02: feat (ui): use UI_MESSAGE generic
- 4892798: chore (ai): always stream tool calls
- c25cbce: feat (ai): use console.error as default error handler for streamText and streamObject
- b33ed7a: chore (ai): rename DataStream* to UIMessage*
- ed675de: feat (ai): add ui data parts
- 7bb58d4: chore (ai): restructure prepareRequest
- ea7a7c9: feat (ui): UI message metadata
- 0463011: fix (ai): update source url stream part
- dcc549b: remove StreamTextResult.mergeIntoDataStream method
  rename DataStreamOptions.getErrorMessage to onError
  add pipeTextStreamToResponse function
  add createTextStreamResponse function
  change createDataStreamResponse function to accept a DataStream and not a DataStreamWriter
  change pipeDataStreamToResponse function to accept a DataStream and not a DataStreamWriter
  change pipeDataStreamToResponse function to have a single parameter
- 35fc02c: chore (ui): rename RequestOptions to CompletionRequestOptions
- 64f6d64: feat (ai): replace maxSteps with continueUntil (generateText)
- 175b868: chore (ai): rename reasoning UI parts 'reasoning' property to 'text'
- 60e2c56: feat (ai): restructure chat transports
- 765f1cd: chore (ai): remove deprecated useChat isLoading helper
- cb2b53a: chore (ai): refactor header preparation
- e244a78: chore (ai): remove StreamData and mergeStreams
- d306260: feat (ai): replace maxSteps with continueUntil (streamText)
- 4bfe9ec: chore (ai): remove ui message reasoning property
- 1766ede: chore: rename maxTokens to maxOutputTokens
- 2877a74: chore (ai): remove ui message data property
- 1409e13: chore (ai): remove experimental continueSteps
- b32e192: chore (ai): rename reasoning to reasoningText, rename reasoningDetails to reasoning (streamText, generateText)
- 92cb0a2: chore (ai): rename CoreMessage to ModelMessage
- 2b637d6: chore (ai): rename UIMessageStreamPart to UIMessageChunk

### Minor Changes

- b7eae2d: feat (core): Add finishReason field to NoObjectGeneratedError
- bcea599: feat (ai): add content to generateText result
- 48d675a: feat (ai): add content to streamText result
- c9ad635: feat (ai): add filename to file ui parts

### Patch Changes

- a571d6e: chore(provider-utils): move ToolResultContent to provider-utils
- de2d2ab: feat(ai): add provider and provider registry middleware functionality
- c22ad54: feat(smooth-stream): chunking callbacks
- d88455d: feat (ai): expose http chat transport type
- e7fcc86: feat (ai): introduce dynamic tools
- da1e6f0: feat (ui): add generics to ui message stream parts
- 48378b9: fix (ai): send null as tool output when tools return undefined
- 5d1e3ba: chore (ai): remove provider re-exports
- 93d53a1: chore (ai): remove cli
- e90d45d: chore (rsc): move HANGING_STREAM_WARNING_TIME constant into @ai-sdk/rsc package
- b32c141: feat (ai): add array support to stopWhen
- bc3109f: chore (ai): push stream-callbacks into langchain/llamaindex adapters
- 0d9583c: fix (ai): use user-provided media type when available
- 38ae5cc: feat (ai): export InferUIMessageChunk type
- 10b21eb: feat(cli): add ai command line interface
- 9e40cbe: Allow destructuring output and errorText on `ToolUIPart` type
- 6909543: feat (ai): support system parameter in Agent constructor
- 86cfc72: feat (ai): add ignoreIncompleteToolCalls option to convertToModelMessages
- 377bbcf: fix (ui): tool input can be undefined during input-streaming
- d8aeaef: feat(providers/fal): add transcribe
- ae77a99: chore (ai): rename text and reasoning chunks in streamText fullstream
- 4fef487: feat: support for zod v4 for schema validation

  All these methods now accept both a zod v4 and zod v3 schemas for validation:

  - `generateObject()`
  - `streamObject()`
  - `generateText()`
  - `experimental_useObject()` from `@ai-sdk/react`
  - `streamUI()` from `@ai-sdk/rsc`

- b1e3abd: feat (ai): expose ui message stream headers
- 4f3e637: fix (ui): avoid caching globalThis.fetch in case it is patched by other libraries
- 14cb3be: chore(providers/llamaindex): extract to separate package
- 1f6ce57: feat (ai): infer tool call types in the `onToolCall` callback
- 16ccfb2: feat (ai): add readUIMessageStream helper
- 225f087: fix (ai/mcp): prevent mutation of customEnv
- ce1d1f3: feat (ai): export mock image, speech, and transcription models
- fc0380b: feat (ui): resolvable header, body, credentials in http chat transport
- 6622441: feat (ai): add static/dynamic toolCalls/toolResults helpers
- 4048ce3: fix (ai): add tests and examples for openai responses
- 6c42e56: feat (ai): validate ui stream data chunks
- bedb239: chore (ai): make ui stream parts value optional when it's not required
- 9b4d074: feat(streamObject): add enum support
- c8fce91: feat (ai): add experimental Agent abstraction
- 655cf3c: feat (ui): add onFinish to createUIMessageStream
- 3e10408: fix(utils/detect-mimetype): add support for detecting id3 tags
- d5ae088: feat (ui): add sendAutomaticallyWhen to Chat
- ced8eee: feat(ai): re-export zodSchema from main package
- c040e2f: fix (ui): inject generated response message id
- d3960e3: selectTelemetryAttributes more robustness
- faea29f: fix (provider/openai): multi-step reasoning with text
- 66af894: fix (ai): respect content order in toResponseMessages
- 332167b: chore (ai): move maxSteps into UseChatOptions
- 6b1c55c: feat (ai): introduce GLOBAL_DEFAULT_PROVIDER
- 5a975a4: feat (ui): update Chat tool result submission
- 507ac1d: fix (ui/react): update messages immediately with the submitted user message
- a166433: feat: add transcription with experimental_transcribe
- 26735b5: chore(embedding-model): add v2 interface
- c93a8bc: chore(ai): export AsyncIterableStream type from async-iterable-stream module
- 0d2c085: feat (ai): support string model ids through gateway
- 2b9bbcd: feat (ai): improve prompt validation error message
- a8c8bd5: feat(embed-many): respect supportsParallelCalls & concurrency
- 75c3396: fix (ai): handle errors in 2nd streamText doStream call
- cb9c9e4: remove deprecated `experimental_wrapLanguageModel`
- 9bf7291: chore(providers/openai): enable structuredOutputs by default & switch to provider option
- 9b0da33: fix (ai): do not send id with start unless specified
- 28ad69e: fix(react-native): support experimental_attachments without FileList global
- 0b78e17: chore(ai/generateObject): simplify function signature
- 20398f2: feat: ai sdk cli documentation + adjusted default model
- 66962ed: fix(packages): export node10 compatible types
- b71fe8d: fix(ai): remove jsondiffpatch dependency
- 7827a49: fix (ai/core): refactor `toResponseMessages` to filter out empty string/content
- bd8a36c: feat(embedding-model-v2/embedMany): add response body field
- d9209ca: fix (image-model): `specificationVersion: v1` -> `v2`
- b346545: feat (ai): add data ui part schemas
- 05d2819: feat: allow zod 4.x as peer dependency
- f2b041e: Fix custom `fetch` in HttpChatTransport
- 2a62513: Fix error thrown when emptying messages in onError or onFinish
- 143c55b: feat (ai): export Chat callback types
- 9301f86: refactor (image-model): rename `ImageModelV1` to `ImageModelV2`
- 904fa5e: feat (ai/core): add terminateOnError option to readUIMessageStream
- 0a87932: core (ai): change transcription model mimeType to mediaType
- 1675396: fix: avoid job executor deadlock when adding tool result
- 51f497d: feat (ai): step input message modification in prepareStep
- cee64b2: fix(otel): change back toolCall attributes of input/output back to args/result for compatibility
- f04ffe4: feat (ui): add onData callback to Chat
- bc24722: feat (ai): Add finishReason as a promise on StreamObjectResult to match StreamTextResult
- b6f9f3c: remove deprecated `CoreTool*` types
- 8aa9e20: feat: add speech with experimental_generateSpeech
- 4617fab: chore(embedding-models): remove remaining settings
- 8255639: ### Fix use with Google APIs + zod v4's `.literal()` schema

  Before [zod@3.25.49](https://github.com/colinhacks/zod/releases/tag/v3.25.49), requests to Google's APIs failed due to a missing `type` in the provided schema. The problem has been resolved for the `ai` SDK by bumping our `zod` peer dependencies to `^3.25.49`.

  pull request: https://github.com/vercel/ai/pull/6609

- f81c720: chore(ai): bundle dependencies in CLI binary
- cf9af6e: feat (ai): allow sync prepareStep
- ee38081: Add support for audio/webm to detect-media-type
- 2e4f9e4: feat (ai): improved error messages when using gateway
- 3e3b9df: fix (ai/mcp): better support for zero-argument MCP tools
- cda32ba: fix (ai): send `start` part in correct position in stream (streamText)
- 48a7606: feat (ai): support changing the system prompt in prepareSteps
- cb68df0: feat: add transcription and speech model support to provider registry
- db64cbe: fix (provider/openai): multi-step reasoning with tool calls
- 97c35c0: feat (ui): transient data parts
- 26695a3: feat (ui): add state for text and reasoning ui message parts
- 90ac328: fix (ui): tool part metadata support in ui messages
- 60132dd: fixed date formatting for updated mcp protocol version
- 4a1e0c8: fix(ai-cli): fix bundling and improve authentication error handling
- c6b64a7: feat (ai): allow async prepareRequest on HttpChatTransport
- fccf75c: update mcp protocol version
- 9121250: Expose provider metadata as an attribute on exported OTEL spans
- ea27cc6: chore (ai): use JSONValue definition from provider
- 90ca2b9: feat(ai): Record tool call errors on tool call spans recorded in `generateText` and `streamText`.
- 50f0362: fix (ai): fix experimental sendStart/sendFinish options in streamText
- 825e8d7: release alpha.5
- 7d97ab6: release alpha.4
- 0ff02bb: chore(provider-utils): move over jsonSchema
- 4f3776c: feat (ai): add InferUITools helper
- 9338f3e: fix (ai): throw error for v1 models
- 92c8e66: fix(ai/core): properly handle custom separator in provider registry
- 53569b8: feat (ai): add experimental repairText function to streamObject
- 82aa95d: fix (ai): merge data ui stream parts correctly
- e7d2ce3: feat: provider-executed tools
- add5ac1: feat (ai): make streamText toUIMessageStream async iterable
- 37a916d: feat (ai): add prepareSteps to streamText
- 30ac566: fix (ui): text message metadata support in ui messages
- 8026705: fix (core): send buffered text in smooth stream when stream parts change
- 9bd5ab5: feat (provider): add providerMetadata to ImageModelV2 interface (#5977)

  The `experimental_generateImage` method from the `ai` package now returnes revised prompts for OpenAI's image models.

  ```js
  const prompt = "Santa Claus driving a Cadillac";

  const { providerMetadata } = await experimental_generateImage({
    model: openai.image("dall-e-3"),
    prompt,
  });

  const revisedPrompt = providerMetadata.openai.images[0]?.revisedPrompt;

  console.log({
    prompt,
    revisedPrompt,
  });
  ```

- ec5933d: chore (ai/mcp): add `assertCapability` method to experimental MCP client
- 09f41ac: fix (ui): add message metadata in Chat.sendMessage
- ff1c81a: feat (ai): add streamText onAbort callback
- af1d5a5: fix(ai): Unexpected reasoning-start event in extract reasoning middleware
- cb3b9c9: fix (ai): catch errors in ui message stream
- 86293e5: fix (ai): use correct generateMessageId in streamText toUIMessageStream
- d1a034f: feature: using Zod 4 for internal stuff
- fd65bc6: chore(embedding-model-v2): rename rawResponse to response
- d92b9a8: fix(ai): add support for MCP protocol version 2025-06-18
- 102b066: fix (ai): fix invalid fetch call
- 142576e: feat (ui): support message replacement in chat via messageId param on sendMessage
- 84343eb: fix (ui): call sendAutomaticallyWhen with updated messages
- a76a62b: feat (ai): add experimental prepareStep callback to generateText
- 89ba235: fix (ui): support tool names with dash
- 8e31d46: feat (ai): export SourceDocumentUIPart
- bd398e4: fix (core): improve error handling in streamText's consumeStream method
- 88a8ee5: fix (ai): support abort during retry waits
- 205077b: fix: improve Zod compatibility
- d91b50d: chore(ui-utils): merge into ai package
- e4c8647: feat (ui): allow asynchronous onFinish in createUIMessageStream
- c808e4d: fix (ui): do not send changing assistant message ids when onFinish is provided
- e862b5b: feat (ai): allow sync tool.execute
- 395c85e: feat (ai): add consumeSseStream option to UI message stream responses
- 5bdff05: Removed deprecated `options.throwErrorForEmptyVectors` from `cosineSimilarity()`. Since `throwErrorForEmptyVectors` was the only option the entire `options` argument was removed.

  ```diff
  - cosineSimilarity(vector1, vector2, options)
  +cosineSimilarity(vector1, vector2)
  ```

- 13b4f46: feat (ai): export experimental MCPClient and MCPClientConfig interfaces
- a4f3007: chore: remove ai/react
- 8e64e9c: feat (ai): allow using provider default temperature by specifying null
- b983b51: feat (ai): support model message array in prompt
- 56c232b: fix (ai): remove outdated sendStart jsdoc
- 7324c21: fix (ai/telemetry): Avoid JSON.stringify on Uint8Arrays for telemetry
- f10304b: feat(tool-calling): don't require the user to have to pass parameters
- dd5fd43: feat (ai): support dynamic tools in Chat onToolCall
- a753b3a: feat (provider/anthropic): cache control for tools
- 383cbfa: feat (ai): add isAborted to onFinish callback for ui message streams
- 27deb4d: feat (provider/gateway): Add providerMetadata to embeddings response
- 5f2b3d4: chore (ai): stable prepareStep
- 4c8f834: feat: automatically respect rate limit headers in retry logic

  Added automatic support for respecting rate limit headers (`retry-after-ms` and `retry-after`) in the SDK's retry logic. When these headers are present and contain reasonable values (0-60 seconds), the retry mechanism will use the server-specified delay instead of exponential backoff. This matches the behavior of Anthropic and OpenAI client SDKs and improves rate limit handling without requiring any API changes.

- f2c7f19: feat (ui): add Chat.clearError()
- 7bd025b: fix (ai): fix sync tool execute with streamText
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0
  - @ai-sdk/provider@2.0.0
  - @ai-sdk/gateway@1.0.0

## 5.0.0-beta.34

### Patch Changes

- 53569b8: feat (ai): add experimental repairText function to streamObject
- 88a8ee5: fix (ai): support abort during retry waits
- f2c7f19: feat (ui): add Chat.clearError()
- Updated dependencies
  - @ai-sdk/gateway@1.0.0-beta.19
  - @ai-sdk/provider-utils@3.0.0-beta.10

## 5.0.0-beta.33

### Patch Changes

- 48378b9: fix (ai): send null as tool output when tools return undefined
- 93d53a1: chore (ai): remove cli
- 27deb4d: feat (provider/gateway): Add providerMetadata to embeddings response
- Updated dependencies [27deb4d]
  - @ai-sdk/gateway@1.0.0-beta.18
  - @ai-sdk/provider@2.0.0-beta.2
  - @ai-sdk/provider-utils@3.0.0-beta.9

## 5.0.0-beta.32

### Patch Changes

- bc24722: feat (ai): Add finishReason as a promise on StreamObjectResult to match StreamTextResult
- 13b4f46: feat (ai): export experimental MCPClient and MCPClientConfig interfaces
- 56c232b: fix (ai): remove outdated sendStart jsdoc

## 5.0.0-beta.31

### Patch Changes

- 6622441: feat (ai): add static/dynamic toolCalls/toolResults helpers
- ced8eee: feat(ai): re-export zodSchema from main package
- cee64b2: fix(otel): change back toolCall attributes of input/output back to args/result for compatibility
- ee38081: Add support for audio/webm to detect-media-type
- dd5fd43: feat (ai): support dynamic tools in Chat onToolCall
- Updated dependencies [dd5fd43]
  - @ai-sdk/provider-utils@3.0.0-beta.8
  - @ai-sdk/gateway@1.0.0-beta.17

## 5.0.0-beta.30

### Patch Changes

- Updated dependencies [fedb55e]
  - @ai-sdk/gateway@1.0.0-beta.16

## 5.0.0-beta.29

### Patch Changes

- e7fcc86: feat (ai): introduce dynamic tools
- d92b9a8: fix(ai): add support for MCP protocol version 2025-06-18
- Updated dependencies [e7fcc86]
  - @ai-sdk/provider-utils@3.0.0-beta.7
  - @ai-sdk/gateway@1.0.0-beta.15

## 5.0.0-beta.28

### Patch Changes

- 84343eb: fix (ui): call sendAutomaticallyWhen with updated messages
- a753b3a: feat (provider/anthropic): cache control for tools
- Updated dependencies [ac34802]
  - @ai-sdk/provider-utils@3.0.0-beta.6
  - @ai-sdk/gateway@1.0.0-beta.14

## 5.0.0-beta.27

### Patch Changes

- d5ae088: feat (ui): add sendAutomaticallyWhen to Chat
- Updated dependencies
  - @ai-sdk/gateway@1.0.0-beta.13

## 5.0.0-beta.26

### Patch Changes

- ae77a99: chore (ai): rename text and reasoning chunks in streamText fullstream
- 1f6ce57: feat (ai): infer tool call types in the `onToolCall` callback
- 5a975a4: feat (ui): update Chat tool result submission
- 2a62513: Fix error thrown when emptying messages in onError or onFinish
- 904fa5e: feat (ai/core): add terminateOnError option to readUIMessageStream
- f81c720: chore(ai): bundle dependencies in CLI binary
- Updated dependencies [70ebead]
  - @ai-sdk/gateway@1.0.0-beta.12

## 5.0.0-beta.25

### Patch Changes

- Updated dependencies
  - @ai-sdk/gateway@1.0.0-beta.11

## 5.0.0-beta.24

### Patch Changes

- add5ac1: feat (ai): make streamText toUIMessageStream async iterable
- ff1c81a: feat (ai): add streamText onAbort callback
- e4c8647: feat (ui): allow asynchronous onFinish in createUIMessageStream
- 383cbfa: feat (ai): add isAborted to onFinish callback for ui message streams
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-beta.5
  - @ai-sdk/gateway@1.0.0-beta.10

## 5.0.0-beta.23

### Patch Changes

- 89ba235: fix (ui): support tool names with dash

## 5.0.0-beta.22

### Patch Changes

- de2d2ab: feat(ai): add provider and provider registry middleware functionality
- 6c42e56: feat (ai): validate ui stream data chunks
- c93a8bc: chore(ai): export AsyncIterableStream type from async-iterable-stream module
- 20398f2: feat: ai sdk cli documentation + adjusted default model
- 86293e5: fix (ai): use correct generateMessageId in streamText toUIMessageStream
- 205077b: fix: improve Zod compatibility
- Updated dependencies [205077b]
  - @ai-sdk/provider-utils@3.0.0-beta.4
  - @ai-sdk/gateway@1.0.0-beta.9

## 5.0.0-beta.21

### Patch Changes

- 38ae5cc: feat (ai): export InferUIMessageChunk type
- faea29f: fix (provider/openai): multi-step reasoning with text
- 90ac328: fix (ui): tool part metadata support in ui messages
- 4a1e0c8: fix(ai-cli): fix bundling and improve authentication error handling
- 30ac566: fix (ui): text message metadata support in ui messages

## 5.0.0-beta.20

### Patch Changes

- 4c8f834: feat: automatically respect rate limit headers in retry logic

  Added automatic support for respecting rate limit headers (`retry-after-ms` and `retry-after`) in the SDK's retry logic. When these headers are present and contain reasonable values (0-60 seconds), the retry mechanism will use the server-specified delay instead of exponential backoff. This matches the behavior of Anthropic and OpenAI client SDKs and improves rate limit handling without requiring any API changes.

## 5.0.0-beta.19

### Patch Changes

- 10b21eb: feat(cli): add ai command line interface
- 75c3396: fix (ai): handle errors in 2nd streamText doStream call
- 05d2819: feat: allow zod 4.x as peer dependency
- db64cbe: fix (provider/openai): multi-step reasoning with tool calls
- Updated dependencies [05d2819]
  - @ai-sdk/provider-utils@3.0.0-beta.3
  - @ai-sdk/gateway@1.0.0-beta.8

## 5.0.0-beta.18

### Patch Changes

- d3960e3: selectTelemetryAttributes more robustness
- 9338f3e: fix (ai): throw error for v1 models

## 5.0.0-beta.17

### Patch Changes

- Updated dependencies [c190907]
  - @ai-sdk/gateway@1.0.0-beta.7

## 5.0.0-beta.16

### Patch Changes

- Updated dependencies [9e16bfd]
  - @ai-sdk/gateway@1.0.0-beta.6

## 5.0.0-beta.15

### Patch Changes

- 8e31d46: feat (ai): export SourceDocumentUIPart

## 5.0.0-beta.14

### Patch Changes

- Updated dependencies [30ab1de]
  - @ai-sdk/gateway@1.0.0-beta.5

## 5.0.0-beta.13

### Patch Changes

- 377bbcf: fix (ui): tool input can be undefined during input-streaming
- ce1d1f3: feat (ai): export mock image, speech, and transcription models
- c040e2f: fix (ui): inject generated response message id
- c808e4d: fix (ui): do not send changing assistant message ids when onFinish is provided

## 5.0.0-beta.12

### Patch Changes

- fc0380b: feat (ui): resolvable header, body, credentials in http chat transport
- 51f497d: feat (ai): step input message modification in prepareStep
- 4f3776c: feat (ai): add InferUITools helper

## 5.0.0-beta.11

### Patch Changes

- 9e40cbe: Allow destructuring output and errorText on `ToolUIPart` type

## 5.0.0-beta.10

### Major Changes

- 2b637d6: chore (ai): rename UIMessageStreamPart to UIMessageChunk

### Patch Changes

- 16ccfb2: feat (ai): add readUIMessageStream helper
- 90ca2b9: feat(ai): Record tool call errors on tool call spans recorded in `generateText` and `streamText`.
- af1d5a5: fix(ai): Unexpected reasoning-start event in extract reasoning middleware

## 5.0.0-beta.9

### Patch Changes

- 86cfc72: feat (ai): add ignoreIncompleteToolCalls option to convertToModelMessages

## 5.0.0-beta.8

### Patch Changes

- 6909543: feat (ai): support system parameter in Agent constructor
- c8fce91: feat (ai): add experimental Agent abstraction
- 9121250: Expose provider metadata as an attribute on exported OTEL spans
- Updated dependencies [97fedf9]
  - @ai-sdk/gateway@1.0.0-beta.4

## 5.0.0-beta.7

### Patch Changes

- 60132dd: fixed date formatting for updated mcp protocol version

## 5.0.0-beta.6

### Patch Changes

- 143c55b: feat (ai): export Chat callback types
- f04ffe4: feat (ui): add onData callback to Chat
- 97c35c0: feat (ui): transient data parts
- fccf75c: update mcp protocol version

## 5.0.0-beta.5

### Patch Changes

- 4f3e637: fix (ui): avoid caching globalThis.fetch in case it is patched by other libraries

## 5.0.0-beta.4

### Patch Changes

- 09f41ac: fix (ui): add message metadata in Chat.sendMessage

## 5.0.0-beta.3

### Patch Changes

- Updated dependencies
  - @ai-sdk/gateway@1.0.0-beta.3

## 5.0.0-beta.2

### Patch Changes

- 0d9583c: fix (ai): use user-provided media type when available
- c6b64a7: feat (ai): allow async prepareRequest on HttpChatTransport
- cb3b9c9: fix (ai): catch errors in ui message stream
- d1a034f: feature: using Zod 4 for internal stuff
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-beta.2
  - @ai-sdk/gateway@1.0.0-beta.2

## 5.0.0-beta.1

### Major Changes

- 9ad0484: feat (ai): automatic tool execution error handling

### Patch Changes

- d88455d: feat (ai): expose http chat transport type
- 4048ce3: fix (ai): add tests and examples for openai responses
- f2b041e: Fix custom `fetch` in HttpChatTransport
- cb68df0: feat: add transcription and speech model support to provider registry
- 26695a3: feat (ui): add state for text and reasoning ui message parts
- e7d2ce3: feat: provider-executed tools
- 102b066: fix (ai): fix invalid fetch call
- e862b5b: feat (ai): allow sync tool.execute
- 7bd025b: fix (ai): fix sync tool execute with streamText
- Updated dependencies
  - @ai-sdk/provider@2.0.0-beta.1
  - @ai-sdk/provider-utils@3.0.0-beta.1
  - @ai-sdk/gateway@1.0.0-beta.1

## 5.0.0-alpha.15

### Major Changes

- 04d5063: chore (ai): rename default provider global to AI_SDK_DEFAULT_PROVIDER
- b4b4bb2: chore (ui): rename experimental_resume to resumeStream
- d884051: feat (ai): simplify default provider setup
- 954aa73: feat (ui): extended regenerate support
- 60e2c56: feat (ai): restructure chat transports

### Patch Changes

- b1e3abd: feat (ai): expose ui message stream headers
- 142576e: feat (ui): support message replacement in chat via messageId param on sendMessage
- 395c85e: feat (ai): add consumeSseStream option to UI message stream responses
- Updated dependencies
  - @ai-sdk/provider@2.0.0-alpha.15
  - @ai-sdk/provider-utils@3.0.0-alpha.15
  - @ai-sdk/gateway@1.0.0-alpha.15

## 5.0.0-alpha.14

### Major Changes

- 63f9e9b: chore (provider,ai): tools have input/output instead of args,result

### Patch Changes

- Updated dependencies
  - @ai-sdk/provider@2.0.0-alpha.14
  - @ai-sdk/gateway@1.0.0-alpha.14
  - @ai-sdk/provider-utils@3.0.0-alpha.14

## 5.0.0-alpha.13

### Major Changes

- 0a710d8: feat (ui): typed tool parts in ui messages
- 6a83f7d: refactoring (ai): restructure message metadata transfer
- 1f55c21: chore (ai): send reasoning to the client by default
- 33eb499: feat (ai): inject message id in createUIMessageStream
- 901df02: feat (ui): use UI_MESSAGE generic

### Patch Changes

- Updated dependencies [68ecf2f]
  - @ai-sdk/provider@2.0.0-alpha.13
  - @ai-sdk/gateway@1.0.0-alpha.13
  - @ai-sdk/provider-utils@3.0.0-alpha.13

## 5.0.0-alpha.12

### Major Changes

- 4892798: chore (ai): always stream tool calls

### Patch Changes

- da1e6f0: feat (ui): add generics to ui message stream parts
- Updated dependencies [e2aceaf]
  - @ai-sdk/gateway@1.0.0-alpha.12
  - @ai-sdk/provider@2.0.0-alpha.12
  - @ai-sdk/provider-utils@3.0.0-alpha.12

## 5.0.0-alpha.11

### Major Changes

- e8324c5: feat (ai): add args callbacks to tools

### Patch Changes

- Updated dependencies [c1e6647]
  - @ai-sdk/provider@2.0.0-alpha.11
  - @ai-sdk/gateway@1.0.0-alpha.11
  - @ai-sdk/provider-utils@3.0.0-alpha.11

## 5.0.0-alpha.10

### Major Changes

- 98f25e5: chore (ui): remove managed chat inputs
- 7bb58d4: chore (ai): restructure prepareRequest

### Patch Changes

- Updated dependencies [c4df419]
  - @ai-sdk/provider@2.0.0-alpha.10
  - @ai-sdk/gateway@1.0.0-alpha.10
  - @ai-sdk/provider-utils@3.0.0-alpha.10

## 5.0.0-alpha.9

### Major Changes

- 9ae327d: chore (ui): replace chat store concept with chat instances

### Patch Changes

- 8255639: ### Fix use with Google APIs + zod v4's `.literal()` schema

  Before [zod@3.25.49](https://github.com/colinhacks/zod/releases/tag/v3.25.49), requests to Google's APIs failed due to a missing `type` in the provided schema. The problem has been resolved for the `ai` SDK by bumping our `zod` peer dependencies to `^3.25.49`.

  pull request: https://github.com/vercel/ai/pull/6609

- Updated dependencies
  - @ai-sdk/gateway@1.0.0-alpha.9
  - @ai-sdk/provider@2.0.0-alpha.9
  - @ai-sdk/provider-utils@3.0.0-alpha.9

## 5.0.0-alpha.8

### Major Changes

- c25cbce: feat (ai): use console.error as default error handler for streamText and streamObject

### Patch Changes

- 4fef487: feat: support for zod v4 for schema validation

  All these methods now accept both a zod v4 and zod v3 schemas for validation:

  - `generateObject()`
  - `streamObject()`
  - `generateText()`
  - `experimental_useObject()` from `@ai-sdk/react`
  - `streamUI()` from `@ai-sdk/rsc`

- 6b1c55c: feat (ai): introduce GLOBAL_DEFAULT_PROVIDER
- 2e4f9e4: feat (ai): improved error messages when using gateway
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-alpha.8
  - @ai-sdk/provider@2.0.0-alpha.8
  - @ai-sdk/gateway@1.0.0-alpha.8

## 5.0.0-alpha.7

### Major Changes

- db345da: chore (ai): remove exports of internal ui functions
- 247ee0c: chore (ai): remove steps from tool invocation ui parts

### Patch Changes

- 9b0da33: fix (ai): do not send id with start unless specified
- Updated dependencies [5c56081]
  - @ai-sdk/provider@2.0.0-alpha.7
  - @ai-sdk/gateway@1.0.0-alpha.7
  - @ai-sdk/provider-utils@3.0.0-alpha.7

## 5.0.0-alpha.6

### Patch Changes

- 0d2c085: feat (ai): support string model ids through gateway
- 48a7606: feat (ai): support changing the system prompt in prepareSteps
- Updated dependencies
  - @ai-sdk/provider@2.0.0-alpha.6
  - @ai-sdk/gateway@1.0.0-alpha.6
  - @ai-sdk/provider-utils@3.0.0-alpha.6

## 5.0.0-alpha.5

### Major Changes

- ef256ed: chore (ai): refactor and use chatstore in svelte
- 1ed0287: chore (ai): stable sendStart/sendFinish options

### Patch Changes

- 655cf3c: feat (ui): add onFinish to createUIMessageStream
- 1675396: fix: avoid job executor deadlock when adding tool result
- cf9af6e: feat (ai): allow sync prepareStep
- 825e8d7: release alpha.5
- 7324c21: fix (ai/telemetry): Avoid JSON.stringify on Uint8Arrays for telemetry

## 5.0.0-alpha.4

### Major Changes

- 72d7d72: chore (ai): stable activeTools
- 9315076: chore (ai): rename continueUntil to stopWhen. Rename maxSteps stop condition to isStepCount.

### Patch Changes

- b32c141: feat (ai): add array support to stopWhen
- 7d97ab6: release alpha.4
- 37a916d: feat (ai): add prepareSteps to streamText
- 5f2b3d4: chore (ai): stable prepareStep
- Updated dependencies [dc714f3]
  - @ai-sdk/provider@2.0.0-alpha.4
  - @ai-sdk/provider-utils@3.0.0-alpha.4

## 5.0.0-alpha.3

### Major Changes

- ab7ccef: chore (ai): change source ui message parts to source-url
- 257224b: chore (ai): separate TextStreamChatTransport
- 0463011: fix (ai): update source url stream part
- d306260: feat (ai): replace maxSteps with continueUntil (streamText)

### Patch Changes

- Updated dependencies [6b98118]
  - @ai-sdk/provider@2.0.0-alpha.3
  - @ai-sdk/provider-utils@3.0.0-alpha.3

## 5.0.0-alpha.2

### Patch Changes

- 82aa95d: fix (ai): merge data ui stream parts correctly
- Updated dependencies [26535e0]
  - @ai-sdk/provider@2.0.0-alpha.2
  - @ai-sdk/provider-utils@3.0.0-alpha.2

## 5.0.0-alpha.1

### Major Changes

- 109c0ac: chore (ai): rename id to chatId (in post request, resume request, and useChat)

### Patch Changes

- b346545: feat (ai): add data ui part schemas
- Updated dependencies [3f2f00c]
  - @ai-sdk/provider@2.0.0-alpha.1
  - @ai-sdk/provider-utils@3.0.0-alpha.1

## 5.0.0-canary.24

### Major Changes

- f7e8bf4: chore (ai): flatten ui message stream parts
- ed675de: feat (ai): add ui data parts
- 64f6d64: feat (ai): replace maxSteps with continueUntil (generateText)

### Patch Changes

- bedb239: chore (ai): make ui stream parts value optional when it's not required
- 507ac1d: fix (ui/react): update messages immediately with the submitted user message
- 2b9bbcd: feat (ai): improve prompt validation error message
- cda32ba: fix (ai): send `start` part in correct position in stream (streamText)
- 50f0362: fix (ai): fix experimental sendStart/sendFinish options in streamText
- Updated dependencies [faf8446]
  - @ai-sdk/provider-utils@3.0.0-canary.19

## 5.0.0-canary.23

### Major Changes

- 40acf9b: feat (ui): introduce ChatStore and ChatTransport

### Patch Changes

- Updated dependencies [40acf9b]
  - @ai-sdk/provider-utils@3.0.0-canary.18

## 5.0.0-canary.22

### Major Changes

- e7dc6c7: chore (ai): remove onResponse callback
- a34eb39: chore (ai): remove `data` and `allowEmptySubmit` from `ChatRequestOptions`
- b33ed7a: chore (ai): rename DataStream* to UIMessage*
- 765f1cd: chore (ai): remove deprecated useChat isLoading helper

## 5.0.0-canary.21

### Major Changes

- d964901: - remove setting temperature to `0` by default
  - remove `null` option from `DefaultSettingsMiddleware`
  - remove setting defaults for `temperature` and `stopSequences` in `ai` to enable middleware changes
- 0560977: chore (ai): improve consistency of generate text result, stream text result, and step result
- 516be5b: ### Move Image Model Settings into generate options

  Image Models no longer have settings. Instead, `maxImagesPerCall` can be passed directly to `generateImage()`. All other image settings can be passed to `providerOptions[provider]`.

  Before

  ```js
  await generateImage({
    model: luma.image("photon-flash-1", {
      maxImagesPerCall: 5,
      pollIntervalMillis: 500,
    }),
    prompt,
    n: 10,
  });
  ```

  After

  ```js
  await generateImage({
    model: luma.image("photon-flash-1"),
    prompt,
    n: 10,
    maxImagesPerCall: 5,
    providerOptions: {
      luma: { pollIntervalMillis: 5 },
    },
  });
  ```

  Pull Request: https://github.com/vercel/ai/pull/6180

- bfbfc4c: feat (ai): streamText/generateText: totalUsage contains usage for all steps. usage is for a single step.
- ea7a7c9: feat (ui): UI message metadata
- 1409e13: chore (ai): remove experimental continueSteps

### Patch Changes

- 66af894: fix (ai): respect content order in toResponseMessages
- Updated dependencies [ea7a7c9]
  - @ai-sdk/provider-utils@3.0.0-canary.17

## 5.0.0-canary.20

### Major Changes

- 13fef90: chore (ai): remove automatic conversion of UI messages to model messages
- 496bbc1: chore (ui): inline/remove ChatRequest type
- da70d79: chore (ai): remove getUIText helper
- c7710a9: chore (ai): rename DataStreamToSSETransformStream to JsonToSseTransformStream
- 35fc02c: chore (ui): rename RequestOptions to CompletionRequestOptions
- b983b51: feat (ai): support model message array in prompt

### Minor Changes

- bcea599: feat (ai): add content to generateText result
- 48d675a: feat (ai): add content to streamText result

### Patch Changes

- e90d45d: chore (rsc): move HANGING_STREAM_WARNING_TIME constant into @ai-sdk/rsc package
- bc3109f: chore (ai): push stream-callbacks into langchain/llamaindex adapters
- Updated dependencies [87b828f]
  - @ai-sdk/provider-utils@3.0.0-canary.16

## 5.0.0-canary.19

### Major Changes

- 2d03e19: chore (ai): remove StreamCallbacks.onCompletion
- 319b989: chore (ai): remove content from ui messages
- 441d042: chore (ui): data stream protocol v2 with SSEs
- dcc549b: remove StreamTextResult.mergeIntoDataStream method
  rename DataStreamOptions.getErrorMessage to onError
  add pipeTextStreamToResponse function
  add createTextStreamResponse function
  change createDataStreamResponse function to accept a DataStream and not a DataStreamWriter
  change pipeDataStreamToResponse function to accept a DataStream and not a DataStreamWriter
  change pipeDataStreamToResponse function to have a single parameter
- cb2b53a: chore (ai): refactor header preparation
- e244a78: chore (ai): remove StreamData and mergeStreams

## 5.0.0-canary.18

### Major Changes

- c60f895: chore (ai): remove useChat keepLastMessageOnError
- a662dea: chore (ai): remove sendExtraMessageFields

### Patch Changes

- a571d6e: chore(provider-utils): move ToolResultContent to provider-utils
- 332167b: chore (ai): move maxSteps into UseChatOptions
- a8c8bd5: feat(embed-many): respect supportsParallelCalls & concurrency
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-canary.15
  - @ai-sdk/provider@2.0.0-canary.14

## 5.0.0-canary.17

### Major Changes

- f04fb4a: chore (ai): replace useChat attachments with file ui parts
- fd1924b: chore (ai): remove redundant `mimeType` property
- fafc3f2: chore (ai): change file to parts to use urls instead of data
- 92cb0a2: chore (ai): rename CoreMessage to ModelMessage

### Minor Changes

- c9ad635: feat (ai): add filename to file ui parts

### Patch Changes

- 9bd5ab5: feat (provider): add providerMetadata to ImageModelV2 interface (#5977)

  The `experimental_generateImage` method from the `ai` package now returnes revised prompts for OpenAI's image models.

  ```js
  const prompt = "Santa Claus driving a Cadillac";

  const { providerMetadata } = await experimental_generateImage({
    model: openai.image("dall-e-3"),
    prompt,
  });

  const revisedPrompt = providerMetadata.openai.images[0]?.revisedPrompt;

  console.log({
    prompt,
    revisedPrompt,
  });
  ```

- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-canary.14
  - @ai-sdk/provider@2.0.0-canary.13

## 5.0.0-canary.16

### Major Changes

- ec78cdc: chore (ai): remove "data" UIMessage role
- 8b86e99: chore (ai): replace `Message` with `UIMessage`
- 2524fc7: chore (ai): remove ui message toolInvocations property
- 175b868: chore (ai): rename reasoning UI parts 'reasoning' property to 'text'

### Patch Changes

- 9b4d074: feat(streamObject): add enum support
- 28ad69e: fix(react-native): support experimental_attachments without FileList global
- ec5933d: chore (ai/mcp): add `assertCapability` method to experimental MCP client

## 5.0.0-canary.15

### Major Changes

- 4bfe9ec: chore (ai): remove ui message reasoning property
- 2877a74: chore (ai): remove ui message data property

### Patch Changes

- d9209ca: fix (image-model): `specificationVersion: v1` -> `v2`
- ea27cc6: chore (ai): use JSONValue definition from provider
- 0ff02bb: chore(provider-utils): move over jsonSchema
- Updated dependencies
  - @ai-sdk/provider@2.0.0-canary.12
  - @ai-sdk/provider-utils@3.0.0-canary.13

## 5.0.0-canary.14

### Patch Changes

- 9bf7291: chore(providers/openai): enable structuredOutputs by default & switch to provider option
- 4617fab: chore(embedding-models): remove remaining settings
- a76a62b: feat (ai): add experimental prepareStep callback to generateText
- Updated dependencies
  - @ai-sdk/provider@2.0.0-canary.11
  - @ai-sdk/provider-utils@3.0.0-canary.12

## 5.0.0-canary.13

### Patch Changes

- 14cb3be: chore(providers/llamaindex): extract to separate package
- 66962ed: fix(packages): export node10 compatible types
- 9301f86: refactor (image-model): rename `ImageModelV1` to `ImageModelV2`
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-canary.11
  - @ai-sdk/provider@2.0.0-canary.10

## 5.0.0-canary.12

### Patch Changes

- Updated dependencies [e86be6f]
  - @ai-sdk/provider@2.0.0-canary.9
  - @ai-sdk/provider-utils@3.0.0-canary.10

## 5.0.0-canary.11

### Patch Changes

- 8e64e9c: feat (ai): allow using provider default temperature by specifying null
- Updated dependencies
  - @ai-sdk/provider@2.0.0-canary.8
  - @ai-sdk/provider-utils@3.0.0-canary.9

## 5.0.0-canary.10

### Patch Changes

- d8aeaef: feat(providers/fal): add transcribe
- 3e10408: fix(utils/detect-mimetype): add support for detecting id3 tags

## 5.0.0-canary.9

### Major Changes

- a847c3e: chore: rename reasoning to reasoningText etc
- b32e192: chore (ai): rename reasoning to reasoningText, rename reasoningDetails to reasoning (streamText, generateText)

### Patch Changes

- cb9c9e4: remove deprecated `experimental_wrapLanguageModel`
- 8aa9e20: feat: add speech with experimental_generateSpeech
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-canary.8
  - @ai-sdk/provider@2.0.0-canary.7

## 5.0.0-canary.8

### Major Changes

- 14c9410: chore: refactor file towards source pattern (spec)

### Patch Changes

- 5d1e3ba: chore (ai): remove provider re-exports
- 26735b5: chore(embedding-model): add v2 interface
- 7827a49: fix (ai/core): refactor `toResponseMessages` to filter out empty string/content
- bd8a36c: feat(embedding-model-v2/embedMany): add response body field
- b6f9f3c: remove deprecated `CoreTool*` types
- 92c8e66: fix(ai/core): properly handle custom separator in provider registry
- fd65bc6: chore(embedding-model-v2): rename rawResponse to response
- 5bdff05: Removed deprecated `options.throwErrorForEmptyVectors` from `cosineSimilarity()`. Since `throwErrorForEmptyVectors` was the only option the entire `options` argument was removed.

  ```diff
  - cosineSimilarity(vector1, vector2, options)
  +cosineSimilarity(vector1, vector2)
  ```

- Updated dependencies
  - @ai-sdk/provider@2.0.0-canary.6
  - @ai-sdk/provider-utils@3.0.0-canary.7

## 5.0.0-canary.7

### Major Changes

- 6fba4c7: chore (ai): remove deprecated experimental_providerMetadata
- 1766ede: chore: rename maxTokens to maxOutputTokens

### Patch Changes

- 0b78e17: chore(ai/generateObject): simplify function signature
- 3e3b9df: fix (ai/mcp): better support for zero-argument MCP tools
- f10304b: feat(tool-calling): don't require the user to have to pass parameters
- Updated dependencies
  - @ai-sdk/provider@2.0.0-canary.5
  - @ai-sdk/provider-utils@3.0.0-canary.6

## 5.0.0-canary.6

### Patch Changes

- Updated dependencies [6f6bb89]
  - @ai-sdk/provider@2.0.0-canary.4
  - @ai-sdk/provider-utils@3.0.0-canary.5

## 5.0.0-canary.5

### Patch Changes

- b71fe8d: fix(ai): remove jsondiffpatch dependency
- d91b50d: chore(ui-utils): merge into ai package
- Updated dependencies [d1a1aa1]
  - @ai-sdk/provider@2.0.0-canary.3
  - @ai-sdk/provider-utils@3.0.0-canary.4

## 5.0.0-canary.4

### Major Changes

- e1cbf8a: chore(@ai-sdk/rsc): extract to separate package

### Patch Changes

- 225f087: fix (ai/mcp): prevent mutation of customEnv
- a166433: feat: add transcription with experimental_transcribe
- 0a87932: core (ai): change transcription model mimeType to mediaType
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-canary.3
  - @ai-sdk/provider@2.0.0-canary.2
  - @ai-sdk/ui-utils@2.0.0-canary.3

## 5.0.0-canary.3

### Patch Changes

- Updated dependencies
  - @ai-sdk/provider@2.0.0-canary.1
  - @ai-sdk/provider-utils@3.0.0-canary.2
  - @ai-sdk/ui-utils@2.0.0-canary.2

## 5.0.0-canary.2

### Patch Changes

- bd398e4: fix (core): improve error handling in streamText's consumeStream method

## 5.0.0-canary.1

### Minor Changes

- b7eae2d: feat (core): Add finishReason field to NoObjectGeneratedError

### Patch Changes

- c22ad54: feat(smooth-stream): chunking callbacks
- a4f3007: chore: remove ai/react
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-canary.1
  - @ai-sdk/ui-utils@2.0.0-canary.1

## 5.0.0-canary.0

### Major Changes

- d5f588f: AI SDK 5
- 9477ebb: chore (ui): remove useAssistant hook (**breaking change**)

### Patch Changes

- 8026705: fix (core): send buffered text in smooth stream when stream parts change
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-canary.0
  - @ai-sdk/ui-utils@2.0.0-canary.0
  - @ai-sdk/react@2.0.0-canary.0
  - @ai-sdk/provider@2.0.0-canary.0

## 4.2.10

### Patch Changes

- Updated dependencies
  - @ai-sdk/react@1.2.5
  - @ai-sdk/provider-utils@2.2.3
  - @ai-sdk/ui-utils@1.2.4

## 4.2.9

### Patch Changes

- Updated dependencies [b01120e]
  - @ai-sdk/provider-utils@2.2.2
  - @ai-sdk/react@1.2.4
  - @ai-sdk/ui-utils@1.2.3

## 4.2.8

### Patch Changes

- 65243ce: fix (ui): introduce step start parts
- Updated dependencies [65243ce]
  - @ai-sdk/ui-utils@1.2.2
  - @ai-sdk/react@1.2.3

## 4.2.7

### Patch Changes

- e14c066: fix (ai/core): convert user ui messages with only parts (no content) to core messages

## 4.2.6

### Patch Changes

- 625591b: feat (ai/core): auto-complete for provider registry
- 6a1506f: feat (ai/core): custom separator support for provider registry
- ea3d998: chore (ai/core): move provider registry to stable

## 4.2.5

### Patch Changes

- Updated dependencies [d92fa29]
  - @ai-sdk/react@1.2.2

## 4.2.4

### Patch Changes

- 3d6d96d: fix (ai/core): validate that messages are not empty

## 4.2.3

### Patch Changes

- 0b3bf29: fix (ai/core): custom env support for stdio MCP transport

## 4.2.2

### Patch Changes

- f10f0fa: fix (provider-utils): improve event source stream parsing performance
- Updated dependencies [f10f0fa]
  - @ai-sdk/provider-utils@2.2.1
  - @ai-sdk/react@1.2.1
  - @ai-sdk/ui-utils@1.2.1

## 4.2.1

### Patch Changes

- b796152: feat (ai/core): add headers to MCP SSE transport
- 06361d6: feat (ai/core): expose JSON RPC types (MCP)

## 4.2.0

### Minor Changes

- 5bc638d: AI SDK 4.2

### Patch Changes

- Updated dependencies [5bc638d]
  - @ai-sdk/provider@1.1.0
  - @ai-sdk/provider-utils@2.2.0
  - @ai-sdk/react@1.2.0
  - @ai-sdk/ui-utils@1.2.0

## 4.1.66

### Patch Changes

- 5d0fc29: chore (ai): improve cosine similarity calculation

## 4.1.65

### Patch Changes

- 16c444f: fix (ai): expose ai/mcp-stdio

## 4.1.64

### Patch Changes

- Updated dependencies [d0c4659]
  - @ai-sdk/provider-utils@2.1.15
  - @ai-sdk/react@1.1.25
  - @ai-sdk/ui-utils@1.1.21

## 4.1.63

### Patch Changes

- 0bd5bc6: feat (ai): support model-generated files
- Updated dependencies [0bd5bc6]
  - @ai-sdk/provider@1.0.12
  - @ai-sdk/provider-utils@2.1.14
  - @ai-sdk/ui-utils@1.1.20
  - @ai-sdk/react@1.1.24

## 4.1.62

### Patch Changes

- c9ed3c4: feat: enable custom mcp transports
  breaking change: remove internal stdio transport creation

## 4.1.61

### Patch Changes

- 2e1101a: feat (provider/openai): pdf input support
- Updated dependencies [2e1101a]
  - @ai-sdk/provider@1.0.11
  - @ai-sdk/provider-utils@2.1.13
  - @ai-sdk/ui-utils@1.1.19
  - @ai-sdk/react@1.1.23

## 4.1.60

### Patch Changes

- 0b8797f: feat (ai/core): expose response body for each generateText step

## 4.1.59

### Patch Changes

- dd18049: fix (ai/core): suppress next.js warnings for node.js specific code path

## 4.1.58

### Patch Changes

- e9897eb: fix (ai/core): move process access into functions and use globalThis

## 4.1.57

### Patch Changes

- 092fdaa: feat (ai/core): add defaultSettingsMiddleware

## 4.1.56

### Patch Changes

- 80be82b: feat (ai/core): add simulateStreamingMiddleware
- 8109a24: fix (ai/core): limit node imports to types where possible

## 4.1.55

### Patch Changes

- 1531959: feat (ai/core): add MCP client for using MCP tools
- Updated dependencies [1531959]
  - @ai-sdk/provider-utils@2.1.12
  - @ai-sdk/react@1.1.22
  - @ai-sdk/ui-utils@1.1.18

## 4.1.54

### Patch Changes

- ee1c787: fix (ai/core): correct spread apply order to fix extract reasoning middleware with generateText

## 4.1.53

### Patch Changes

- e1d3d42: feat (ai): expose raw response body in generateText and generateObject
- Updated dependencies [e1d3d42]
  - @ai-sdk/provider@1.0.10
  - @ai-sdk/provider-utils@2.1.11
  - @ai-sdk/ui-utils@1.1.17
  - @ai-sdk/react@1.1.21

## 4.1.52

### Patch Changes

- 5329a69: fix (ai/core): fix duplicated reasoning in streamText onFinish and messages

## 4.1.51

### Patch Changes

- 0cb2647: feat (ai/core): add streamText sendStart & sendFinish data stream options

## 4.1.50

### Patch Changes

- ae98f0d: fix (ai/core): forward providerOptions for text, image, and file parts

## 4.1.49

### Patch Changes

- dc027d3: fix (ai/core): add reasoning support to appendResponseMessages

## 4.1.48

### Patch Changes

- Updated dependencies [6255fbc]
  - @ai-sdk/react@1.1.20

## 4.1.47

### Patch Changes

- Updated dependencies [da5c734]
  - @ai-sdk/react@1.1.19

## 4.1.46

### Patch Changes

- ddf9740: feat (ai): add anthropic reasoning
- Updated dependencies [ddf9740]
  - @ai-sdk/provider@1.0.9
  - @ai-sdk/ui-utils@1.1.16
  - @ai-sdk/provider-utils@2.1.10
  - @ai-sdk/react@1.1.18

## 4.1.45

### Patch Changes

- 93bd5a0: feat (ai/ui): add writeSource to createDataStream

## 4.1.44

### Patch Changes

- f8e7df2: fix (ai/core): add `startWithReasoning` option to `extractReasoningMiddleware`

## 4.1.43

### Patch Changes

- ef2e23b: feat (ai/core): add experimental repairText function to generateObject

## 4.1.42

### Patch Changes

- Updated dependencies [2761f06]
  - @ai-sdk/provider@1.0.8
  - @ai-sdk/provider-utils@2.1.9
  - @ai-sdk/ui-utils@1.1.15
  - @ai-sdk/react@1.1.17

## 4.1.41

### Patch Changes

- Updated dependencies [60c3220]
  - @ai-sdk/react@1.1.16

## 4.1.40

### Patch Changes

- Updated dependencies [c43df41]
  - @ai-sdk/react@1.1.15

## 4.1.39

### Patch Changes

- 075a9a9: fix (ai): improve tsdoc on custom provider

## 4.1.38

### Patch Changes

- 4c9c194: chore (ai): add description to provider-defined tools for better accessibility
- 2e898b4: chore (ai): move mockId test helper into provider utils
- Updated dependencies [2e898b4]
  - @ai-sdk/provider-utils@2.1.8
  - @ai-sdk/react@1.1.14
  - @ai-sdk/ui-utils@1.1.14

## 4.1.37

### Patch Changes

- c1e10d1: chore: export UIMessage type

## 4.1.36

### Patch Changes

- Updated dependencies [3ff4ef8]
  - @ai-sdk/provider-utils@2.1.7
  - @ai-sdk/react@1.1.13
  - @ai-sdk/ui-utils@1.1.13

## 4.1.35

### Patch Changes

- 166e09e: feat (ai/ui): forward source parts to useChat
- Updated dependencies [166e09e]
  - @ai-sdk/ui-utils@1.1.12
  - @ai-sdk/react@1.1.12

## 4.1.34

### Patch Changes

- dc49119: chore: deprecate ai/react

## 4.1.33

### Patch Changes

- 74f0f0e: chore (ai/core): move providerMetadata to stable

## 4.1.32

### Patch Changes

- c128ca5: fix (ai/core): fix streamText onFinish messages with structured output

## 4.1.31

### Patch Changes

- b30b1cc: feat (ai/core): add onError callback to streamObject

## 4.1.30

### Patch Changes

- 4ee5b6f: fix (core): remove invalid providerOptions from streamObject onFinish callback

## 4.1.29

### Patch Changes

- 605de49: feat (ai/core): export callback types

## 4.1.28

### Patch Changes

- 6eb7fc4: feat (ai/core): url source support

## 4.1.27

### Patch Changes

- Updated dependencies [318b351]
  - @ai-sdk/ui-utils@1.1.11
  - @ai-sdk/react@1.1.11

## 4.1.26

### Patch Changes

- 34983d4: fix (ai/core): bind supportsUrl when creating wrapper

## 4.1.25

### Patch Changes

- 5a21310: fix (ai/core): use ai types on custom provider to prevent ts error

## 4.1.24

### Patch Changes

- 38142b8: feat (ai/core): introduce streamText consumeStream

## 4.1.23

### Patch Changes

- b08f7c1: fix (ai/core): suppress errors in textStream

## 4.1.22

### Patch Changes

- 2bec72a: feat (ai/core): add onError callback to streamText

## 4.1.21

### Patch Changes

- d387989: feat (ai/core): re-export zodSchema

## 4.1.20

### Patch Changes

- bcc61d4: feat (ui): introduce message parts for useChat
- Updated dependencies [bcc61d4]
  - @ai-sdk/ui-utils@1.1.10
  - @ai-sdk/react@1.1.10

## 4.1.19

### Patch Changes

- Updated dependencies [6b8cc14]
  - @ai-sdk/ui-utils@1.1.9
  - @ai-sdk/react@1.1.9

## 4.1.18

### Patch Changes

- 6a1acfe: fix (ai/core): revert '@internal' tag on function definitions due to build impacts

## 4.1.17

### Patch Changes

- 5af8cdb: fix (ai/core): support this reference in model.supportsUrl implementations

## 4.1.16

### Patch Changes

- 7e299a4: feat (ai/core): wrapLanguageModel can apply multiple middlewares

## 4.1.15

### Patch Changes

- d89c3b9: feat (provider): add image model support to provider specification
- d89c3b9: feat (core): type ahead for model ids with custom provider
- 08f54fc: chore (ai/core): move custom provider to stable
- Updated dependencies [d89c3b9]
  - @ai-sdk/provider@1.0.7
  - @ai-sdk/provider-utils@2.1.6
  - @ai-sdk/ui-utils@1.1.8
  - @ai-sdk/react@1.1.8

## 4.1.14

### Patch Changes

- ca89615: fix (ai/core): only append assistant response at the end when there is a final user message

## 4.1.13

### Patch Changes

- 999085e: feat (ai/core): add write function to DataStreamWriter

## 4.1.12

### Patch Changes

- 0d2d9bf: fix (ui): single assistant message with multiple tool steps
- Updated dependencies
  - @ai-sdk/react@1.1.7
  - @ai-sdk/ui-utils@1.1.7

## 4.1.11

### Patch Changes

- 4c58da5: chore (core): move providerOptions to stable

## 4.1.10

### Patch Changes

- bf2c9c6: feat (core): move middleware to stable

## 4.1.9

### Patch Changes

- 3a602ca: chore (core): rename CoreTool to Tool
- Updated dependencies [3a602ca]
  - @ai-sdk/provider-utils@2.1.5
  - @ai-sdk/ui-utils@1.1.6
  - @ai-sdk/react@1.1.6

## 4.1.8

### Patch Changes

- 92f5f36: feat (core): add extractReasoningMiddleware

## 4.1.7

### Patch Changes

- 066206e: feat (provider-utils): move delay to provider-utils from ai
- Updated dependencies [066206e]
  - @ai-sdk/provider-utils@2.1.4
  - @ai-sdk/react@1.1.5
  - @ai-sdk/ui-utils@1.1.5

## 4.1.6

### Patch Changes

- Updated dependencies [39e5c1f]
  - @ai-sdk/provider-utils@2.1.3
  - @ai-sdk/react@1.1.4
  - @ai-sdk/ui-utils@1.1.4

## 4.1.5

### Patch Changes

- 9ce598c: feat (ai/ui): add reasoning support to useChat
- Updated dependencies [9ce598c]
  - @ai-sdk/ui-utils@1.1.3
  - @ai-sdk/react@1.1.3

## 4.1.4

### Patch Changes

- caaad11: feat (ai/core): re-export languagemodelv1 types for middleware implementations
- caaad11: feat (ai/core): expose TelemetrySettings type

## 4.1.3

### Patch Changes

- 7f30a77: feat (core): export core message schemas
- 4298996: feat (core): add helper for merging single client message

## 4.1.2

### Patch Changes

- 3c5fafa: chore (ai/core): move streamText toolCallStreaming option to stable
- 3a58a2e: feat (ai/core): throw NoImageGeneratedError from generateImage when no predictions are returned.
- Updated dependencies
  - @ai-sdk/provider-utils@2.1.2
  - @ai-sdk/react@1.1.2
  - @ai-sdk/provider@1.0.6
  - @ai-sdk/ui-utils@1.1.2

## 4.1.1

### Patch Changes

- 0a699f1: feat: add reasoning token support
- Updated dependencies
  - @ai-sdk/ui-utils@1.1.1
  - @ai-sdk/provider-utils@2.1.1
  - @ai-sdk/provider@1.0.5
  - @ai-sdk/react@1.1.1

## 4.1.0

### Minor Changes

- 62ba5ad: release: AI SDK 4.1

### Patch Changes

- Updated dependencies [62ba5ad]
  - @ai-sdk/provider-utils@2.1.0
  - @ai-sdk/react@1.1.0
  - @ai-sdk/ui-utils@1.1.0

## 4.0.41

### Patch Changes

- Updated dependencies [44f04d5]
  - @ai-sdk/react@1.0.14

## 4.0.40

### Patch Changes

- 33592d2: fix (ai/core): switch to json schema 7 target for zod to json schema conversion
- Updated dependencies [33592d2]
  - @ai-sdk/ui-utils@1.0.12
  - @ai-sdk/react@1.0.13

## 4.0.39

### Patch Changes

- 00114c5: feat: expose IDGenerator and createIdGenerator
- 00114c5: feat (ui): generate and forward message ids for response messages
- Updated dependencies
  - @ai-sdk/provider-utils@2.0.8
  - @ai-sdk/ui-utils@1.0.11
  - @ai-sdk/react@1.0.12

## 4.0.38

### Patch Changes

- 0118fa7: fix (ai/core): handle empty tool invocation array in convertToCoreMessages

## 4.0.37

### Patch Changes

- 8304ed8: feat (ai/core): Add option `throwErrorForEmptyVectors` to cosineSimilarity
- ed28182: feat (ai/ui): add appendResponseMessages helper

## 4.0.36

### Patch Changes

- Updated dependencies [37f4510]
  - @ai-sdk/ui-utils@1.0.10
  - @ai-sdk/react@1.0.11

## 4.0.35

### Patch Changes

- 3491f78: feat (ai/core): support multiple stream text transforms

## 4.0.34

### Patch Changes

- 2495973: feat (ai/core): use openai compatible mode for json schema conversion
- 2495973: fix (ai/core): duplicate instead of using reference in json schema
- Updated dependencies
  - @ai-sdk/ui-utils@1.0.9
  - @ai-sdk/react@1.0.10

## 4.0.33

### Patch Changes

- 5510ee7: feat (ai/core): add stopStream option to streamText transforms

## 4.0.32

### Patch Changes

- de66619: feat (ai/core): add tool call id to ToolExecution error

## 4.0.31

### Patch Changes

- Updated dependencies
  - @ai-sdk/provider-utils@2.0.7
  - @ai-sdk/react@1.0.9
  - @ai-sdk/ui-utils@1.0.8

## 4.0.30

### Patch Changes

- e4ce80c: fix (ai/core): prevent onFinish from masking stream errors

## 4.0.29

### Patch Changes

- a92f5f6: feat (ai/core): generate many images with parallel model calls

## 4.0.28

### Patch Changes

- 19a2ce7: feat (ai/core): add aspectRatio and seed options to generateImage
- 6337688: feat: change image generation errors to warnings
- 8b422ea: feat (ai/core): add caching to generated images
- Updated dependencies
  - @ai-sdk/provider@1.0.4
  - @ai-sdk/provider-utils@2.0.6
  - @ai-sdk/ui-utils@1.0.7
  - @ai-sdk/react@1.0.8

## 4.0.27

### Patch Changes

- a56734f: feat (ai/core): export simulateReadableStream in ai package
- 9589601: feat (ai/core): support null delay in smoothStream
- e3cc23a: feat (ai/core): support regexp chunking pattern in smoothStream
- e463e73: feat (ai/core): support skipping delays in simulateReadableStream

## 4.0.26

### Patch Changes

- a8f3242: feat (ai/core): add line chunking mode to smoothStream

## 4.0.25

### Patch Changes

- 0823899: fix (ai/core): throw error when accessing output when no output is defined in generateText (breaking/experimental)

## 4.0.24

### Patch Changes

- ae0485b: feat (ai/core): add experimental output setting to streamText

## 4.0.23

### Patch Changes

- bc4cd19: feat (ai/core): consolidate whitespace in smooth stream

## 4.0.22

### Patch Changes

- Updated dependencies [5ed5e45]
  - @ai-sdk/provider-utils@2.0.5
  - @ai-sdk/provider@1.0.3
  - @ai-sdk/react@1.0.7
  - @ai-sdk/ui-utils@1.0.6

## 4.0.21

### Patch Changes

- a8669a2: fix (ai/core): prefer auto-detected image mimetype
- 6fb3e91: fix (ai/core): include type in generateText toolResults result property.

## 4.0.20

### Patch Changes

- da9d240: fix (ai/core): suppress errors caused by writing to closed stream
- 6f1bfde: fix (ai/core): invoke streamText tool call repair when tool cannot be found

## 4.0.19

### Patch Changes

- c3a6065: fix (ai/core): apply transform before callbacks and resolvables

## 4.0.18

### Patch Changes

- 304e6d3: feat (ai/core): standardize generateObject, streamObject, and output errors to NoObjectGeneratedError
- 304e6d3: feat (ai/core): add additional information to NoObjectGeneratedError

## 4.0.17

### Patch Changes

- 54bbf21: fix (ai/core): change streamText.experimental_transform signature to support tool type inference

## 4.0.16

### Patch Changes

- e3fac3f: fix (ai/core): change smoothStream default delay to 10ms

## 4.0.15

### Patch Changes

- cc16a83: feat (ai/core): add smoothStream helper
- cc16a83: feat (ai/core): add experimental transform option to streamText

## 4.0.14

### Patch Changes

- 09a9cab: feat (ai/core): add experimental generateImage function
- Updated dependencies [09a9cab]
  - @ai-sdk/provider@1.0.2
  - @ai-sdk/provider-utils@2.0.4
  - @ai-sdk/ui-utils@1.0.5
  - @ai-sdk/react@1.0.6

## 4.0.13

### Patch Changes

- 9f32213: feat (ai/core): add experimental tool call repair

## 4.0.12

### Patch Changes

- 5167bec: fix (ai/core): forward streamText errors as error parts
- 0984f0b: feat (ai/core): add ToolExecutionError type
- Updated dependencies [0984f0b]
  - @ai-sdk/provider-utils@2.0.3
  - @ai-sdk/react@1.0.5
  - @ai-sdk/ui-utils@1.0.4

## 4.0.11

### Patch Changes

- Updated dependencies
  - @ai-sdk/ui-utils@1.0.3
  - @ai-sdk/react@1.0.4

## 4.0.10

### Patch Changes

- 913872d: fix (ai/core): track promise from async createDataStream.execute

## 4.0.9

### Patch Changes

- fda9695: feat (ai/core): reworked data stream management

## 4.0.8

### Patch Changes

- a803d76: feat (ai/core): pass toolCallId option into tool execute function

## 4.0.7

### Patch Changes

- 5b4f07b: fix (ai/core): change default error message for data streams to "An error occurred."

## 4.0.6

### Patch Changes

- fc18132: feat (ai/core): experimental output for generateText
- 2779f6d: fix (ai/core): do not send maxRetries into providers

## 4.0.5

### Patch Changes

- Updated dependencies [630ac31]
  - @ai-sdk/react@1.0.3

## 4.0.4

### Patch Changes

- 6ff6689: fix (ai): trigger onFinal when stream adapter finishes
- 6ff6689: chore (ai): deprecate onCompletion (stream callbacks)

## 4.0.3

### Patch Changes

- Updated dependencies
  - @ai-sdk/ui-utils@1.0.2
  - @ai-sdk/provider@1.0.1
  - @ai-sdk/react@1.0.2
  - @ai-sdk/provider-utils@2.0.2

## 4.0.2

### Patch Changes

- Updated dependencies [c3ab5de]
  - @ai-sdk/provider-utils@2.0.1
  - @ai-sdk/react@1.0.1
  - @ai-sdk/ui-utils@1.0.1

## 4.0.1

### Patch Changes

- b117255: feat (ai/core): add messages to tool call options

## 4.0.0

### Major Changes

- 4e38b38: chore (ai): remove LanguageModelResponseMetadataWithHeaders type
- 8bf5756: chore: remove legacy function/tool calling
- f0cb69d: chore (ai/core): remove experimental function exports
- da8c609: chore (ai): remove Tokens RSC helper
- cbab571: chore (ai): remove ExperimentalXXXMessage types
- b469a7e: chore: remove isXXXError methods
- 54cb888: chore (ai): remove experimental_StreamData export
- 4d61295: chore (ai): remove streamToResponse and streamingTextResponse
- 9a3d741: chore (ai): remove ExperimentalTool export
- 064257d: chore (ai/core): rename simulateReadableStream values parameter to chunks
- 60e69ed: chore (ai/core): remove ai-stream related methods from streamText
- a4f8ce9: chore (ai): AssistantResponse cleanups
- d3ae4f6: chore (ui/react): remove useObject setInput helper
- 7264b0a: chore (ai): remove responseMessages property from streamText/generateText result
- b801982: chore (ai/core): remove init option from streamText result methods
- f68d7b1: chore (ai/core): streamObject returns result immediately (no Promise)
- 6090cea: chore (ai): remove rawResponse from generate/stream result objects
- 073f282: chore (ai): remove AIStream and related exports
- 1c58337: chore (ai): remove 2.x prompt helpers
- a40a93d: chore (ai/ui): remove vue, svelte, solid re-export and dependency
- a7ad35a: chore: remove legacy providers & rsc render
- c0ddc24: chore (ai): remove toJSON method from AI SDK errors
- 007cb81: chore (ai): change `streamText` warnings result to Promise
- effbce3: chore (ai): remove responseMessage from streamText onFinish callback
- 545d133: chore (ai): remove deprecated roundtrip settings from streamText / generateText
- 7e89ccb: chore: remove nanoid export
- f967199: chore (ai/core): streamText returns result immediately (no Promise)
- 62d08fd: chore (ai): remove TokenUsage, CompletionTokenUsage, and EmbeddingTokenUsage types
- e5d2ce8: chore (ai): remove deprecated provider registry exports
- 70ce742: chore (ai): remove experimental_continuationSteps option
- 2f09717: chore (ai): remove deprecated telemetry data
- 0827bf9: chore (ai): remove LangChain adapter `toAIStream` method

### Patch Changes

- dce4158: chore (dependencies): update eventsource-parser to 3.0.0
- f0ec721: chore (ai): remove openai peer dependency
- f9bb30c: chore (ai): remove unnecessary dev dependencies
- b053413: chore (ui): refactorings & README update
- Updated dependencies
  - @ai-sdk/react@1.0.0
  - @ai-sdk/ui-utils@1.0.0
  - @ai-sdk/provider-utils@2.0.0
  - @ai-sdk/provider@1.0.0

## 4.0.0-canary.13

### Major Changes

- 064257d: chore (ai/core): rename simulateReadableStream values parameter to chunks

### Patch Changes

- Updated dependencies
  - @ai-sdk/react@1.0.0-canary.9
  - @ai-sdk/ui-utils@1.0.0-canary.9

## 4.0.0-canary.12

### Patch Changes

- b053413: chore (ui): refactorings & README update
- Updated dependencies [b053413]
  - @ai-sdk/ui-utils@1.0.0-canary.8
  - @ai-sdk/react@1.0.0-canary.8

## 4.0.0-canary.11

### Major Changes

- f68d7b1: chore (ai/core): streamObject returns result immediately (no Promise)
- f967199: chore (ai/core): streamText returns result immediately (no Promise)

## 4.0.0-canary.10

### Major Changes

- effbce3: chore (ai): remove responseMessage from streamText onFinish callback

### Patch Changes

- Updated dependencies [fe4f109]
  - @ai-sdk/ui-utils@1.0.0-canary.7
  - @ai-sdk/react@1.0.0-canary.7

## 4.0.0-canary.9

### Patch Changes

- f0ec721: chore (ai): remove openai peer dependency

## 4.0.0-canary.8

### Major Changes

- 007cb81: chore (ai): change `streamText` warnings result to Promise

### Patch Changes

- Updated dependencies [70f28f6]
  - @ai-sdk/ui-utils@1.0.0-canary.6
  - @ai-sdk/react@1.0.0-canary.6

## 4.0.0-canary.7

### Major Changes

- 4e38b38: chore (ai): remove LanguageModelResponseMetadataWithHeaders type
- 54cb888: chore (ai): remove experimental_StreamData export
- 9a3d741: chore (ai): remove ExperimentalTool export
- a4f8ce9: chore (ai): AssistantResponse cleanups
- 7264b0a: chore (ai): remove responseMessages property from streamText/generateText result
- 62d08fd: chore (ai): remove TokenUsage, CompletionTokenUsage, and EmbeddingTokenUsage types
- e5d2ce8: chore (ai): remove deprecated provider registry exports
- 70ce742: chore (ai): remove experimental_continuationSteps option
- 0827bf9: chore (ai): remove LangChain adapter `toAIStream` method

## 4.0.0-canary.6

### Major Changes

- b801982: chore (ai/core): remove init option from streamText result methods

### Patch Changes

- f9bb30c: chore (ai): remove unnecessary dev dependencies

## 4.0.0-canary.5

### Major Changes

- 4d61295: chore (ai): remove streamToResponse and streamingTextResponse
- d3ae4f6: chore (ui/react): remove useObject setInput helper
- 6090cea: chore (ai): remove rawResponse from generate/stream result objects
- 2f09717: chore (ai): remove deprecated telemetry data

### Patch Changes

- Updated dependencies
  - @ai-sdk/ui-utils@1.0.0-canary.5
  - @ai-sdk/react@1.0.0-canary.5
  - @ai-sdk/provider-utils@2.0.0-canary.3

## 4.0.0-canary.4

### Major Changes

- f0cb69d: chore (ai/core): remove experimental function exports
- da8c609: chore (ai): remove Tokens RSC helper
- cbab571: chore (ai): remove ExperimentalXXXMessage types
- 60e69ed: chore (ai/core): remove ai-stream related methods from streamText
- 073f282: chore (ai): remove AIStream and related exports
- 545d133: chore (ai): remove deprecated roundtrip settings from streamText / generateText

### Patch Changes

- dce4158: chore (dependencies): update eventsource-parser to 3.0.0
- Updated dependencies
  - @ai-sdk/provider-utils@2.0.0-canary.2
  - @ai-sdk/react@1.0.0-canary.4
  - @ai-sdk/ui-utils@1.0.0-canary.4

## 4.0.0-canary.3

### Patch Changes

- Updated dependencies
  - @ai-sdk/react@1.0.0-canary.3
  - @ai-sdk/provider-utils@2.0.0-canary.1
  - @ai-sdk/ui-utils@1.0.0-canary.3

## 4.0.0-canary.2

### Major Changes

- b469a7e: chore: remove isXXXError methods
- c0ddc24: chore (ai): remove toJSON method from AI SDK errors

### Patch Changes

- Updated dependencies
  - @ai-sdk/react@1.0.0-canary.2
  - @ai-sdk/provider-utils@2.0.0-canary.0
  - @ai-sdk/provider@1.0.0-canary.0
  - @ai-sdk/ui-utils@1.0.0-canary.2

## 4.0.0-canary.1

### Major Changes

- 8bf5756: chore: remove legacy function/tool calling

### Patch Changes

- 1c58337: chore (ai): remove 2.x prompt helpers
- Updated dependencies [8bf5756]
  - @ai-sdk/ui-utils@1.0.0-canary.1
  - @ai-sdk/react@1.0.0-canary.1

## 4.0.0-canary.0

### Major Changes

- a40a93d: chore (ai/ui): remove vue, svelte, solid re-export and dependency

### Patch Changes

- a7ad35a: chore: remove legacy providers & rsc render
- 7e89ccb: chore: remove nanoid export
- Updated dependencies
  - @ai-sdk/react@1.0.0-canary.0
  - @ai-sdk/ui-utils@1.0.0-canary.0

## 3.4.33

### Patch Changes

- ac380e3: fix (provider/anthropic): continuation mode with 3+ steps

## 3.4.32

### Patch Changes

- 6bb9e51: fix (ai/core): expose response.messages in streamText

## 3.4.31

### Patch Changes

- Updated dependencies [2dfb93e]
  - @ai-sdk/react@0.0.70

## 3.4.30

### Patch Changes

- Updated dependencies [a85c965]
  - @ai-sdk/ui-utils@0.0.50
  - @ai-sdk/react@0.0.69
  - @ai-sdk/solid@0.0.54
  - @ai-sdk/svelte@0.0.57
  - @ai-sdk/vue@0.0.59

## 3.4.29

### Patch Changes

- 54b56f7: feat (ai/core): send tool and tool choice telemetry data

## 3.4.28

### Patch Changes

- 29f1390: feat (ai/test): add simulateReadableStream helper

## 3.4.27

### Patch Changes

- fa772ae: feat (ai/core): automatically convert ui messages to core messages

## 3.4.26

### Patch Changes

- 57f39ea: feat (ai/core): support multi-modal tool results in convertToCoreMessages

## 3.4.25

### Patch Changes

- 6e0fa1c: fix (ai/core): wait for tool results to arrive before sending finish event

## 3.4.24

### Patch Changes

- d92fd9f: feat (ui/svelte): support Svelte 5 peer dependency
- Updated dependencies [d92fd9f]
  - @ai-sdk/svelte@0.0.56

## 3.4.23

### Patch Changes

- 8301e41: fix (ai/react): update React peer dependency version to allow rc releases.
- Updated dependencies [8301e41]
  - @ai-sdk/react@0.0.68

## 3.4.22

### Patch Changes

- Updated dependencies [3bf8da0]
  - @ai-sdk/ui-utils@0.0.49
  - @ai-sdk/react@0.0.67
  - @ai-sdk/solid@0.0.53
  - @ai-sdk/svelte@0.0.55
  - @ai-sdk/vue@0.0.58

## 3.4.21

### Patch Changes

- 3954471: (experimental) fix passing "experimental_toToolResultContent" into PoolResultPart

## 3.4.20

### Patch Changes

- aa98cdb: chore: more flexible dependency versioning
- 1486128: feat: add supportsUrl to language model specification
- 3b1b69a: feat: provider-defined tools
- 85b98da: revert fix (ai/core): handle tool calls without results in message conversion
- 7ceed77: feat (ai/core): expose response message for each step
- 811a317: feat (ai/core): multi-part tool results (incl. images)
- Updated dependencies
  - @ai-sdk/provider-utils@1.0.22
  - @ai-sdk/provider@0.0.26
  - @ai-sdk/ui-utils@0.0.48
  - @ai-sdk/svelte@0.0.54
  - @ai-sdk/react@0.0.66
  - @ai-sdk/vue@0.0.57
  - @ai-sdk/solid@0.0.52

## 3.4.19

### Patch Changes

- b9b0d7b: feat (ai): access raw request body
- Updated dependencies [b9b0d7b]
  - @ai-sdk/provider@0.0.25
  - @ai-sdk/provider-utils@1.0.21
  - @ai-sdk/ui-utils@0.0.47
  - @ai-sdk/react@0.0.65
  - @ai-sdk/solid@0.0.51
  - @ai-sdk/svelte@0.0.53
  - @ai-sdk/vue@0.0.56

## 3.4.18

### Patch Changes

- 95c67b4: fix (ai/core): handle tool calls without results in message conversion

## 3.4.17

### Patch Changes

- e4ff512: fix (core): prevent unnecessary input/output serialization when telemetry is not enabled

## 3.4.16

### Patch Changes

- 01dcc44: feat (ai/core): add experimental activeTools option to generateText and streamText

## 3.4.15

### Patch Changes

- Updated dependencies [98a3b08]
  - @ai-sdk/react@0.0.64

## 3.4.14

### Patch Changes

- e930f40: feat (ai/core): expose core tool result and tool call types

## 3.4.13

### Patch Changes

- fc39158: fix (ai/core): add abortSignal to tool helper function

## 3.4.12

### Patch Changes

- a23da5b: feat (ai/core): forward abort signal to tools

## 3.4.11

### Patch Changes

- caedcda: feat (ai/ui): add setData helper to useChat
- Updated dependencies [caedcda]
  - @ai-sdk/svelte@0.0.52
  - @ai-sdk/react@0.0.63
  - @ai-sdk/solid@0.0.50
  - @ai-sdk/vue@0.0.55

## 3.4.10

### Patch Changes

- 0b557d7: feat (ai/core): add tracer option to telemetry settings
- 44f6bc5: feat (ai/core): expose StepResult type

## 3.4.9

### Patch Changes

- d347538: fix (ai/core): export FilePart interface

## 3.4.8

### Patch Changes

- Updated dependencies [b5f577e]
  - @ai-sdk/vue@0.0.54

## 3.4.7

### Patch Changes

- db04700: feat (core): support converting attachments to file parts
- 988707c: feat (ai/core): automatically download files from urls

## 3.4.6

### Patch Changes

- d595d0d: feat (ai/core): file content parts
- Updated dependencies [d595d0d]
  - @ai-sdk/provider@0.0.24
  - @ai-sdk/provider-utils@1.0.20
  - @ai-sdk/ui-utils@0.0.46
  - @ai-sdk/react@0.0.62
  - @ai-sdk/solid@0.0.49
  - @ai-sdk/svelte@0.0.51
  - @ai-sdk/vue@0.0.53

## 3.4.5

### Patch Changes

- cd77c5d: feat (ai/core): add isContinued to steps
- Updated dependencies [cd77c5d]
  - @ai-sdk/ui-utils@0.0.45
  - @ai-sdk/react@0.0.61
  - @ai-sdk/solid@0.0.48
  - @ai-sdk/svelte@0.0.50
  - @ai-sdk/vue@0.0.52

## 3.4.4

### Patch Changes

- 4db074b: fix (ai/core): correct whitespace in generateText continueSteps
- 1297e1b: fix (ai/core): correct whitespace in streamText continueSteps

## 3.4.3

### Patch Changes

- b270ae3: feat (ai/core): streamText continueSteps (experimental)
- b270ae3: chore (ai/core): rename generateText continuationSteps to continueSteps

## 3.4.2

### Patch Changes

- e6c7e98: feat (ai/core): add continuationSteps to generateText

## 3.4.1

### Patch Changes

- Updated dependencies [7e7104f]
  - @ai-sdk/react@0.0.60

## 3.4.0

### Minor Changes

- c0cea03: release (ai): 3.4

## 3.3.44

### Patch Changes

- Updated dependencies [d3933e0]
  - @ai-sdk/vue@0.0.51

## 3.3.43

### Patch Changes

- fea6bec: fix (ai/core): support tool calls without arguments

## 3.3.42

### Patch Changes

- de37aee: feat (ai): Add support for LlamaIndex

## 3.3.41

### Patch Changes

- Updated dependencies [692e265]
  - @ai-sdk/vue@0.0.50

## 3.3.40

### Patch Changes

- a91c308: feat (ai/core): add responseMessages to streamText

## 3.3.39

### Patch Changes

- 33cf3e1: feat (ai/core): add providerMetadata to StepResult
- 17ee757: feat (ai/core): add onStepFinish callback to generateText

## 3.3.38

### Patch Changes

- 83da52c: feat (ai/core): add onStepFinish callback to streamText

## 3.3.37

### Patch Changes

- Updated dependencies [273f696]
  - @ai-sdk/provider-utils@1.0.19
  - @ai-sdk/react@0.0.59
  - @ai-sdk/solid@0.0.47
  - @ai-sdk/svelte@0.0.49
  - @ai-sdk/ui-utils@0.0.44
  - @ai-sdk/vue@0.0.49

## 3.3.36

### Patch Changes

- a3882f5: feat (ai/core): add steps property to streamText result and onFinish callback
- 1f590ef: chore (ai): rename roundtrips to steps
- 7e82d36: fix (ai/core): pass topK to providers
- Updated dependencies
  - @ai-sdk/react@0.0.58
  - @ai-sdk/ui-utils@0.0.43
  - @ai-sdk/solid@0.0.46
  - @ai-sdk/svelte@0.0.48
  - @ai-sdk/vue@0.0.48

## 3.3.35

### Patch Changes

- 14210d5: feat (ai/core): add sendUsage information to streamText data stream methods
- Updated dependencies [14210d5]
  - @ai-sdk/ui-utils@0.0.42
  - @ai-sdk/react@0.0.57
  - @ai-sdk/solid@0.0.45
  - @ai-sdk/svelte@0.0.47
  - @ai-sdk/vue@0.0.47

## 3.3.34

### Patch Changes

- a0403d6: feat (react): support sending attachments using append
- 678449a: feat (ai/core): export test helpers
- ff22fac: fix (ai/rsc): streamUI onFinish is called when tool calls have finished
- Updated dependencies [a0403d6]
  - @ai-sdk/react@0.0.56

## 3.3.33

### Patch Changes

- cbddc83: fix (ai/core): filter out empty text parts

## 3.3.32

### Patch Changes

- ce7a4af: feat (ai/core): support providerMetadata in functions

## 3.3.31

### Patch Changes

- 561fd7e: feat (ai/core): add output: enum to generateObject

## 3.3.30

### Patch Changes

- 6ee1f8e: feat (ai/core): add toDataStream to streamText result

## 3.3.29

### Patch Changes

- 1e3dfd2: feat (ai/core): enhance pipeToData/TextStreamResponse methods

## 3.3.28

### Patch Changes

- db61c53: feat (ai/core): middleware support

## 3.3.27

### Patch Changes

- 03313cd: feat (ai): expose response id, response model, response timestamp in telemetry and api
- 3be7c1c: fix (provider/anthropic): support prompt caching on assistant messages
- Updated dependencies
  - @ai-sdk/provider-utils@1.0.18
  - @ai-sdk/provider@0.0.23
  - @ai-sdk/react@0.0.55
  - @ai-sdk/solid@0.0.44
  - @ai-sdk/svelte@0.0.46
  - @ai-sdk/ui-utils@0.0.41
  - @ai-sdk/vue@0.0.46

## 3.3.26

### Patch Changes

- Updated dependencies [4ab883f]
  - @ai-sdk/react@0.0.54

## 3.3.25

### Patch Changes

- 4f1530f: feat (ai/core): add OpenTelemetry Semantic Conventions for GenAI operations to v1.27.0 of standard
- dad775f: feat (ai/core): add finish event and avg output tokens per second (telemetry)

## 3.3.24

### Patch Changes

- d87a655: fix (ai/core): provide fallback when globalThis.performance is not available

## 3.3.23

### Patch Changes

- b55e6f7: fix (ai/core): streamObject text stream in array mode must not include elements: prefix.

## 3.3.22

### Patch Changes

- a5a56fd: fix (ai/core): only send roundtrip-finish event after async tool calls are done

## 3.3.21

### Patch Changes

- aa2dc58: feat (ai/core): add maxToolRoundtrips to streamText
- Updated dependencies [aa2dc58]
  - @ai-sdk/ui-utils@0.0.40
  - @ai-sdk/react@0.0.53
  - @ai-sdk/solid@0.0.43
  - @ai-sdk/svelte@0.0.45
  - @ai-sdk/vue@0.0.45

## 3.3.20

### Patch Changes

- 7807677: fix (rsc): Deep clone currentState in getMutableState()

## 3.3.19

### Patch Changes

- 7235de0: fix (ai/core): convertToCoreMessages accepts Message[]

## 3.3.18

### Patch Changes

- 9e3b5a5: feat (ai/core): add experimental_customProvider
- 26515cb: feat (ai/provider): introduce ProviderV1 specification
- Updated dependencies [26515cb]
  - @ai-sdk/provider@0.0.22
  - @ai-sdk/provider-utils@1.0.17
  - @ai-sdk/ui-utils@0.0.39
  - @ai-sdk/react@0.0.52
  - @ai-sdk/solid@0.0.42
  - @ai-sdk/svelte@0.0.44
  - @ai-sdk/vue@0.0.44

## 3.3.17

### Patch Changes

- d151349: feat (ai/core): array output for generateObject / streamObject
- Updated dependencies [d151349]
  - @ai-sdk/ui-utils@0.0.38
  - @ai-sdk/react@0.0.51
  - @ai-sdk/solid@0.0.41
  - @ai-sdk/svelte@0.0.43
  - @ai-sdk/vue@0.0.43

## 3.3.16

### Patch Changes

- 09f895f: feat (ai/core): no-schema output for generateObject / streamObject
- Updated dependencies [09f895f]
  - @ai-sdk/provider-utils@1.0.16
  - @ai-sdk/react@0.0.50
  - @ai-sdk/solid@0.0.40
  - @ai-sdk/svelte@0.0.42
  - @ai-sdk/ui-utils@0.0.37
  - @ai-sdk/vue@0.0.42

## 3.3.15

### Patch Changes

- b5a82b7: chore (ai): update zod-to-json-schema to 3.23.2
- Updated dependencies [b5a82b7]
  - @ai-sdk/ui-utils@0.0.36
  - @ai-sdk/react@0.0.49
  - @ai-sdk/solid@0.0.39
  - @ai-sdk/svelte@0.0.41
  - @ai-sdk/vue@0.0.41

## 3.3.14

### Patch Changes

- Updated dependencies [d67fa9c]
  - @ai-sdk/provider-utils@1.0.15
  - @ai-sdk/react@0.0.48
  - @ai-sdk/solid@0.0.38
  - @ai-sdk/svelte@0.0.40
  - @ai-sdk/ui-utils@0.0.35
  - @ai-sdk/vue@0.0.40

## 3.3.13

### Patch Changes

- 412f943: fix (ai/core): make Buffer validation optional for environments without buffer

## 3.3.12

### Patch Changes

- f2c025e: feat (ai/core): prompt validation
- Updated dependencies [f2c025e]
  - @ai-sdk/provider@0.0.21
  - @ai-sdk/provider-utils@1.0.14
  - @ai-sdk/ui-utils@0.0.34
  - @ai-sdk/react@0.0.47
  - @ai-sdk/solid@0.0.37
  - @ai-sdk/svelte@0.0.39
  - @ai-sdk/vue@0.0.39

## 3.3.11

### Patch Changes

- 03eb0f4: feat (ai/core): add "ai.operationId" telemetry attribute
- 099db96: feat (ai/core): add msToFirstChunk telemetry data
- Updated dependencies [b6c1dee]
  - @ai-sdk/react@0.0.46

## 3.3.10

### Patch Changes

- Updated dependencies [04084a3]
  - @ai-sdk/vue@0.0.38

## 3.3.9

### Patch Changes

- 6ac355e: feat (provider/anthropic): add cache control support
- b56dee1: chore (ai): deprecate prompt helpers
- Updated dependencies [6ac355e]
  - @ai-sdk/provider@0.0.20
  - @ai-sdk/provider-utils@1.0.13
  - @ai-sdk/ui-utils@0.0.33
  - @ai-sdk/react@0.0.45
  - @ai-sdk/solid@0.0.36
  - @ai-sdk/svelte@0.0.38
  - @ai-sdk/vue@0.0.37

## 3.3.8

### Patch Changes

- Updated dependencies [dd712ac]
  - @ai-sdk/provider-utils@1.0.12
  - @ai-sdk/ui-utils@0.0.32
  - @ai-sdk/react@0.0.44
  - @ai-sdk/solid@0.0.35
  - @ai-sdk/svelte@0.0.37
  - @ai-sdk/vue@0.0.36

## 3.3.7

### Patch Changes

- eccbd8e: feat (ai/core): add onChunk callback to streamText
- Updated dependencies [dd4a0f5]
  - @ai-sdk/provider@0.0.19
  - @ai-sdk/provider-utils@1.0.11
  - @ai-sdk/ui-utils@0.0.31
  - @ai-sdk/react@0.0.43
  - @ai-sdk/solid@0.0.34
  - @ai-sdk/svelte@0.0.36
  - @ai-sdk/vue@0.0.35

## 3.3.6

### Patch Changes

- e9c891d: feat (ai/react): useObject supports non-Zod schemas
- 3719e8a: chore (ai/core): provider registry code improvements
- Updated dependencies
  - @ai-sdk/ui-utils@0.0.30
  - @ai-sdk/react@0.0.42
  - @ai-sdk/provider-utils@1.0.10
  - @ai-sdk/provider@0.0.18
  - @ai-sdk/solid@0.0.33
  - @ai-sdk/svelte@0.0.35
  - @ai-sdk/vue@0.0.34

## 3.3.5

### Patch Changes

- 9ada023: feat (ai/core): mask data stream error messages with streamText
- Updated dependencies [e5b58f3]
  - @ai-sdk/ui-utils@0.0.29
  - @ai-sdk/react@0.0.41
  - @ai-sdk/solid@0.0.32
  - @ai-sdk/svelte@0.0.34
  - @ai-sdk/vue@0.0.33

## 3.3.4

### Patch Changes

- 029af4c: feat (ai/core): support schema name & description in generateObject & streamObject
- 3806c0c: chore (ai/ui): increase stream data warning timeout to 15 seconds
- db0118a: feat (ai/core): export Schema type
- Updated dependencies [029af4c]
  - @ai-sdk/provider@0.0.17
  - @ai-sdk/provider-utils@1.0.9
  - @ai-sdk/ui-utils@0.0.28
  - @ai-sdk/react@0.0.40
  - @ai-sdk/solid@0.0.31
  - @ai-sdk/svelte@0.0.33
  - @ai-sdk/vue@0.0.32

## 3.3.3

### Patch Changes

- d58517b: feat (ai/openai): structured outputs
- Updated dependencies [d58517b]
  - @ai-sdk/provider@0.0.16
  - @ai-sdk/provider-utils@1.0.8
  - @ai-sdk/ui-utils@0.0.27
  - @ai-sdk/react@0.0.39
  - @ai-sdk/solid@0.0.30
  - @ai-sdk/svelte@0.0.32
  - @ai-sdk/vue@0.0.31

## 3.3.2

### Patch Changes

- Updated dependencies [96aed25]
  - @ai-sdk/provider@0.0.15
  - @ai-sdk/provider-utils@1.0.7
  - @ai-sdk/ui-utils@0.0.26
  - @ai-sdk/react@0.0.38
  - @ai-sdk/solid@0.0.29
  - @ai-sdk/svelte@0.0.31
  - @ai-sdk/vue@0.0.30

## 3.3.1

### Patch Changes

- 9614584: fix (ai/core): use Symbol.for
- 0762a22: feat (ai/core): support zod transformers in generateObject & streamObject
- Updated dependencies
  - @ai-sdk/provider-utils@1.0.6
  - @ai-sdk/react@0.0.37
  - @ai-sdk/solid@0.0.28
  - @ai-sdk/svelte@0.0.30
  - @ai-sdk/ui-utils@0.0.25
  - @ai-sdk/vue@0.0.29

## 3.3.0

### Minor Changes

- dbc3afb7: chore (ai): release AI SDK 3.3

### Patch Changes

- b9827186: feat (ai/core): update operation.name telemetry attribute to include function id and detailed name

## 3.2.45

### Patch Changes

- Updated dependencies [5be25124]
  - @ai-sdk/ui-utils@0.0.24
  - @ai-sdk/react@0.0.36
  - @ai-sdk/solid@0.0.27
  - @ai-sdk/svelte@0.0.29
  - @ai-sdk/vue@0.0.28

## 3.2.44

### Patch Changes

- Updated dependencies [a147d040]
  - @ai-sdk/react@0.0.35

## 3.2.43

### Patch Changes

- Updated dependencies [b68fae4f]
  - @ai-sdk/react@0.0.34

## 3.2.42

### Patch Changes

- f63c99e7: feat (ai/core): record OpenTelemetry gen_ai attributes
- Updated dependencies [fea7b604]
  - @ai-sdk/ui-utils@0.0.23
  - @ai-sdk/react@0.0.33
  - @ai-sdk/solid@0.0.26
  - @ai-sdk/svelte@0.0.28
  - @ai-sdk/vue@0.0.27

## 3.2.41

### Patch Changes

- a12044c7: feat (ai/core): add recordInputs / recordOutputs setting to telemetry options
- Updated dependencies [1d93d716]
  - @ai-sdk/ui-utils@0.0.22
  - @ai-sdk/react@0.0.32
  - @ai-sdk/solid@0.0.25
  - @ai-sdk/svelte@0.0.27
  - @ai-sdk/vue@0.0.26

## 3.2.40

### Patch Changes

- f56b7e66: feat (ai/ui): add toDataStreamResponse to LangchainAdapter.

## 3.2.39

### Patch Changes

- b694f2f9: feat (ai/svelte): add tool calling support to useChat
- Updated dependencies [b694f2f9]
  - @ai-sdk/svelte@0.0.26

## 3.2.38

### Patch Changes

- 5c4b8cfc: chore (ai/core): rename ai stream methods to data stream (in streamText, LangChainAdapter).
- c450fcf7: feat (ui): invoke useChat onFinish with finishReason and tokens
- e4a1719f: chore (ai/ui): rename streamMode to streamProtocol
- 10158bf2: fix (ai/core): generateObject.doGenerate sets object telemetry attribute
- Updated dependencies
  - @ai-sdk/ui-utils@0.0.21
  - @ai-sdk/svelte@0.0.25
  - @ai-sdk/react@0.0.31
  - @ai-sdk/solid@0.0.24
  - @ai-sdk/vue@0.0.25

## 3.2.37

### Patch Changes

- b2bee4c5: fix (ai/ui): send data, body, headers in useChat().reload
- Updated dependencies [b2bee4c5]
  - @ai-sdk/svelte@0.0.24
  - @ai-sdk/react@0.0.30
  - @ai-sdk/solid@0.0.23

## 3.2.36

### Patch Changes

- a8d1c9e9: feat (ai/core): parallel image download
- cfa360a8: feat (ai/core): add telemetry support to embedMany function.
- 49808ca5: feat (ai/core): add telemetry to streamObject
- Updated dependencies [a8d1c9e9]
  - @ai-sdk/provider-utils@1.0.5
  - @ai-sdk/provider@0.0.14
  - @ai-sdk/react@0.0.29
  - @ai-sdk/svelte@0.0.23
  - @ai-sdk/ui-utils@0.0.20
  - @ai-sdk/vue@0.0.24
  - @ai-sdk/solid@0.0.22

## 3.2.35

### Patch Changes

- 1be014b7: feat (ai/core): add telemetry support for embed function.
- 4f88248f: feat (core): support json schema
- 0d545231: chore (ai/svelte): change sswr into optional peer dependency
- Updated dependencies [4f88248f]
  - @ai-sdk/provider-utils@1.0.4
  - @ai-sdk/react@0.0.28
  - @ai-sdk/svelte@0.0.22
  - @ai-sdk/ui-utils@0.0.19
  - @ai-sdk/vue@0.0.23
  - @ai-sdk/solid@0.0.21

## 3.2.34

### Patch Changes

- 2b9da0f0: feat (core): support stopSequences setting.
- a5b58845: feat (core): support topK setting
- 420f170f: chore (ai/core): use interfaces for core function results
- 13b27ec6: chore (ai/core): remove grammar mode
- 644f6582: feat (ai/core): add telemetry to generateObject
- Updated dependencies
  - @ai-sdk/provider@0.0.13
  - @ai-sdk/provider-utils@1.0.3
  - @ai-sdk/react@0.0.27
  - @ai-sdk/svelte@0.0.21
  - @ai-sdk/ui-utils@0.0.18
  - @ai-sdk/solid@0.0.20
  - @ai-sdk/vue@0.0.22

## 3.2.33

### Patch Changes

- 4b2c09d9: feat (ai/ui): add mutator function support to useChat / setMessages
- 281e7662: chore: add description to ai package
- Updated dependencies
  - @ai-sdk/ui-utils@0.0.17
  - @ai-sdk/svelte@0.0.20
  - @ai-sdk/react@0.0.26
  - @ai-sdk/solid@0.0.19
  - @ai-sdk/vue@0.0.21

## 3.2.32

### Patch Changes

- Updated dependencies [5b7b3bbe]
  - @ai-sdk/ui-utils@0.0.16
  - @ai-sdk/react@0.0.25
  - @ai-sdk/solid@0.0.18
  - @ai-sdk/svelte@0.0.19
  - @ai-sdk/vue@0.0.20

## 3.2.31

### Patch Changes

- b86af092: feat (ai/core): add langchain stream event v2 support to LangChainAdapter

## 3.2.30

### Patch Changes

- Updated dependencies [19c3d50f]
  - @ai-sdk/react@0.0.24
  - @ai-sdk/vue@0.0.19

## 3.2.29

### Patch Changes

- e710b388: fix (ai/core): race condition in mergeStreams
- 6078a690: feat (ai/core): introduce stream data support in toAIStreamResponse

## 3.2.28

### Patch Changes

- 68d1f78c: fix (ai/core): do not construct object promise in streamObject result until requested
- f0bc1e79: feat (ai/ui): add system message support to convertToCoreMessages
- 1f67fe49: feat (ai/ui): stream tool calls with streamText and useChat
- Updated dependencies [1f67fe49]
  - @ai-sdk/ui-utils@0.0.15
  - @ai-sdk/react@0.0.23
  - @ai-sdk/solid@0.0.17
  - @ai-sdk/svelte@0.0.18
  - @ai-sdk/vue@0.0.18

## 3.2.27

### Patch Changes

- 811f4493: fix (ai/core): generateText token usage is sum over all roundtrips

## 3.2.26

### Patch Changes

- 8f545ce9: fix (ai/core): forward request headers in generateObject and streamObject

## 3.2.25

### Patch Changes

- 99ddbb74: feat (ai/react): add experimental support for managing attachments to useChat
- Updated dependencies [99ddbb74]
  - @ai-sdk/ui-utils@0.0.14
  - @ai-sdk/react@0.0.22
  - @ai-sdk/solid@0.0.16
  - @ai-sdk/svelte@0.0.17
  - @ai-sdk/vue@0.0.17

## 3.2.24

### Patch Changes

- f041c056: feat (ai/core): add roundtrips property to generateText result

## 3.2.23

### Patch Changes

- a6cb2c8b: feat (ai/ui): add keepLastMessageOnError option to useChat
- Updated dependencies [a6cb2c8b]
  - @ai-sdk/ui-utils@0.0.13
  - @ai-sdk/svelte@0.0.16
  - @ai-sdk/react@0.0.21
  - @ai-sdk/solid@0.0.15
  - @ai-sdk/vue@0.0.16

## 3.2.22

### Patch Changes

- 53fccf1c: fix (ai/core): report error on controller
- dd0d854e: feat (ai/vue): add useAssistant
- Updated dependencies [dd0d854e]
  - @ai-sdk/vue@0.0.15

## 3.2.21

### Patch Changes

- 56bbc2a7: feat (ai/ui): set body and headers directly on options for handleSubmit and append
- Updated dependencies [56bbc2a7]
  - @ai-sdk/ui-utils@0.0.12
  - @ai-sdk/svelte@0.0.15
  - @ai-sdk/react@0.0.20
  - @ai-sdk/solid@0.0.14
  - @ai-sdk/vue@0.0.14

## 3.2.20

### Patch Changes

- 671331b6: feat (core): add experimental OpenTelemetry support for generateText and streamText

## 3.2.19

### Patch Changes

- b7290943: chore (ai/core): rename TokenUsage type to CompletionTokenUsage
- b7290943: feat (ai/core): add token usage to embed and embedMany
- Updated dependencies [b7290943]
  - @ai-sdk/provider@0.0.12
  - @ai-sdk/provider-utils@1.0.2
  - @ai-sdk/react@0.0.19
  - @ai-sdk/svelte@0.0.14
  - @ai-sdk/ui-utils@0.0.11
  - @ai-sdk/solid@0.0.13
  - @ai-sdk/vue@0.0.13

## 3.2.18

### Patch Changes

- Updated dependencies [70d18003]
  - @ai-sdk/react@0.0.18

## 3.2.17

### Patch Changes

- 3db90c3d: allow empty handleSubmit submissions for useChat
- abb22602: feat (ai): verify that system messages have string content
- 5c1f0bd3: fix unclosed streamable value console message
- Updated dependencies
  - @ai-sdk/react@0.0.17
  - @ai-sdk/svelte@0.0.13
  - @ai-sdk/solid@0.0.12
  - @ai-sdk/vue@0.0.12
  - @ai-sdk/provider-utils@1.0.1
  - @ai-sdk/ui-utils@0.0.10

## 3.2.16

### Patch Changes

- Updated dependencies [3f756a6b]
  - @ai-sdk/react@0.0.16

## 3.2.15

### Patch Changes

- 6c99581e: fix (ai/react): stop() on useObject does not throw error and clears isLoading
- Updated dependencies [6c99581e]
  - @ai-sdk/react@0.0.15

## 3.2.14

### Patch Changes

- Updated dependencies
  - @ai-sdk/react@0.0.14
  - @ai-sdk/ui-utils@0.0.9
  - @ai-sdk/solid@0.0.11
  - @ai-sdk/svelte@0.0.12
  - @ai-sdk/vue@0.0.11

## 3.2.13

### Patch Changes

- d3100b9c: feat (ai/ui): support custom fetch function in useChat, useCompletion, useAssistant, useObject
- Updated dependencies [d3100b9c]
  - @ai-sdk/ui-utils@0.0.8
  - @ai-sdk/svelte@0.0.11
  - @ai-sdk/react@0.0.13
  - @ai-sdk/solid@0.0.10
  - @ai-sdk/vue@0.0.10

## 3.2.12

### Patch Changes

- 5edc6110: feat (ai/core): add custom request header support
- Updated dependencies
  - @ai-sdk/provider@0.0.11
  - @ai-sdk/provider-utils@1.0.0
  - @ai-sdk/react@0.0.12
  - @ai-sdk/svelte@0.0.10
  - @ai-sdk/ui-utils@0.0.7
  - @ai-sdk/solid@0.0.9
  - @ai-sdk/vue@0.0.9

## 3.2.11

### Patch Changes

- c908f741: chore (ui/solid): update solidjs useChat and useCompletion to feature parity with React
- 827ef450: feat (ai/ui): improve error handling in useAssistant
- Updated dependencies
  - @ai-sdk/solid@0.0.8
  - @ai-sdk/svelte@0.0.9
  - @ai-sdk/react@0.0.11

## 3.2.10

### Patch Changes

- Updated dependencies
  - @ai-sdk/react@0.0.10

## 3.2.9

### Patch Changes

- 82d9c8de: feat (ai/ui): make event in useAssistant submitMessage optional
- Updated dependencies
  - @ai-sdk/svelte@0.0.8
  - @ai-sdk/react@0.0.9
  - @ai-sdk/vue@0.0.8

## 3.2.8

### Patch Changes

- 54bf4083: feat (ai/react): control request body in useChat
- Updated dependencies [54bf4083]
  - @ai-sdk/ui-utils@0.0.6
  - @ai-sdk/react@0.0.8
  - @ai-sdk/solid@0.0.7
  - @ai-sdk/svelte@0.0.7
  - @ai-sdk/vue@0.0.7

## 3.2.7

### Patch Changes

- d42b8907: feat (ui): make event in handleSubmit optional
- Updated dependencies [d42b8907]
  - @ai-sdk/svelte@0.0.6
  - @ai-sdk/react@0.0.7
  - @ai-sdk/solid@0.0.6
  - @ai-sdk/vue@0.0.6

## 3.2.6

### Patch Changes

- 74e28222: fix (ai/rsc): "could not find InternalStreamableUIClient" bug

## 3.2.5

### Patch Changes

- 4d426d0c: fix (ai): split provider and model ids correctly in the provider registry

## 3.2.4

### Patch Changes

- Updated dependencies [3cb103bc]
  - @ai-sdk/react@0.0.6

## 3.2.3

### Patch Changes

- 89b7552b: chore (ai): remove deprecation from ai/react imports, add experimental_useObject
- Updated dependencies [02f6a088]
  - @ai-sdk/provider-utils@0.0.16
  - @ai-sdk/react@0.0.5
  - @ai-sdk/svelte@0.0.5
  - @ai-sdk/ui-utils@0.0.5
  - @ai-sdk/solid@0.0.5
  - @ai-sdk/vue@0.0.5

## 3.2.2

### Patch Changes

- 0565cd72: feat (ai/core): add toJsonResponse to generateObject result.

## 3.2.1

### Patch Changes

- 008725ec: feat (ai): add textStream, toTextStreamResponse(), and pipeTextStreamToResponse() to streamObject
- 520fb2d5: feat (rsc): add streamUI onFinish callback
- Updated dependencies
  - @ai-sdk/react@0.0.4
  - @ai-sdk/ui-utils@0.0.4
  - @ai-sdk/solid@0.0.4
  - @ai-sdk/svelte@0.0.4
  - @ai-sdk/vue@0.0.4

## 3.2.0

### Minor Changes

- 85ef6d18: chore (ai): AI SDK 3.2 release

### Patch Changes

- b965dd2d: fix (core): pass settings correctly for generateObject and streamObject

## 3.1.37

### Patch Changes

- 85712895: chore (@ai-sdk/provider-utils): move test helper to provider utils
- Updated dependencies
  - @ai-sdk/provider-utils@0.0.15
  - @ai-sdk/react@0.0.3
  - @ai-sdk/svelte@0.0.3
  - @ai-sdk/ui-utils@0.0.3
  - @ai-sdk/solid@0.0.3
  - @ai-sdk/vue@0.0.3

## 3.1.36

### Patch Changes

- 4728c37f: feat (core): add text embedding model support to provider registry
- 8c49166e: chore (core): rename experimental_createModelRegistry to experimental_createProviderRegistry
- Updated dependencies [7910ae84]
  - @ai-sdk/provider-utils@0.0.14
  - @ai-sdk/react@0.0.2
  - @ai-sdk/svelte@0.0.2
  - @ai-sdk/ui-utils@0.0.2
  - @ai-sdk/solid@0.0.2
  - @ai-sdk/vue@0.0.2

## 3.1.35

### Patch Changes

- 06123501: feat (core): support https and data url strings in image parts

## 3.1.34

### Patch Changes

- d25566ac: feat (core): add cosineSimilarity helper function
- 87a5d27e: feat (core): introduce InvalidMessageRoleError.

## 3.1.33

### Patch Changes

- 6fb14b5d: chore (streams): deprecate nanoid export.
- 05536768: feat (core): add experimental model registry

## 3.1.32

### Patch Changes

- 3cabf078: fix(ai/rsc): Refactor streamable UI internal implementation

## 3.1.31

### Patch Changes

- 85f209a4: chore: extracted ui library support into separate modules
- 85f209a4: removed (streams): experimental_StreamingReactResponse was removed. Please use AI SDK RSC instead.
- Updated dependencies [85f209a4]
  - @ai-sdk/ui-utils@0.0.1
  - @ai-sdk/svelte@0.0.1
  - @ai-sdk/react@0.0.1
  - @ai-sdk/solid@0.0.1
  - @ai-sdk/vue@0.0.1

## 3.1.30

### Patch Changes

- fcf4323b: fix (core): filter out empty assistant text messages

## 3.1.29

### Patch Changes

- 28427d3e: feat (core): add streamObject onFinish callback

## 3.1.28

### Patch Changes

- 102ca22f: feat (core): add object promise to streamObject result
- Updated dependencies [102ca22f]
  - @ai-sdk/provider@0.0.10
  - @ai-sdk/provider-utils@0.0.13

## 3.1.27

### Patch Changes

- c9198d4d: feat (ui): send annotation and data fields in useChat when sendExtraMessageFields is true
- Updated dependencies
  - @ai-sdk/provider@0.0.9
  - @ai-sdk/provider-utils@0.0.12

## 3.1.26

### Patch Changes

- 5ee44cae: feat (provider): langchain StringOutputParser support

## 3.1.25

### Patch Changes

- ff281126: fix(ai/rsc): Remove extra reconcilation of streamUI

## 3.1.24

### Patch Changes

- 93cae126: fix(ai/rsc): Fix unsafe {} type in application code for StreamableValue
- 08b5c509: feat (core): add tokenUsage to streamObject result

## 3.1.23

### Patch Changes

- c03cafe6: chore (core, ui): rename maxAutomaticRoundtrips to maxToolRoundtrips

## 3.1.22

### Patch Changes

- 14bb8694: chore (ui): move maxAutomaticRoundtrips and addToolResult out of experimental

## 3.1.21

### Patch Changes

- 213f2411: fix (core,streams): support ResponseInit variants
- 09698bca: chore (streams): deprecate streaming helpers that have a provider replacement

## 3.1.20

### Patch Changes

- 0e1da476: feat (core): add maxAutomaticRoundtrips setting to generateText

## 3.1.19

### Patch Changes

- 9882d24b: fix (ui/svelte): send data to server
- 131bbd3e: fix (ui): remove console.log statements

## 3.1.18

### Patch Changes

- f9dee8ac: fix(ai/rsc): Fix types for createStreamableValue and createStreamableUI
- 1c0ebf8e: feat (core): add responseMessages to generateText result

## 3.1.17

### Patch Changes

- 92b993b7: ai/rsc: improve getAIState and getMutableAIState types
- 7de628e9: chore (ui): deprecate old function/tool call handling
- 7de628e9: feat (ui): add onToolCall handler to useChat

## 3.1.16

### Patch Changes

- f39c0dd2: feat (core, rsc): add toolChoice setting
- Updated dependencies [f39c0dd2]
  - @ai-sdk/provider@0.0.8
  - @ai-sdk/provider-utils@0.0.11

## 3.1.15

### Patch Changes

- 8e780288: feat (ai/core): add onFinish callback to streamText
- 8e780288: feat (ai/core): add text, toolCalls, and toolResults promises to StreamTextResult (matching the generateText result API with async methods)
- Updated dependencies [8e780288]
  - @ai-sdk/provider@0.0.7
  - @ai-sdk/provider-utils@0.0.10

## 3.1.14

### Patch Changes

- 6109c6a: feat (ai/react): add experimental_maxAutomaticRoundtrips to useChat

## 3.1.13

### Patch Changes

- 60117c9: dependencies (ai/ui): add React 18.3 and 19 support (peer dependency)
- Updated dependencies
  - @ai-sdk/provider@0.0.6
  - @ai-sdk/provider-utils@0.0.9

## 3.1.12

### Patch Changes

- ae05fb7: feat (ai/streams): add StreamData support to streamToResponse

## 3.1.11

### Patch Changes

- a085d42: fix (ai/ui): decouple StreamData chunks from LLM stream

## 3.1.10

### Patch Changes

- 3a21030: feat (ai/core): add embedMany function

## 3.1.9

### Patch Changes

- 18a9655: feat (ai/svelte): add useAssistant

## 3.1.8

### Patch Changes

- 0f6bc4e: feat (ai/core): add embed function
- Updated dependencies [0f6bc4e]
  - @ai-sdk/provider@0.0.5
  - @ai-sdk/provider-utils@0.0.8

## 3.1.7

### Patch Changes

- f617b97: feat (ai): support client/server tool calls with useChat and streamText

## 3.1.6

### Patch Changes

- 2e78acb: Deprecate StreamingReactResponse (use AI SDK RSC instead).
- 8439884: ai/rsc: make RSC streamable utils chainable
- 325ca55: feat (ai/core): improve image content part error message
- Updated dependencies [325ca55]
  - @ai-sdk/provider@0.0.4
  - @ai-sdk/provider-utils@0.0.7

## 3.1.5

### Patch Changes

- 5b01c13: feat (ai/core): add system message support in messages list

## 3.1.4

### Patch Changes

- ceb44bc: feat (ai/ui): add stop() helper to useAssistant (important: AssistantResponse now requires OpenAI SDK 4.42+)
- 37c9d4c: feat (ai/streams): add LangChainAdapter.toAIStream()

## 3.1.3

### Patch Changes

- 970a099: fix (ai/core): streamObject fixes partial json with empty objects correctly
- 1ac2390: feat (ai/core): add usage and finishReason to streamText result.
- Updated dependencies [276f22b]
  - @ai-sdk/provider-utils@0.0.6

## 3.1.2

### Patch Changes

- d1b1880: fix (ai/core): allow reading streams in streamText result multiple times

## 3.1.1

### Patch Changes

- 0f77132: ai/rsc: remove experimental\_ from streamUI

## 3.1.0

### Minor Changes

- 73356a9: Move AI Core functions out of experimental (streamText, generateText, streamObject, generateObject).

## 3.0.35

### Patch Changes

- 41d5736: ai/core: re-expose language model types.
- b4c68ec: ai/rsc: ReadableStream as provider for createStreamableValue; add .append() method
- Updated dependencies [41d5736]
  - @ai-sdk/provider@0.0.3
  - @ai-sdk/provider-utils@0.0.5

## 3.0.34

### Patch Changes

- b9a831e: ai/rsc: add experimental_streamUI()

## 3.0.33

### Patch Changes

- 56ef84a: ai/core: fix abort handling in transformation stream
- Updated dependencies [56ef84a]
  - @ai-sdk/provider-utils@0.0.4

## 3.0.32

### Patch Changes

- 0e0d2af: ai/core: add pipeTextStreamToResponse helper to streamText.

## 3.0.31

### Patch Changes

- 74c63b1: ai/core: add toAIStreamResponse() helper to streamText.

## 3.0.30

### Patch Changes

- e7e5898: use-assistant: fix missing message content

## 3.0.29

### Patch Changes

- 22a737e: Fix: mark useAssistant as in progress for append/submitMessage.

## 3.0.28

### Patch Changes

- d6431ae: ai/core: add logprobs support (thanks @SamStenner for the contribution)
- 25f3350: ai/core: add support for getting raw response headers.
- Updated dependencies
  - @ai-sdk/provider@0.0.2
  - @ai-sdk/provider-utils@0.0.3

## 3.0.27

### Patch Changes

- eb150a6: ai/core: remove scaling of setting values (breaking change). If you were using the temperature, frequency penalty, or presence penalty settings, you need to update the providers and adjust the setting values.
- Updated dependencies [eb150a6]
  - @ai-sdk/provider-utils@0.0.2
  - @ai-sdk/provider@0.0.1

## 3.0.26

### Patch Changes

- f90f6a1: ai/core: add pipeAIStreamToResponse() to streamText result.

## 3.0.25

### Patch Changes

- 1e84d6d: Fix: remove mistral lib type dependency.
- 9c2a049: Add append() helper to useAssistant.

## 3.0.24

### Patch Changes

- e94fb32: feat(ai/rsc): Make `onSetAIState` and `onGetUIState` stable

## 3.0.23

### Patch Changes

- 66b5892: Add streamMode parameter to useChat and useCompletion.
- Updated dependencies [7b8791d]
  - @ai-sdk/provider-utils@0.0.1

## 3.0.22

### Patch Changes

- d544886: Breaking change: extract experimental AI core provider packages. They can now be imported with e.g. import { openai } from '@ai-sdk/openai' after adding them to a project.
- ea6b0e1: Expose formatStreamPart, parseStreamPart, and readDataStream helpers.

## 3.0.21

### Patch Changes

- 87d3db5: Extracted @ai-sdk/provider package
- 8c40f8c: ai/core: Fix openai provider streamObject for gpt-4-turbo
- 5cd29bd: ai/core: add toTextStreamResponse() method to streamText result

## 3.0.20

### Patch Changes

- f42bbb5: Remove experimental from useAssistant and AssistantResponse.
- 149fe26: Deprecate <Tokens/>
- 2eb4b55: Remove experimental\_ prefix from StreamData.
- e45fa96: Add stream support for Bedrock/Cohere.
- a6b2500: Deprecated the `experimental_streamData: true` setting from AIStreamCallbacksAndOptions. You can delete occurrences in your code. The stream data protocol is now used by default.

## 3.0.19

### Patch Changes

- 4f4c7f5: ai/core: Anthropic tool call support

## 3.0.18

### Patch Changes

- 63d587e: Add Anthropic provider for ai/core functions (no tool calling).
- 63d587e: Add automatic mime type detection for images in ai/core prompts.

## 3.0.17

### Patch Changes

- 2b991c4: Add Google Generative AI provider for ai/core functions.

## 3.0.16

### Patch Changes

- a54ea77: feat(ai/rsc): add `useStreamableValue`

## 3.0.15

### Patch Changes

- 4aed2a5: Add JSDoc comments for ai/core functions.
- cf8d12f: Export experimental language model specification under `ai/spec`.

## 3.0.14

### Patch Changes

- 8088de8: fix(ai/rsc): improve typings for `StreamableValue`
- 20007b9: feat(ai/rsc): support string diff and patch in streamable value
- 6039460: Support Bedrock Anthropic Stream for Messages API.
- e83bfe3: Added experimental ai/core functions (streamText, generateText, streamObject, generateObject). Add OpenAI and Mistral language model providers.

## 3.0.13

### Patch Changes

- 026d061: Expose setMessages in useAssistant hook
- 42209be: AssistantResponse: specify forwardStream return type.

## 3.0.12

### Patch Changes

- b99b008: fix(ai/rsc): avoid appending boundary if the same reference was passed

## 3.0.11

### Patch Changes

- ce009e2: Added OpenAI assistants streaming.
- 3f9bf3e: Updates types to OpenAI SDK 4.29.0

## 3.0.10

### Patch Changes

- 33d261a: fix(ai/rsc): Fix .append() behavior

## 3.0.9

### Patch Changes

- 81ca3d6: fix(ai/rsc): improve .done() argument type

## 3.0.8

### Patch Changes

- a94aab2: ai/rsc: optimize streamable value stream size

## 3.0.7

### Patch Changes

- 9a9ae73: feat(ai/rsc): readStreamableValue

## 3.0.6

### Patch Changes

- 1355ad0: Fix: experimental_onToolCall is called with parsed tool args
- 9348f06: ai/rsc: improve dev error and warnings by trying to detect hanging streams
- 8be9404: fix type resolution

## 3.0.5

### Patch Changes

- a973f1e: Support Anthropic SDK v0.15.0
- e25f3ca: type improvements

## 3.0.4

### Patch Changes

- 7962862: fix `useActions` type inference
- aab5324: Revert "fix(render): parse the args based on the zod schema"
- fe55612: Bump OpenAI dependency to 4.28.4; fix type error in render

## 3.0.3

### Patch Changes

- 4d816ca: fix(render): parse the args based on the zod schema
- d158a47: fix potential race conditions

## 3.0.2

### Patch Changes

- 73bd06e: fix(useActions): return typed object

## 3.0.1

### Patch Changes

- ac20a25: ai/rsc: fix text response and async generator
- b88778f: Added onText callback for text tokens.

## 3.0.0

### Major Changes

- 51054a9: add ai/rsc

## 2.2.37

### Patch Changes

- a6b5764: Add support for Mistral's JavaScript SDK

## 2.2.36

### Patch Changes

- 141f0ce: Fix: onFinal callback is invoked with text from onToolCall when onToolCall returns string

## 2.2.35

### Patch Changes

- b717dad: Adding Inkeep as a stream provider

## 2.2.34

### Patch Changes

- 2c8ffdb: cohere-stream: support AsyncIterable
- ed1e278: Message annotations handling for all Message types

## 2.2.33

### Patch Changes

- 8542ae7: react/use-assistant: add onError handler
- 97039ff: OpenAIStream: Add support for the Azure OpenAI client library

## 2.2.32

### Patch Changes

- 7851fa0: StreamData: add `annotations` and `appendMessageAnnotation` support

## 2.2.31

### Patch Changes

- 9b89c4d: react/use-assistant: Expose setInput
- 75751c9: ai/react: Add experimental_onToolCall to useChat.

## 2.2.30

### Patch Changes

- ac503e0: ai/solid: add chat request options to useChat
- b78a73e: Add GoogleGenerativeAIStream for Gemini support
- 5220336: ai/svelte: Add experimental_onToolCall to useChat.
- ef99062: Add support for the Anthropic message API
- 5220336: Add experimental_onToolCall to OpenAIStream.
- ac503e0: ai/vue: add chat request options to useChat

## 2.2.29

### Patch Changes

- 5a9ae2e: ai/prompt: add `experimental_buildOpenAIMessages` to validate and cast AI SDK messages to OpenAI messages

## 2.2.28

### Patch Changes

- 07a679c: Add data message support to useAssistant & assistantResponse.
- fbae595: ai/react: `api` functions are no longer used as a cache key in `useChat`

## 2.2.27

### Patch Changes

- 0fd1205: ai/vue: Add complex response parsing and StreamData support to useCompletion
- a7dc746: experimental_useAssistant: Expose extra fetch options
- 3dcf01e: ai/react Add data support to useCompletion
- 0c3b338: ai/svelte: Add complex response parsing and StreamData support to useCompletion
- 8284777: ai/solid: Add complex response parsing and StreamData support to useCompletion

## 2.2.26

### Patch Changes

- df1ad33: ai/vue: Add complex response parsing and StreamData support to useChat
- 3ff8a56: Add `generateId` to use-chat params to allow overriding message ID generation
- 6c2a49c: ai/react experimental_useAssistant() submit can be called without an event
- 8b4f7d1: ai/react: Add complex response parsing and StreamData support to useCompletion

## 2.2.25

### Patch Changes

- 1e61c69: chore: specify the minimum react version to 18
- 6aec2d2: Expose threadId in useAssistant
- c2369df: Add AWS Bedrock support
- 223fde3: ai/svelte: Add complex response parsing and StreamData support to useChat

## 2.2.24

### Patch Changes

- 69ca8f5: ai/react: add experimental_useAssistant hook and experimental_AssistantResponse
- 3e2299e: experimental_StreamData/StreamingReactResponse: optimize parsing, improve types
- 70bd2ac: ai/solid: add experimental_StreamData support to useChat

## 2.2.23

### Patch Changes

- 5a04321: add StreamData support to StreamingReactResponse, add client-side data API to react/use-chat

## 2.2.22

### Patch Changes

- 4529831: ai/react: Do not store initialMessages in useState
- db5378c: experimental_StreamData: fix data type to be JSONValue

## 2.2.21

### Patch Changes

- 2c8d4bd: Support openai@4.16.0 and later

## 2.2.20

### Patch Changes

- 424d5ee: experimental_StreamData: fix trailing newline parsing bug in decoder
- c364c6a: cohere: fix closing cohere stream, avoids response from hanging

## 2.2.19

### Patch Changes

- 699552d: add experimental_StreamingReactResponse

## 2.2.18

### Patch Changes

- 0bd27f6: react/use-chat: allow client-side handling of function call without following response

## 2.2.17

### Patch Changes

- 5ed581d: Use interface instead of type for Message to allow declaration merging
- 9adec1e: vue and solid: fix including `function_call` and `name` fields in subsequent requests

## 2.2.16

### Patch Changes

- e569688: Fix for #637, resync interfaces

## 2.2.15

### Patch Changes

- c5d1857: fix: return complete response in onFinish when onCompletion isn't passed
- c5d1857: replicate-stream: fix types for replicate@0.20.0+

## 2.2.14

### Patch Changes

- 6229d6b: openai: fix OpenAIStream types with openai@4.11+

## 2.2.13

### Patch Changes

- a4a997f: all providers: reset error message on (re)submission

## 2.2.12

### Patch Changes

- cb181b4: ai/vue: wrap body with unref to support reactivity

## 2.2.11

### Patch Changes

- 2470658: ai/react: fix: handle partial chunks in react getStreamedResponse when using experimental_StreamData

## 2.2.10

### Patch Changes

- 8a2cbaf: vue/use-completion: fix: don't send network request for loading state"
- bbf4403: langchain-stream: return langchain `writer` from LangChainStream

## 2.2.9

### Patch Changes

- 3fc2b32: ai/vue: fix: make body parameter reactive

## 2.2.8

### Patch Changes

- 26bf998: ai/react: make reload/complete/append functions stable via useCallback

## 2.2.7

### Patch Changes

- 2f97630: react/use-chat: fix aborting clientside function calls too early
- 1157340: fix: infinite loop for experimental stream data (#484)

## 2.2.6

### Patch Changes

- e5bf68d: react/use-chat: fix experimental functions returning proper function messages

  Closes #478

## 2.2.5

### Patch Changes

- e5bf68d: react/use-chat: fix experimental functions returning proper function messages

  Closes #478

## 2.2.4

### Patch Changes

- 7b389a7: fix: improve safety for type check in openai-stream

## 2.2.3

### Patch Changes

- 867a3f9: Fix client-side function calling (#467, #469)

  add Completion type from the `openai` SDK to openai-stream (#472)

## 2.2.2

### Patch Changes

- 84e0cc8: Add experimental_StreamData and new opt-in wire protocol to enable streaming additional data. See https://github.com/vercel/ai/pull/425.

  Changes `onCompletion` back to run every completion, including recursive function calls. Adds an `onFinish` callback that runs once everything has streamed.

  If you're using experimental function handlers on the server _and_ caching via `onCompletion`,
  you may want to adjust your caching code to account for recursive calls so the same key isn't used.

  ```
  let depth = 0

  const stream = OpenAIStream(response, {
      async onCompletion(completion) {
        depth++
        await kv.set(key + '_' + depth, completion)
        await kv.expire(key + '_' + depth, 60 * 60)
      }
    })
  ```

## 2.2.1

### Patch Changes

- 04084a8: openai-stream: fix experimental_onFunctionCall types for OpenAI SDK v4

## 2.2.0

### Minor Changes

- dca1ed9: Update packages and examples to use OpenAI SDK v4

## 2.1.34

### Patch Changes

- c2917d3: Add support for the Anthropic SDK, newer Anthropic API versions, and improve Anthropic error handling

## 2.1.33

### Patch Changes

- 4ef8015: Prevent `isLoading` in vue integration from triggering extraneous network requests

## 2.1.32

### Patch Changes

- 5f91427: ai/svelte: fix isLoading return value

## 2.1.31

### Patch Changes

- ab2b973: fix pnpm-lock.yaml

## 2.1.30

### Patch Changes

- 4df2a49: Fix termination of ReplicateStream by removing the terminating `{}`from output

## 2.1.29

### Patch Changes

- 3929a41: Add ReplicateStream helper

## 2.1.28

### Patch Changes

- 9012e17: react/svelte/vue: fix making unnecessary SWR request to API endpoint

## 2.1.27

### Patch Changes

- 3d29799: React/Svelte/Vue: keep isLoading in sync between hooks with the same ID.

  React: don't throw error when submitting

## 2.1.26

### Patch Changes

- f50d9ef: Add experimental_buildLlama2Prompt helper for Hugging Face

## 2.1.25

### Patch Changes

- 877c16f: ai/react: don't throw error if onError is passed

## 2.1.24

### Patch Changes

- f3f5866: Adds SolidJS support and SolidStart example

## 2.1.23

### Patch Changes

- 0ebc2f0: streams/openai-stream: don't call onStart/onCompletion when recursing

## 2.1.22

### Patch Changes

- 9320e95: Add (experimental) prompt construction helpers for StarChat and OpenAssistant
- e3a7ec8: Support <|end|> token for StarChat beta in huggingface-stream

## 2.1.21

### Patch Changes

- 561a49a: Providing a function to `function_call` request parameter of the OpenAI Chat Completions API no longer breaks OpenAI function stream parsing.

## 2.1.20

### Patch Changes

- e361114: OpenAI functions: allow returning string in callback

## 2.1.19

### Patch Changes

- e4281ca: Add experimental server-side OpenAI function handling

## 2.1.18

### Patch Changes

- 6648b21: Add experimental client side OpenAI function calling to Svelte bindings
- e5b983f: feat(streams): add http error handling for openai

## 2.1.17

### Patch Changes

- 3ed65bf: Remove dependency on node crypto API

## 2.1.16

### Patch Changes

- 8bfb43d: Fix svelte peer dependency version

## 2.1.15

### Patch Changes

- 4a2b978: Update cohere stream and add docs

## 2.1.14

### Patch Changes

- 3164adb: Fix regression with generated ids

## 2.1.13

### Patch Changes

- fd82961: Use rfc4122 IDs when generating chat/completion IDs

## 2.1.12

### Patch Changes

- b7b93e5: Add <Tokens> RSC to ai/react

## 2.1.11

### Patch Changes

- 8bf637a: Fix langchain handlers so that they now are correctly invoked and update examples and docs to show correct usage (passing the handlers to `llm.call` and not the model itself).

## 2.1.10

### Patch Changes

- a7b3d0e: Experimental support for OpenAI function calling

## 2.1.9

### Patch Changes

- 9cdf968: core/react: add Tokens react server component

## 2.1.8

### Patch Changes

- 44d9879: Support extra request options in chat and completion hooks

## 2.1.7

### Patch Changes

- bde3898: Allow an async onResponse callback in useChat/useCompletion

## 2.1.6

### Patch Changes

- 23f0899: Set stream: true when decoding streamed chunks

## 2.1.5

### Patch Changes

- 89938b0: Provider direct callback handlers in LangChain now that `CallbackManager` is deprecated.

## 2.1.4

### Patch Changes

- c16d650: Improve type saftey for AIStream. Added JSDoc comments.

## 2.1.3

### Patch Changes

- a9591fe: Add `createdAt` on `user` input message in `useChat` (it was already present in `assistant` messages)

## 2.1.2

### Patch Changes

- f37d4ec: fix bundling

## 2.1.1

### Patch Changes

- 9fdb51a: fix: add better typing for store within svelte implementation (#104)

## 2.1.0

### Minor Changes

- 71f9c51: This adds Vue support for `ai` via the `ai/vue` subpath export. Vue composables `useChat` and `useCompletion` are provided.

### Patch Changes

- ad54c79: add tests

## 2.0.1

### Patch Changes

- be90740: - Switches `LangChainStream` helper callback `handler` to return use `handleChainEnd` instead of `handleLLMEnd` so as to work with sequential chains

## 2.0.0

### Major Changes

- 095de43: New package name!

## 0.0.14

### Patch Changes

- c6586a2: Add onError callback, include response text in error if response is not okay

## 0.0.13

### Patch Changes

- c1f4a91: Throw error when provided AI response isn't valid

## 0.0.12

### Patch Changes

- ea4e66a: improve API types

## 0.0.11

### Patch Changes

- a6bc35c: fix package exports for react and svelte subpackages

## 0.0.10

### Patch Changes

- 56f9537: add svelte apis

## 0.0.9

### Patch Changes

- 78477d3: - Create `/react` sub-package.
  - Create `import { useChat, useCompletion } from 'ai/react'` and mark React as an optional peer dependency so we can add more framework support in the future.
  - Also renamed `set` to `setMessages` and `setCompletion` to unify the API naming as we have `setInput` too.
  - Added an `sendExtraMessageFields` field to `useChat` that defaults to `false`, to prevent OpenAI errors when `id` is not filtered out.
- c4c1be3: useCompletion.handleSubmit does not clear the input anymore
- 7de2185: create /react export

## 0.0.8

### Patch Changes

- fc83e95: Implement new start-of-stream newline trimming
- 2c6fa04: Optimize callbacks TransformStream to be more memory efficient when `onCompletion` is not specified

## 0.0.7

### Patch Changes

- fdfef52: - Splits the `EventSource` parser into a reusable helper
  - Uses a `TransformStream` for this, so the stream respects back-pressure
  - Splits the "forking" stream for callbacks into a reusable helper
  - Changes the signature for `customParser` to avoid Stringify -> Encode -> Decode -> Parse round trip
  - Uses ?.() optional call syntax for callbacks
  - Uses string.includes to perform newline checking
  - Handles the `null` `res.body` case
  - Fixes Anthropic's streaming responses
    - Anthropic returns cumulative responses, not deltas like OpenAI
    - https://github.com/hwchase17/langchain/blob/3af36943/langchain/llms/anthropic.py#L190-L193

## 0.0.6

### Patch Changes

- d70a9e7: Add streamToResponse
- 47b85b2: Improve abortController and callbacks of `useChat`
- 6f7b43a: Export `UseCompletionHelpers` as a TypeScript type alias

## 0.0.5

### Patch Changes

- 4405a8a: fix duplicated `'use client'` directives

## 0.0.4

### Patch Changes

- b869104: Added `LangChainStream`, `useCompletion`, and `useChat`

## 0.0.3

### Patch Changes

- 677d222: add useCompletion

## 0.0.2

### Patch Changes

- af400e2: Fix release script

## 0.0.1

### Patch Changes

- b7e227d: Add `useChat` hook

## 0.0.2

### Patch Changes

- 9a8a845: Testing out release
